"""
Name: access_token.py
Purpose: Personal access token models (the token itself only on AccessTokenIssued).
"""

from typing import TYPE_CHECKING, Annotated, Any, TypeVar

from pydantic import Field
from typing_extensions import Self

from ._generated.models import AccessToken as _AccessTokenBase
from ._generated.models import AccessTokenIssued as _AccessTokenIssuedBase

if TYPE_CHECKING:
    from ..client import HiveClient


class AccessToken(_AccessTokenBase):
    """A personal access token as Hive lists it: its hint, never the token."""

    hive_client: Annotated["HiveClient", Field(exclude=True, repr=False)]

    @classmethod
    def from_dict(cls, src_dict: dict[str, Any], hive_client: "HiveClient") -> Self:
        data = dict(src_dict)
        data["hive_client"] = hive_client
        return cls.model_validate(data)


class AccessTokenIssued(_AccessTokenIssuedBase):
    """A personal access token just created or regenerated: ``token`` is shown only this once."""

    hive_client: Annotated["HiveClient", Field(exclude=True, repr=False)]
    token: Annotated[str, Field(repr=False)]

    @classmethod
    def from_dict(cls, src_dict: dict[str, Any], hive_client: "HiveClient") -> Self:
        data = dict(src_dict)
        data["hive_client"] = hive_client
        return cls.model_validate(data)


T = TypeVar("T", bound="AccessToken")
