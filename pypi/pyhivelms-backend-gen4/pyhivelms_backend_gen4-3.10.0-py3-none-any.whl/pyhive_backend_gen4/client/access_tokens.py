"""Personal access token mixin for HiveClient (``/api/core/management/access-tokens/``).

Hive refuses these endpoints to a client that is itself signed in with an
access token: sign in with a password or SSO to create one.
"""

from collections.abc import Iterable
from datetime import datetime
from typing import TYPE_CHECKING

from ..types._generated.enums import TokenAccessEnum
from ..types.access_token import AccessToken, AccessTokenIssued
from .client_shared import ClientCoreMixin
from .utils import resolve_item_or_id

if TYPE_CHECKING:
    from ..types.user import User

    UserLike = int | User


class AccessTokenClientMixin(ClientCoreMixin):
    """Mixin that exposes personal access token endpoints."""

    def get_access_tokens(self) -> Iterable[AccessToken]:
        """Yield the access tokens Hive lists for the signed-in user (an admin's include everyone's)."""
        return self._get_core_items("/api/core/management/access-tokens/", AccessToken)

    def create_access_token(
        self,
        name: str,
        *,
        access: TokenAccessEnum = TokenAccessEnum.READ,
        expires_at: datetime | None = None,
        user: "UserLike | None" = None,
    ) -> AccessTokenIssued:
        """Create an access token (for ``user``: admins only); ``expires_at=None`` never expires."""
        from . import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        payload: dict[str, object] = {
            "name": name,
            "access": str(access),
            "expires_at": expires_at.isoformat() if expires_at else None,
        }
        if user is not None:
            payload["user_id"] = resolve_item_or_id(user)
        data = self.post("/api/core/management/access-tokens/", payload)
        assert isinstance(data, dict)
        return AccessTokenIssued.from_dict(data, hive_client=self)

    def revoke_access_token(self, token: "AccessToken | str") -> None:
        """Revoke an access token (by model or id): it stops working at once."""
        token_id = token.id if isinstance(token, AccessToken) else token
        self.delete(f"/api/core/management/access-tokens/{token_id}/")
