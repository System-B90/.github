"""Schedule mixin for HiveClient.

Covers calendar events, event categories/tags/taggings/attendees/instructors and
the daily review generator under ``/api/core/schedule/``. Meant only for use as
a mixin on HiveClient.
"""

import datetime
from collections.abc import Iterable
from typing import TYPE_CHECKING

from ..types.event_category import EventCategory
from ..types.schedule_event import ScheduleEvent
from .client_shared import ClientCoreMixin
from .utils import UUIDLike, resolve_item_or_uuid

if TYPE_CHECKING:
    from ..types.lesson import Lesson
    from ..types.module import Module


def _optional_str(value: UUIDLike | None) -> str | None:
    return None if value is None else str(value)


def _optional_iso(value: datetime.datetime | None) -> str | None:
    return None if value is None else value.isoformat()


class ScheduleClientMixin(ClientCoreMixin):  # pylint: disable=too-many-public-methods
    """Mixin that exposes schedule endpoints."""

    def get_schedule_events(
        self,
        *,
        start__lt: datetime.datetime | None = None,
        end__gt: datetime.datetime | None = None,
        start__gte: datetime.datetime | None = None,
        end__lte: datetime.datetime | None = None,
        lesson__id: "UUIDLike | Lesson | None" = None,
    ) -> Iterable[ScheduleEvent]:
        """Yield ``ScheduleEvent`` objects (Hive 8 filters start__lt/end__gt, older start__gte/end__lte)."""
        return self._get_core_items(
            "/api/core/schedule/events/",
            ScheduleEvent,
            start__lt=_optional_iso(start__lt),
            end__gt=_optional_iso(end__gt),
            start__gte=_optional_iso(start__gte),
            end__lte=_optional_iso(end__lte),
            lesson__id=_optional_str(resolve_item_or_uuid(lesson__id)),
        )

    def get_schedule_event(self, event_id: "UUIDLike | ScheduleEvent") -> ScheduleEvent:
        """Return a single ``ScheduleEvent`` by its id."""
        from . import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.get(f"/api/core/schedule/events/{resolve_item_or_uuid(event_id)}/")
        assert isinstance(data, dict)
        return ScheduleEvent.from_dict(data, hive_client=self)

    # --- Categories ---

    def get_event_categories(self) -> Iterable[EventCategory]:
        """Yield all event categories."""
        return self._get_core_items("/api/core/schedule/categories/", EventCategory)

    def get_event_category(
        self, category_id: "UUIDLike | EventCategory"
    ) -> EventCategory:
        """Return a single event category by id."""
        from . import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.get(
            f"/api/core/schedule/categories/{resolve_item_or_uuid(category_id)}/"
        )
        assert isinstance(data, dict)
        return EventCategory.from_dict(data, hive_client=self)

    def create_event_category(
        self,
        name: str,
        color: str,
        *,
        students_see_subject: bool = False,
        visible_to_students: bool = True,
        has_lesson: bool = False,
        hide_details_in_review: bool = False,
    ) -> EventCategory:
        """Create an event category."""
        from . import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        payload: dict[str, object] = {
            "name": name,
            "color": color,
            "students_see_subject": students_see_subject,
            "visible_to_students": visible_to_students,
            "has_lesson": has_lesson,
            "hide_details_in_review": hide_details_in_review,
        }
        return EventCategory.from_dict(
            self.post("/api/core/schedule/categories/", payload), hive_client=self
        )

    def update_event_category(
        self, category: "UUIDLike | EventCategory", **fields: object
    ) -> EventCategory:
        """Partially update an event category with the given fields."""
        from . import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        payload: dict[str, object] = {
            k: v.value if hasattr(v, "value") else v for k, v in fields.items()
        }
        data = self.patch(
            f"/api/core/schedule/categories/{resolve_item_or_uuid(category)}/", payload
        )
        assert isinstance(data, dict)
        return EventCategory.from_dict(data, hive_client=self)

    def delete_event_category(self, category_id: "UUIDLike | EventCategory") -> None:
        """Delete an event category by id."""
        self.delete(
            f"/api/core/schedule/categories/{resolve_item_or_uuid(category_id)}/"
        )

    # --- Attendees / instructors / tags / taggings (Hive <= 7.3.0 only) ---

    # --- Daily review ---

    def create_daily_review(
        self, date: datetime.date, *, show_lesson_names: bool = True
    ) -> "Module":
        """Generate (and persist) the Daily Review module for ``date``."""
        from ..types.module import Module
        from . import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.post(
            "/api/core/schedule/daily_review/",
            {"date": date.isoformat(), "show_lesson_names": show_lesson_names},
        )
        assert isinstance(data, dict)
        return Module.from_dict(data, hive_client=self)
