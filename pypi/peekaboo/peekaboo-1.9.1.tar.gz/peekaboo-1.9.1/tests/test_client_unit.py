"""
Name: test_client_unit.py
Purpose: Unit tests for the HTTP client core (peekaboo/client.py) — envelope
         unwrapping, error translation, redirect/401 handling and get_raw().
         Fully offline: every response comes from an httpx.MockTransport, so
         there is no server and no network.
Created: 2026-09-27
Author: Michael K. Steinberg
"""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

import httpx
import peekaboo.client as client_module
import pytest
from peekaboo.client import AppClient
from peekaboo.config import Config
from peekaboo.errors import ApiError, NotAuthenticatedError


def _client(
    monkeypatch, handler: Callable[[httpx.Request], httpx.Response]
) -> AppClient:
    """A AppClient whose transport answers from `handler` — no network."""
    # Grab the real constructor first: patching the module attribute would
    # otherwise make this very factory call itself.
    real_client_factory = httpx.Client

    def transport_injecting_factory(**kwargs: Any) -> httpx.Client:
        kwargs["transport"] = httpx.MockTransport(handler)
        return real_client_factory(**kwargs)

    monkeypatch.setattr(client_module.httpx, "Client", transport_injecting_factory)
    return AppClient(Config(url="http://stub.test", token="tok"))


def _json_response(payload: Any, status: int = 200) -> httpx.Response:
    return httpx.Response(status, json=payload)


# --- envelope unwrapping -------------------------------------------------------


def test_success_envelope_unwraps_to_data(monkeypatch):
    client = _client(
        monkeypatch,
        lambda request: _json_response({"status": 0, "data": {"id": 7}}),
    )

    assert client.get("/api/x") == {"id": 7}


def test_error_envelope_raises_the_route_s_error_name_and_message(monkeypatch):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            404,
            json={"status": -1, "error": {"name": "NotFound", "message": "gone"}},
        )

    client = _client(monkeypatch, handler)

    with pytest.raises(ApiError) as excinfo:
        client.get("/api/x")
    assert excinfo.value.error_name == "NotFound"
    assert excinfo.value.error_message == "gone"
    assert excinfo.value.http_status == 404


def test_error_envelope_with_a_string_error_is_wrapped_verbatim(monkeypatch):
    def handler(request: httpx.Request) -> httpx.Response:
        return _json_response({"status": -1, "error": "kaput"}, status=500)

    client = _client(monkeypatch, handler)

    with pytest.raises(ApiError) as excinfo:
        client.get("/api/x")
    # A non-object error payload is stringified under a generic name.
    assert excinfo.value.error_name == "Error"
    assert excinfo.value.error_message == "kaput"


def test_bare_json_without_a_status_key_passes_through(monkeypatch):
    """Not every endpoint speaks the envelope; a bare value is returned as-is."""
    client = _client(monkeypatch, lambda request: _json_response({"hello": 1}))

    assert client.get("/api/x") == {"hello": 1}


def test_bare_json_error_body_still_raises_http_error(monkeypatch):
    client = _client(
        monkeypatch,
        lambda request: _json_response({"detail": "nope"}, status=400),
    )

    with pytest.raises(ApiError) as excinfo:
        client.get("/api/x")
    assert excinfo.value.error_name == "HttpError"
    assert excinfo.value.http_status == 400


def test_non_json_error_body_becomes_an_http_error(monkeypatch):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(502, text="<html>Bad Gateway</html>")

    client = _client(monkeypatch, handler)

    with pytest.raises(ApiError) as excinfo:
        client.get("/api/x")
    assert excinfo.value.error_name == "HttpError"
    assert "<html>" in excinfo.value.error_message


def test_non_json_success_body_returns_raw_bytes(monkeypatch):
    """Binary routes (Excel export) come back verbatim, not through the envelope."""
    body = b"PK\x03\x04-bytes"
    client = _client(
        monkeypatch,
        lambda request: httpx.Response(200, content=body),
    )

    assert client.get("/api/x") == body


def test_json_looking_text_is_parsed_even_without_the_content_type(monkeypatch):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            content=b'{"sniffed": true}',
            headers={"Content-Type": "text/plain"},
        )

    client = _client(monkeypatch, handler)

    assert client.get("/api/x") == {"sniffed": True}


def test_none_valued_query_params_are_dropped(monkeypatch):
    seen: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["query"] = request.url.query.decode()
        return _json_response({"status": 0, "data": None})

    client = _client(monkeypatch, handler)
    client.get("/api/x", params={"keep": 1, "drop": None})

    assert seen["query"] == "keep=1"


# --- auth signalling -------------------------------------------------------------


@pytest.mark.parametrize("status", [301, 302, 307])
def test_a_redirect_means_not_logged_in(monkeypatch, status):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status, headers={"Location": "/login"})

    client = _client(monkeypatch, handler)

    with pytest.raises(NotAuthenticatedError):
        client.post("/api/x")


def test_401_means_not_logged_in(monkeypatch):
    client = _client(monkeypatch, lambda request: httpx.Response(401))

    with pytest.raises(NotAuthenticatedError):
        client.post("/api/x")


# --- network failures --------------------------------------------------------------


def test_a_connection_failure_becomes_a_network_error(monkeypatch):
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused", request=request)

    client = _client(monkeypatch, handler)

    with pytest.raises(ApiError) as excinfo:
        client.get("/api/x")
    assert excinfo.value.error_name == "NetworkError"


# --- get_raw ------------------------------------------------------------------------


def test_get_raw_parses_json_without_touching_the_envelope(monkeypatch):
    client = _client(
        monkeypatch,
        lambda request: _json_response({"status": "healthy", "checks": {}}),
    )

    assert client.get_raw("/api/health") == {"status": "healthy", "checks": {}}


def test_get_raw_redirect_also_means_not_logged_in(monkeypatch):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(302, headers={"Location": "/login"})

    client = _client(monkeypatch, handler)

    with pytest.raises(NotAuthenticatedError):
        client.get_raw("/api/health")


def test_get_raw_on_401_also_means_not_logged_in(monkeypatch):
    client = _client(monkeypatch, lambda request: httpx.Response(401))

    with pytest.raises(NotAuthenticatedError):
        client.get_raw("/api/health")


def test_get_raw_network_failure_becomes_a_network_error(monkeypatch):
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("unreachable", request=request)

    client = _client(monkeypatch, handler)

    with pytest.raises(ApiError) as excinfo:
        client.get_raw("/api/health")
    assert excinfo.value.error_name == "NetworkError"


def test_get_raw_rejects_invalid_json(monkeypatch):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            content=b"{not json",
            headers={"Content-Type": "application/json"},
        )

    client = _client(monkeypatch, handler)

    with pytest.raises(ApiError) as excinfo:
        client.get_raw("/api/health")
    assert excinfo.value.error_name == "InvalidResponse"


def test_get_raw_drops_none_params_and_keeps_the_rest(monkeypatch):
    seen: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["query"] = request.url.query.decode()
        return _json_response({})

    client = _client(monkeypatch, handler)
    client.get_raw("/api/health", params={"verbose": 1, "it": None})

    assert seen["query"] == "verbose=1"


def test_posted_json_bodies_round_trip_as_json(monkeypatch):
    seen: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["body"] = json.loads(request.content)
        return _json_response({"status": 0, "data": None})

    client = _client(monkeypatch, handler)
    client.post("/api/x", json={"a": 1})

    assert seen["body"] == {"a": 1}
