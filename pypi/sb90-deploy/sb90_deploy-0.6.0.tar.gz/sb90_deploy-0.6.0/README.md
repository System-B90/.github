# sb90-deploy

Shared release bundling, install, in-place upgrade, setup-wizard and Hive
integration flows for System-B90's app deployments (Bluz, madash, peek-a-boo).

They were three diverging copies of Bluz's bash/PowerShell scripts. They are now
one Python package, and each app keeps only a `deploy/app.json` describing
itself plus its own `setup.py` questions. The flows are ports of Bluz's
battle-tested scripts; issue numbers in comments (`Bluz#412`, …) point at
the incidents that shaped them.

## What an operator sees

A release bundle (`<app>-online-<tag>.tar.gz` / `<app>-offline-<tag>.tar.gz`)
extracts into `<app>/`:

```
./install.sh              # .\install.ps1 on Windows
./update.sh [--version vX | --package <offline or delta bundle>] [--pre-release] [--skip-backup] [-y]
./link-hive.sh            # only for a Hive on the same Docker daemon
python3 bootstrap.py setup   # re-run the .env wizard
```

The target that matters most is **an air-gapped Ubuntu 22.04 server** with
Docker Compose and apt-installable Python:

1. The shims need any Python ≥ 3.6 and run `bootstrap.py`, which is stdlib-only
   and 3.6-compatible.
2. `bootstrap.py` finds a Python ≥ 3.10 (the stock `python3` on 22.04) and builds
   `.venv` from the bundle's `wheels/` with `--no-index`. If Ubuntu's stripped
   `ensurepip` stops `python3 -m venv` (no `python3-venv`), it falls back to
   `--without-pip` plus the vendored pip wheel.
3. Everything else runs inside `.venv`, as `python -m sb90_deploy <command>`.

The venv is rebuilt when it is missing, too old, or out of date with the
bundle's wheels, so an upgrade that ships new wheels also refreshes the tools.

## Flows

| Command | Module | Was |
| --- | --- | --- |
| `install` | `install.py` | `install.sh`, `install.ps1` |
| `update` | `upgrade.py` | `update.sh` (Bluz; peek-a-boo's copy) |
| `link-hive` | `linkhive.py` | `link-hive.sh`, `link-hive.ps1` |
| `setup` | the app's `setup.py` + `wizard.py`, `tls.py`, `hive.py` | each app's `setup.py` |
| `bundle` | `bundle.py` | each workflow's `craft-release` shell steps |
| `delta` | `delta.py`, `archive.py` | new: see [Delta packages](#delta-packages) |
| `publish` | `release.py` | each repo's `scripts/publish.py` / `bump_version.py` |

## `app.json`

```jsonc
{
  "name": "bluz",                      // container/image-archive prefix
  "display_name": "Bluz",
  "env_prefix": "BLUZ",                // BLUZ_VERSION, BLUZ_BIND_IP, BLUZ_HTTP(S)_PORT,
                                       // and operator overrides BLUZ_COMPOSE_FILE,
                                       // BLUZ_COMPOSE_OVERLAY, BLUZ_ENV_FILE,
                                       // BLUZ_RELEASE_REPO, BLUZ_HEALTH_RETRIES,
                                       // BLUZ_BACKUP_SCRIPT, BLUZ_BACKUP_DIR
  "release_repo": "System-B90/Bluz",
  "roll": ["ui", "sessions", "proxy"], // upgrade order: ui first (migrations), proxy last
  "health": {"service": "ui", "url": "http://127.0.0.1:3000/api/health"},
  "containers": {"ui": "bluz-ui", "proxy": "bluz-proxy"},
  "backup": {"sh": "backup/bluz-backup.sh", "ps1": "backup/bluz-backup.ps1",
             "restore_sh": "backup/bluz-restore.sh", "restore_ps1": "backup/bluz-restore.ps1",
             "root": "/var/backups/bluz",
             "root_windows": "%ProgramData%\bluz\backups"},          // omit for stateless apps
  "required_files": [],                // must exist after setup.py (peek-a-boo's token file)
  "state": ["nginx/ssl"],              // host state an upgrade never overwrites
  "venv_packages": ["bluz"],       // operator tooling installed into .venv
  "post_install": ["..."],             // extra lines printed after install
  "bundle": {
    "dir": "bluz",
    "files": {"docker-compose.yml": "deploy/docker-compose.release.yml",
              "docker-compose.hive-local.yml": "deploy/docker-compose.hive-local.yml",
              "setup.py": "scripts/setup.py"},
    "local_wheels": ["cli/dist/*.whl"]
  }
}
```

The bundle's images are **read from the release compose file**. Images tagged
with `${<PREFIX>_VERSION}` are the app's own; the rest (Postgres, Mongo,
nginx) are saved too, since an air-gapped host has no other way to get them.

## A setup.py

```python
from sb90_deploy.wizard import Wizard

w = Wizard()  # reads app.json + existing .env
domain = w.domain(example="bluz.example.com")
w.ports()
w.tls(domain, ssl_dir="nginx/ssl")
hive_url = w.ask("NEXT_PUBLIC_HIVE_URL", "Hive URL", "https://hive.org")
w.generated("NEXTAUTH_SECRET")
w.sso(hive_url)  # browser → password → retry → MANUAL_ENTRY_REQUIRED
w.write()  # keeps keys it does not own
```

## CI

Bundling needs the `bundle` extra (`pip install "sb90-deploy[bundle]"`): wheels are
resolved per target platform and Python with `uv pip compile`, because `pip download
--platform/--python-version` still evaluates markers such as `python_version < "3.11"` and
`sys_platform == "linux"` against the machine doing the bundling. Extra wheel sources:
`SB90_BUNDLE_FIND_LINKS=<dir>[<os.pathsep><dir>...]`.


In an app's release workflow, use the org composite action:

```yaml
- uses: System-B90/.github/actions/craft-release@main
  with:
      tag: ${{ github.ref_name }}
```

## Delta packages

A full offline bundle is every image, every release (Bluz: ~650 MB). A delta
`<dir>-delta-<tag>.tar.zst` carries only what the host lacks (Bluz v1.6.1 → v1.6.2:
**0.2 MB**). One file serves every base it was built against, like a cumulative
Windows update — the operator never chains patches.

```
python -m sb90_deploy delta --target dist/<dir>-offline-v1.3.0.tar.gz \
    --base <dir>-offline-v1.2.1.tar.gz --base <dir>-offline-v1.2.0.tar.gz --out dist
./update.sh --package <dir>-delta-v1.3.0.tar.zst       # on the host
```

How it stays small, per image layer of the target:

| Layer | Shipped |
| --- | --- |
| On every base (same diffID) | nothing — the host has it loaded |
| Changed (counterpart at the same position in a base) | `zstd --patch-from` the base layer, `--ultra -22 --long` — one patch per distinct base layer |
| New (no counterpart), or patches would be bigger | the layer, `--ultra -22 --long` |

Wheels ship only when some base lacks them; bundle files ship whole (a few KB).

On the host, `update --package <delta>` checks the running release is a listed
base, `docker save`s its running images, rebuilds every target image archive
and `wheels/`, verifies each layer against its diffID and each wheel against its
sha256, then carries on as a normal offline upgrade. Any mismatch stops it before
anything is touched, naming the full offline package to use instead.

Limits:

* In-place upgrades only: the host must run a listed base, with its images still loaded.
* A base bundled with sb90-deploy < 0.6.0 is skipped — its hosts upgrade with
  their own older tools, which cannot read a delta. Upgrade those once with the
  full offline package.
* Crafting needs each base's offline bundle and RAM for one base + target layer.

In CI, the `craft-release` action builds it with `delta-bases: <n>` (the `n`
newest earlier stable releases).

## Publishing a release

Maintainers cut a release from a clean checkout of the release branch:

```
python -m sb90_deploy publish [--bump patch|minor|major] [--rc/--no-rc] [--version X.Y.Z] [-y] [--dry]
```

It takes the latest `v*` tag (an rc sorts below its release), picks the next
version, writes it into every file in app.json's `release.manifests`, commits
`chore: bump version to X`, and pushes the branch and the annotated tag. That tag
is what the release workflow and `bundle` build from. `--dry` commits locally
and pushes nothing.

```jsonc
"release": {
  "branches": ["master"],                 // default ["master"]
  "manifests": [
    "package.json",                       // first "version" field
    {"path": "package-lock.json", "count": 2},   // root + packages[""]
    {"path": "cli/app_cli/__init__.py", "format": "python"}  // __version__
  ]
}
```

## Development

```
python -m venv .venv && .venv/bin/pip install -e ".[dev,lint]" --extra-index-url https://system-b90.github.io/.github/pypi/
pre-commit install        # ruff check --fix + ruff format on every commit, at CI's pinned version
pytest -q && ruff check . && ruff format --check .
vermin -t=3.6- --no-tips --violations sb90_deploy/templates/bootstrap.py
```

The tests drive the real flows against a stub `docker` (`SB90_DOCKER`), so no
daemon is needed.
