"""
Name: alerts.py
Purpose: `madash event-alerts` — the event-end alerts (/api/event-end-alerts):
         a Mattermost post 3 minutes before each Bluz schedule event ends and
         again when it ends. Show, change and clear the settings.
Created: 2026-11-01
Author: Michael K. Steinberg
"""

from __future__ import annotations

from typing import Any

import typer

from madash.commands._common import show
from madash.context import state
from madash.output import abort, success

app = typer.Typer(
    help="Event-end alerts to Mattermost, read from the Bluz schedule.",
    no_args_is_help=True,
)

_PATH = "/api/event-end-alerts"


def _summary(view: dict[str, Any]) -> dict[str, Any]:
    status = view.get("status") or {}
    return {
        "enabled": view.get("enabled"),
        "channel": view.get("channelName") or view.get("channelId") or None,
        "mattermostToken": "saved" if view.get("hasMattermostToken") else "missing",
        "bluzToken": "saved" if view.get("hasBluzToken") else "missing",
        "bluzUser": view.get("bluzUser"),
        "configuredBy": view.get("configuredBy"),
        "lastFetchAt": status.get("lastFetchAt"),
        "lastSentAt": status.get("lastSentAt"),
        "lastError": status.get("lastError"),
        "upcoming": [
            f"{u.get('endTime')} {', '.join(u.get('names') or [])}"
            for u in status.get("upcoming") or []
        ],
    }


def _show(view: dict[str, Any]) -> None:
    show(view if state.as_json else _summary(view), title="Event-end alerts")


@app.command("show")
def show_settings() -> None:
    """Show the settings (never the tokens), status and the next end times."""
    with state.client() as client:
        _show(client.get(_PATH) or {})


@app.command("set")
def set_settings(
    channel: str = typer.Option(
        None, "--channel", help="Mattermost channel id. Default: keep the current one."
    ),
    mattermost_token: str = typer.Option(
        None,
        "--mattermost-token",
        envvar="MADASH_MATTERMOST_TOKEN",
        help="Mattermost bot access token. Default: keep the saved one.",
    ),
    bluz_token: str = typer.Option(
        None,
        "--bluz-token",
        envvar="MADASH_BLUZ_TOKEN",
        help="Bluz personal access token (bluz_pat_..., ReadOnly is enough). Default: keep the saved one.",
    ),
    enable: bool = typer.Option(
        None, "--enable/--disable", help="Turn the alerts on or off. Default: on."
    ),
) -> None:
    """Change the settings. Unset options keep their current value; the server
    checks both tokens before turning the alerts on."""
    with state.client() as client:
        current = client.get(_PATH) or {}
        channel_id = channel if channel is not None else current.get("channelId", "")
        payload: dict[str, Any] = {
            "enabled": True if enable is None else enable,
            "channelId": channel_id,
        }
        if mattermost_token:
            payload["mattermostToken"] = mattermost_token
        if bluz_token:
            payload["bluzToken"] = bluz_token
        if payload["enabled"] and not channel_id:
            abort("Pass --channel: no Mattermost channel is set yet.")
        view = client.put(_PATH, json=payload) or {}
    if state.as_json:
        show(view)
    else:
        success(
            "Event-end alerts " + ("enabled." if view.get("enabled") else "disabled.")
        )


@app.command("clear")
def clear_settings() -> None:
    """Forget the settings and both tokens on the server."""
    with state.client() as client:
        client.delete(_PATH)
    success("Event-end alert settings cleared.")
