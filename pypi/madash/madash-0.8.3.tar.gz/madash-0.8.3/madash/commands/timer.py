"""
Name: timer.py
Purpose: `madash timer` — the live timer (/timer, /api/live-timer): what is
         running on the Bluz schedule right now (every parallel event) and the
         time left, plus a live countdown in the terminal.
Created: 2026-11-03
Author: Michael K. Steinberg
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

import typer
from rich.console import Group
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from madash.commands._common import show
from madash.context import state
from madash.errors import CliError
from madash.output import abort, console

app = typer.Typer(
    help="The live timer: time left in the Bluz events running now.",
    no_args_is_help=True,
)

_PATH = "/api/live-timer"
_NOTE_PATH = "/api/live-timer/note"
# Same as the page: dramatic for the last 3 minutes (the end-alert warning).
DRAMATIC_SECONDS = 3 * 60
# Same as the page: the schedule is re-read once a minute.
FETCH_INTERVAL_SECONDS = 60.0
_UNNAMED = "אירוע ללא שם"


@dataclass
class Running:
    """Events running together that end in the same minute: one countdown."""

    end: datetime
    start: datetime
    names: list[str]


def _parse(iso: str) -> datetime:
    return datetime.fromisoformat(iso.replace("Z", "+00:00"))


def _now() -> datetime:
    return datetime.now(UTC)


def running_groups(events: list[dict[str, Any]], now: datetime) -> list[Running]:
    """Mirrors runningGroups in src/api-shared/live-timer.ts."""
    groups: dict[datetime, Running] = {}
    for event in events:
        start = _parse(event["startTime"])
        end = _parse(event["endTime"]).replace(second=0, microsecond=0)
        if not (start <= now < end):
            continue
        group = groups.setdefault(end, Running(end=end, start=start, names=[]))
        group.start = min(group.start, start)
        name = (event.get("name") or "").strip() or _UNNAMED
        if name not in group.names:
            group.names.append(name)
    return sorted(groups.values(), key=lambda g: g.end)


def seconds_left(end: datetime, now: datetime) -> int:
    return max(0, math.ceil((end - now).total_seconds()))


def format_countdown(total: int) -> str:
    """`M:SS` under an hour, `H:MM:SS` from an hour up — like the page."""
    hours, rest = divmod(max(0, total), 3600)
    minutes, seconds = divmod(rest, 60)
    return f"{hours}:{minutes:02}:{seconds:02}" if hours else f"{minutes}:{seconds:02}"


def _clock(moment: datetime) -> str:
    return moment.astimezone().strftime("%H:%M")


def fetch_view() -> dict[str, Any]:
    with state.client() as client:
        return client.get(_PATH) or {}


def _explain(view: dict[str, Any]) -> str | None:
    """Why there is nothing to offer, if it is not just a quiet schedule."""
    if not view.get("bluzUrlConfigured"):
        return "BLUZ_URL is not set on the server."
    if not view.get("hasBluzToken"):
        return "No Bluz access token is saved: set one with `madash event-alerts set --bluz-token`."
    return view.get("error")


@app.command("now")
def now_running() -> None:
    """List the events running now, grouped by end time, with the time left."""
    view = fetch_view()
    if state.as_json:
        show(view)
        return
    problem = _explain(view)
    if problem:
        abort(problem)
    now = _now()
    rows = [
        {
            "event": " · ".join(g.names),
            "start": _clock(g.start),
            "end": _clock(g.end),
            "left": format_countdown(seconds_left(g.end, now)),
        }
        for g in running_groups(view.get("events") or [], now)
    ]
    if not rows:
        console.print("Nothing is running on the Bluz schedule right now.")
        return
    show(rows, title="Running now")


def _frame(group: Running | None, now: datetime, error: str | None):
    if group is None:
        body = Text("Nothing is running on the Bluz schedule right now.", style="dim")
        return Panel(body, title="Live timer")
    left = seconds_left(group.end, now)
    style = "bold white on red" if 0 < left <= DRAMATIC_SECONDS else "bold"
    if left == 0:
        style = "bold red blink"
    parts = [
        Text(" · ".join(group.names), style="bold"),
        Text(format_countdown(left), style=style, justify="center"),
        Text(f"ends {_clock(group.end)}", style="dim"),
    ]
    if error:
        parts.append(Text(f"last read failed: {error}", style="yellow"))
    return Panel(Group(*parts), title="Live timer")


def watch_loop(
    *,
    pick: int,
    fetch=None,
    clock=None,
    sleep=None,
    iterations: int | None = None,
) -> None:
    """Redraw the countdown every second, re-reading the schedule each minute.

    Follows the `pick`-th group (1 = ends soonest) of what is running; when it
    ends, it holds 0:00 for a minute, then moves on to what is running then.
    `fetch`, `clock`, `sleep` and `iterations` exist for tests.
    """
    fetch = fetch or fetch_view
    clock = clock or _now
    sleep = sleep or time.sleep
    events: list[dict[str, Any]] = []
    error: str | None = None
    fetched_at: datetime | None = None
    target: Running | None = None
    with Live(console=console, refresh_per_second=4, transient=False) as live:
        count = 0
        while iterations is None or count < iterations:
            count += 1
            now = clock()
            if (
                fetched_at is None
                or (now - fetched_at).total_seconds() >= FETCH_INTERVAL_SECONDS
            ):
                fetched_at = now
                try:
                    view = fetch()
                    events, error = view.get("events") or [], _explain(view)
                except CliError as exc:
                    error = str(exc)
            if target is None or (now - target.end).total_seconds() >= 60:
                groups = running_groups(events, now)
                target = groups[pick - 1] if len(groups) >= pick else None
            live.update(_frame(target, now, error))
            if iterations is None or count < iterations:
                sleep(1.0)


@app.command("watch")
def watch(
    pick: int = typer.Option(
        1,
        "--pick",
        "-p",
        min=1,
        help="Which running group to follow, by end time (1 = ends soonest). See `madash timer now`.",
    ),
) -> None:
    """Count down live to the end of an event running now."""
    try:
        watch_loop(pick=pick)
    except KeyboardInterrupt:
        raise typer.Exit() from None


def _epoch_ms(moment: datetime) -> int:
    return round(moment.timestamp() * 1000)


def _countdown_end(pick: int) -> int:
    """The end (epoch ms, the page's `?until=`) of the `pick`-th group running now."""
    view = fetch_view()
    groups = running_groups(view.get("events") or [], _now())
    if len(groups) < pick:
        problem = _explain(view)
        abort(
            problem
            or f"Only {len(groups)} group(s) running now; see `madash timer now`, or pass --until."
        )
    return _epoch_ms(groups[pick - 1].end)


@app.command("note")
def note(
    text: str | None = typer.Argument(
        None, help="The new note. Leave out to show the current one."
    ),
    pick: int = typer.Option(
        1,
        "--pick",
        "-p",
        min=1,
        help="Which running group's countdown, by end time (1 = ends soonest). See `madash timer now`.",
    ),
    until: int | None = typer.Option(
        None,
        "--until",
        help="The countdown's end in epoch ms (the page's ?until=), instead of --pick.",
    ),
    clear: bool = typer.Option(False, "--clear", help="Remove the note."),
) -> None:
    """Show or set the note under a countdown — every screen showing it updates live."""
    if clear and text is not None:
        abort("Pass a note or --clear, not both.")
    end = until if until is not None else _countdown_end(pick)
    with state.client() as client:
        if text is None and not clear:
            result = client.get(_NOTE_PATH, params={"until": end}) or {}
        else:
            result = (
                client.put(
                    _NOTE_PATH, json={"until": end, "text": "" if clear else text}
                )
                or {}
            )
    if state.as_json:
        show(result)
        return
    current = result.get("text") or ""
    console.print(current if current else "(no note)")
