"""Public package for the pyhive distribution."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .core.aliases import install as _install_aliases

_install_aliases()

if TYPE_CHECKING:
    from pyhive_backend_gen4.client import HiveClient
else:
    from .core.shell import HiveClient

__all__ = ["HiveClient"]
