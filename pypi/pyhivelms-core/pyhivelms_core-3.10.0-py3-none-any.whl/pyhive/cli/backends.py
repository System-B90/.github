"""
Name: backends.py
Purpose: ``pyhive backends``: list, add, remove and pick the Hive API backends,
    plus the first-run picker (#42 phase 5).
Created: 2026-11-25

Backends are shown by the Hive versions they serve, never by generation. The
newest one is always installed and cannot be removed. Installing runs pip (or
``pipx inject``) once; where PyHive must not (uv tool, PEP 668), it prints the
command instead.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Annotated

import typer

from pyhive.cli.base import PyHiveTyper
from pyhive.cli.formatter import print_error_and_exit, print_info, print_result
from pyhive.cli.state import state
from pyhive.core.backends import (
    NO_PROMPT_ENV,
    BackendStatus,
    plan,
    run,
    status_for,
    statuses,
)
from pyhive.src.api_versions import UnverifiedHiveVersionError

backends_app = PyHiveTyper(
    help="Choose which Hive versions this PyHive can talk to (one backend per API family)."
)

MARKER_NAME = "backends.toml"


def marker_path() -> Path:
    """Where the first-run picker records that it ran."""
    import platformdirs  # pylint: disable=import-outside-toplevel

    return Path(platformdirs.user_config_dir("pyhive")) / MARKER_NAME


def _as_dict(status: BackendStatus) -> dict[str, object]:
    return {
        "hive_versions": list(status.versions),
        "installed": status.installed,
        "newest": status.newest,
        "distribution": status.distribution,
    }


def _resolve(hive_versions: list[str]) -> list[BackendStatus]:
    found: dict[str, BackendStatus] = {}
    for hive_version in hive_versions:
        try:
            status = status_for(hive_version)
        except UnverifiedHiveVersionError as exc:
            print_error_and_exit(str(exc))
        found[status.generation] = status
    return list(found.values())


def _apply(to_add: list[BackendStatus], to_remove: list[BackendStatus]) -> None:
    for distributions, remove in (
        ([s.distribution for s in to_add], False),
        ([s.distribution for s in to_remove], True),
    ):
        if not distributions:
            continue
        step = plan(distributions, remove=remove)
        if not step.runnable:
            print_info(f"{step.reason}. Run this yourself:")
            typer.echo(f"  {step.shell}")
            continue
        print_info(f"Running: {step.shell}")
        if run(step) != 0:
            print_error_and_exit(
                "The command failed (PyHive does not retry). Run it yourself, "
                f"for example when back online:\n  {step.shell}",
                {"command": list(step.command)},
            )


@backends_app.command(name="list")
def list_backends() -> None:
    """List the Hive versions PyHive supports and whether each is installed."""
    found = statuses()

    def text_output() -> None:
        for status in found:
            mark = "installed" if status.installed else "not installed"
            newest = " (newest, always installed)" if status.newest else ""
            typer.echo(f"Hive {status.label}: {mark}{newest}")

    print_result({"backends": [_as_dict(s) for s in found]}, text_output)


@backends_app.command(name="add")
def add_backends(
    hive_versions: Annotated[
        list[str], typer.Argument(help="Hive versions to support, e.g. 7.3.0")
    ],
) -> None:
    """Install the backends serving the given Hive versions."""
    wanted = [s for s in _resolve(hive_versions) if not s.installed]
    if not wanted:
        print_result({"added": []}, lambda: typer.echo("Already installed."))
        return
    _apply(wanted, [])
    print_result(
        {"added": [s.distribution for s in wanted]},
        lambda: typer.echo(
            "Added support for Hive " + "; ".join(s.label for s in wanted)
        ),
    )


@backends_app.command(name="remove")
def remove_backends(
    hive_versions: Annotated[
        list[str], typer.Argument(help="Hive versions to stop supporting")
    ],
) -> None:
    """Uninstall the backends serving the given Hive versions (never the newest)."""
    chosen = _resolve(hive_versions)
    if any(s.newest for s in chosen):
        print_error_and_exit("The newest Hive version's backend cannot be removed.")
    doomed = [s for s in chosen if s.installed]
    _apply([], doomed)
    print_result(
        {"removed": [s.distribution for s in doomed]},
        lambda: typer.echo(
            "Removed support for Hive " + "; ".join(s.label for s in doomed)
            if doomed
            else "Nothing to remove."
        ),
    )


def pick(found: list[BackendStatus]) -> tuple[list[BackendStatus], list[BackendStatus]]:
    """Ask which backends to keep; return (to add, to remove). Needs a terminal."""
    import questionary  # pylint: disable=import-outside-toplevel

    choices = [
        questionary.Choice(
            f"Hive {s.label}",
            value=s.generation,
            checked=s.installed or s.newest,
            disabled="newest, always installed" if s.newest else None,
        )
        for s in found
    ]
    answer = questionary.checkbox(
        "Which Hive versions should PyHive support?", choices=choices
    ).ask()
    if answer is None:
        raise typer.Abort()
    keep = set(answer) | {s.generation for s in found if s.newest}
    to_add = [s for s in found if s.generation in keep and not s.installed]
    to_remove = [s for s in found if s.generation not in keep and s.installed]
    return to_add, to_remove


def _write_marker(found: list[BackendStatus]) -> None:
    path = marker_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    chosen = ", ".join(f'"{s.generation}"' for s in found if s.installed)
    path.write_text(
        "# Written by PyHive's first-run backend picker. Delete it to be asked again.\n"
        f"prompted = true\ninstalled = [{chosen}]\n",
        encoding="utf-8",
    )


@backends_app.command(name="pick")
def pick_backends() -> None:
    """Choose interactively which Hive versions to support."""
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        print_error_and_exit(
            "`pyhive backends pick` needs a terminal; use `pyhive backends add/remove`."
        )
    to_add, to_remove = pick(statuses())
    _apply(to_add, to_remove)
    _write_marker(statuses())


def should_prompt_first_run(argv: list[str]) -> bool:
    """Whether this CLI run shows the first-run picker."""
    if os.environ.get(NO_PROMPT_ENV) == "1" or state.use_json or "--json" in argv:
        return False
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return False
    if any(arg in {"backends", "--help", "-h", "version", "docs"} for arg in argv):
        return False
    if marker_path().exists():
        return False
    return not all(s.installed for s in statuses())


def first_run_picker(argv: list[str]) -> None:
    """Offer the picker once, the first time the interactive CLI runs with backends missing."""
    if not should_prompt_first_run(argv):
        return
    print_info(
        f"PyHive can support more Hive versions. Choose now (set {NO_PROMPT_ENV}=1 "
        "to never ask; `pyhive backends pick` to change later)."
    )
    to_add, to_remove = pick(statuses())
    _apply(to_add, to_remove)
    _write_marker(statuses())
