"""One module per exact Hive version: ``from pyhive.hive.v8_0_4 import HiveClient`` (#42 phase 4).

Each ``v<X_Y_Z>`` resolves (pyhive/core/aliases.py) to the ``hive_api`` module of the
backend serving that Hive release; versions served by one backend share one module.
Type checkers read the ``v<X_Y_Z>.pyi`` stubs rendered from hive_versions.toml.
"""
