# Generated from hive_versions.toml by scripts/generate_versions.py. Do not edit.
"""Type-checker view of the Hive API module for gen3 releases."""

# pylint: disable=wildcard-import,unused-wildcard-import,useless-import-alias
from pyhive_backend_gen3.hive_api import *
from pyhive_backend_gen3.hive_api import __all__ as __all__
