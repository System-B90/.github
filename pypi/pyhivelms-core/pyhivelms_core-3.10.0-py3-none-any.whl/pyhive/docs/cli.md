# CLI reference

`pyhive` is installed with the `PyHiveLMS` package. It is built on the
[Python SDK](sdk.md), so anything a command does, a script can do too. The
CLI covers the everyday reads and deletes; the SDK covers everything else.

```bash
pyhive --help              # command groups
pyhive programs --help     # one group
pyhive docs show cli       # this page, in the terminal
```

## Command line shape

```text
pyhive GROUP COMMAND [ARGS] [OPTIONS]
```

These options work anywhere on the line: before the group, between the group
and the command, or after the command. `pyhive --json programs list`,
`pyhive programs --json list` and `pyhive programs list --json` are the same.

| Option                 | What it does                                                        |
| ---------------------- | ------------------------------------------------------------------- |
| `-u`, `--username`     | Hive username (with `-p`)                                           |
| `-p`, `--password`     | Hive password (with `-u`)                                           |
| `-t`, `--token`        | Hive personal access token (`hive_pat_...`) or API token            |
| `--json`               | Print one JSON document on stdout instead of text                   |
| `--cache-token`        | Save the server and token in the OS keyring for later calls         |
| `--hive-url URL`       | Server to talk to. Default: the cached one, else `https://hive.org` |
| `--verify/--no-verify` | Verify TLS certificates. Default `--no-verify`                      |

!!! note "A command's own option comes first"
    `pyhive users create USERNAME --password PW` sets the **new account's**
    password. To sign in with a password on that command, put `-p` (or
    `--password`) before `users`. Anything after a bare `--` is passed through
    untouched.

## Signing in

Sign in once:

```bash
pyhive auth login
```

It asks for the Hive URL (Enter keeps the one shown), opens the browser on
Hive's sign-in page, and saves the URL, the access token and the refresh token
in the OS keyring (service `pyhive_cli`). Later commands talk to that server by
default, sign in without a browser, and refresh the access token when it
expires. Anyone who can read your keyring can act as you, so only do this on
your own machine.

```bash
pyhive auth login --hive-url https://hive.example   # no prompt
pyhive auth login --token hive_pat_...              # store a personal access token instead (no browser)
pyhive auth status                                  # cached server, and whether (and which kind of) token is cached
pyhive auth logout                                  # forget the server and the tokens
```

`auth status` only reads the keyring. It does not check that the token still
works.

`auth login --token` takes a personal access token made in Hive (account menu,
Access Tokens). It checks the token against the server, then caches it the same
way; it has no refresh token and works until it expires or is revoked. Use this
on machines without a browser.

Every command that talks to Hive picks the first credentials it finds:

1. `-u USER -p PASS`
2. `-t TOKEN`
3. the `HIVE_ACCESS_TOKEN` environment variable
4. the keyring cache from `pyhive auth login` or `--cache-token`, if it was
   saved for the same server the command talks to
5. otherwise, SSO: a browser opens on Hive's sign-in page and the command
   waits for you to finish

`--cache-token` on any command saves the server it used and the token it ended
up with, the same way `auth login` does. Without `--hive-url`, commands use the
cached server, or `https://hive.org` if none is cached. Giving `--hive-url` for
a different server ignores the cached token instead of sending it there.

A token from `-t` or `HIVE_ACCESS_TOKEN` cannot be refreshed. A personal access
token (`hive_pat_...`) lasts until the expiry chosen when it was made, so it is
the one to use for scripts and CI; a token from `pyhive token` expires soon, then
get a new one.

## Output

Text mode prints progress lines and aligned lists for people. With `--json`,
stdout holds exactly one JSON document:

| Command kind | JSON on stdout                                               |
| ------------ | ------------------------------------------------------------ |
| `list`       | `{"programs": [{...}, ...]}` — key is the group name          |
| `get`        | `{"program": {...}}` — key is the singular                    |
| `delete`     | `{"deleted_program_id": 2, "status": "success"}`              |
| error        | nothing on stdout; `{"error": "...", "details": "..."}` on **stderr** |

The exit code is `0` on success and `1` on any error. Lists are sorted by `id`.

Objects carry every field Hive returns, under Hive's own field names. Related
objects appear as ids: `"program": 2`, `"mentor": 1`, `"classes": [1, 3]`.
(The SDK models expose the same values as `program_id`, `mentor_id`,
`class_ids`.)

```bash
pyhive --json subjects list | jq -r '.subjects[] | "\(.id)\t\(.symbol)\t\(.name)"'
pyhive --json users list | jq '[.users[] | select(.clearance == 1)] | length'   # students
```

## Course content

Programs contain subjects, subjects contain modules, modules contain exercises.

```bash
pyhive programs list
pyhive programs get 2
pyhive programs delete 2

pyhive subjects list
pyhive subjects get 12
pyhive subjects delete 12        # also deletes the subject's modules and exercises

pyhive modules list
pyhive modules get 40
pyhive modules delete 40

pyhive exercises list
pyhive exercises get 7
pyhive exercises delete 7
```

Running a group with no command runs its `list`: `pyhive subjects` is
`pyhive subjects list`.

!!! danger "Deletes do not ask for confirmation"
    `delete` commands run immediately and cannot be undone.

The CLI does not create or edit course content. Use the SDK:
`program.create_subject(...)`, `subject.create_module(...)`,
`module.create_exercise(...)` — see the
[`build_module` example](examples.md#build_module).

## Assignments

An assignment is one student's copy of one exercise.

```bash
pyhive assignments list
pyhive assignments get 1234
```

`list` returns every assignment the account can see. To filter (by student,
mentor, module, subject…), use `client.get_assignments(...)` in the SDK.

## Classes

A class is either a room or a student group (`"type": "Room"` /
`"Student Group"`).

```bash
pyhive classes list
pyhive classes get 3
pyhive classes delete 3

# Assign to every student in the class:
pyhive classes set-queue 3 12          # class queue 12; `none` clears it
pyhive classes set-lesson 3 6c14e49d-ab72-4675-8279-2aa840d6a95b   # or `none`
pyhive classes clear-override-queues 3 # Hive 6.1.1+
```

`set-lesson` applies the lesson's queue rules: each student a rule matches
gets that rule's queue as their class queue. Find lesson ids with
`pyhive lessons list` (UUIDs on Hive 7.3+, integers before). Setting the
lesson to `none` keeps the queues it assigned.

## Users

```bash
pyhive users list
pyhive users delete 15
pyhive users set-queues 15 --queue 12 --user-queue none --enable-queue
pyhive users create jdoe --password 'S3cret!' --clearance checker --gender female \
    --first-name Jane --last-name Doe
```

`users create` options:

| Option                          | Values                                                                        |
| ------------------------------- | ----------------------------------------------------------------------------- |
| `USERNAME`                      | required argument                                                             |
| `--password`                    | prompted (hidden) if omitted — always pass it in scripts                      |
| `--clearance`                   | required: `HANICH` (student), `CHECKER`, `SEGEL` (staff), `ADMIN`, any case  |
| `--gender`                      | required: `MALE`, `FEMALE`, `NONBINARY`                                       |
| `--status`                      | `PRESENT` (default), `RAISED_HAND`, `TOILET`, `HOME`, `MEDICAL`, …            |
| `--number`                      | identification number                                                         |
| `--first-name`, `--last-name`   |                                                                               |
| `--avatar-filename`             |                                                                               |
| `--teacher/--no-teacher`        |                                                                               |
| `--confirmed/--no-confirmed`    |                                                                               |

On success the JSON is `{"user": {...}, "status": "created"}`.

!!! note "Students need the SDK"
    A student (`HANICH`) must have a program and a number, and `users create`
    has no `--program` option, so it can only create staff.
    Create students with `client.create_student(username, password, gender,
    number=..., program=...)`.

`users set-queues` sets a student's three queue slots, each to a queue id or
`none` (clears it); a slot you leave out keeps its value:

| Option                                        | Sets                                        |
| --------------------------------------------- | ------------------------------------------- |
| `--queue ID\|none`                            | the class queue                             |
| `--user-queue ID\|none`                       | the student's own queue                     |
| `--override-queue ID\|none`                   | the override queue                          |
| `--disable-queue` / `--enable-queue`          | pauses or resumes the class queue           |
| `--disable-user-queue` / `--enable-user-queue` | pauses or resumes the student's own queue  |

## Queues

A queue belongs to exactly one owner: a module (shared) or one user (their own
queue). Its items are exercises, nested queues, or a module's exercises, in
order from position 0.

```bash
pyhive queues list [--user 15 | --module 7 | --class 3] [--user-queues | --module-queues]
pyhive queues get 12
pyhive queues create "Week 3" --module 7        # or --user 15; --description TEXT
pyhive queues update 12 --name "Week 3a" --description "..."
pyhive queues duplicate 12 "Week 3 (copy)"      # same owner, same items
pyhive queues delete 12

pyhive queues items 12                          # the items, in order
pyhive queues add-item 12 --exercise 40         # or --nested-queue 13 / --module 7
pyhive queues add-item 12 --nested-queue 13 --order 0 --rule "wait for done" --disabled
pyhive queues update-item 12 51 --rule choose --enabled --no-continue-on-redo
pyhive queues move-item 12 51 0                 # 0-based; the rest are renumbered
pyhive queues expand-item 12 51                 # replace a nested queue with its items
pyhive queues remove-item 12 51
```

`--rule` takes `Choose`, `Wait For Submitted`, `Wait For AutoChecks` or
`Wait For Done` (any case). `add-item` appends unless `--order` is given;
`update-item` changes only what you pass and never the position (use
`move-item`). Hive refuses (HTTP 400) to nest a user's own queue in a module
queue, to duplicate an empty queue, and to add a module with no exercises.

## Lessons

```bash
pyhive lessons list [--module 7]        # ids for `classes set-lesson`
```

## Sign-in helpers

```bash
pyhive token                        # SSO in the browser, prints the access token
pyhive --json token                 # {"access_token", "refresh_token", "expires_at"}
pyhive token --cache-token          # ...and saves the server and both tokens, like `auth login`

pyhive register "My service" http://localhost:5000/api/auth/callback/hive
```

`register` creates an SSO (OAuth) client application on Hive and prints its
`client_id` and `client_secret`, for building another service that signs in
with Hive. It needs an account allowed to manage SSO applications.

## Versions

```bash
pyhive version       # this PyHive's version
pyhive versions      # every Hive release this PyHive is verified against
```

PyHive checks the server's version when it connects and refuses a Hive
release it has not been verified against. Upgrade PyHive when the server is
newer; from the SDK, `skip_version_check=True` tries anyway.

### Which Hive versions are installed

Each family of Hive releases that share an API is served by its own small
package (a *backend*). `pip install PyHiveLMS` installs all of them; these
commands add or drop them one at a time:

```bash
pyhive backends list                 # every supported Hive version, installed or not
pyhive backends add 7.3.0            # install the package serving Hive 7.3.0
pyhive backends remove 6.4.0 7.3.0   # uninstall those (never the newest Hive's)
pyhive backends pick                 # interactive checklist (needs a terminal)
```

`add` and `remove` run `pip` (or `pipx inject` under pipx) once and never
retry. Under `uv tool`, or a Python that forbids installs (PEP 668), they print
the command to run instead. The first interactive run with a backend missing
offers the checklist once; `PYHIVE_NO_BACKEND_PROMPT=1`, `--json` or a
non-terminal skips it, and `pyhive backends pick` brings it back.

## Docs and examples

The documentation and example scripts ship inside the package.

```bash
pyhive docs list                    # list the pages (also plain `pyhive docs`)
pyhive docs show sdk                # print a page as Markdown
pyhive docs path                    # where the files are
pyhive docs install-skill           # install them as the Claude Code skill `pyhive`
pyhive docs install-skill --project .   # ...into ./.claude/skills instead of ~/.claude/skills

pyhive examples list                # list the example scripts (also plain `pyhive examples`)
pyhive examples show program_tree   # print one
pyhive examples run program_tree 2  # run one against the server
```

`examples run` signs in exactly like every other command and passes any extra
arguments to the example. Its output is the example's own text, not JSON.
`python -m pyhive.examples` is the same command group.
