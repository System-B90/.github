"""
Name: shell.py
Purpose: The Hive-version-independent HiveClient: sign-in factories, the
    version check and the switch to the server's API generation (#42).
Created: 2026-11-25

Every backend's client class derives from this one, so ``pyhive.HiveClient``
is the auto-detecting entry point: once the server's version is known, the
instance becomes the client class of the generation that serves it.
"""

import re
import warnings
from types import TracebackType
from typing import TYPE_CHECKING, Any, ClassVar, Literal, Optional, Union

from typing_extensions import Self

from ..src.access_tokens import (
    is_valid_personal_access_token,
    looks_like_personal_access_token,
)
from ..src.api_versions import (
    UnverifiedHiveVersionError,
    generation_for,
    versions_for_generation,
)
from ..src.authenticated_hive_client import AuthenticatedHiveClient
from .generations import (
    GenerationMismatchError,
    backend_class_for,
    client_class_for,
    default_client_class,
    versions_served_by,
)
from .sso_utils import generate_sso_client_credentials, get_sso_token

if TYPE_CHECKING:
    from httpx import Timeout
    from httpx._types import ProxyTypes


class HiveClient(AuthenticatedHiveClient):
    """Authenticated client for one Hive server; adapts to the server's Hive version."""

    GENERATION: ClassVar[str | None] = None
    BACKEND: ClassVar[str | None] = None

    def __init__(
        self,
        username: str,
        password: str,
        hive_url: str,
        *,
        skip_version_check: bool = False,
        timeout: Union["Timeout", float] | None = None,
        headers: dict[str, str] | None = None,
        verify: bool | str | None = None,
        proxy: Optional["ProxyTypes"] = None,
        existing_token: str | None = None,
        auth_strategy: Literal["sso", "cache", "access_token"] | None = None,
        refresh_token: str | None = None,
        hive_version: str | None = None,
        allow_unverified: bool = False,
        **kwargs: object,
    ):
        self._hive_version: str | None = hive_version
        super().__init__(
            username,
            password,
            hive_url,
            timeout=timeout,
            headers=headers,
            verify=verify,
            proxy=proxy,
            existing_token=existing_token,
            auth_strategy=auth_strategy,
            refresh_token=refresh_token,
            **kwargs,
        )
        try:
            if hive_version is not None:
                self._pin_hive_version(hive_version)
            if skip_version_check:
                self._adopt_latest_backend()
            else:
                self._check_server(allow_unverified)
        except BaseException:
            self.close()
            raise

    @property
    def hive_version(self) -> str | None:
        """The Hive version the server reported (``None`` when the check was skipped)."""
        return self._hive_version

    def _pin_hive_version(self, hive_version: str) -> None:
        if type(self).GENERATION is None:
            self.__class__ = client_class_for(generation_for(hive_version), type(self))

    def _check_server(self, allow_unverified: bool) -> None:
        version = self.get_hive_version()
        self._hive_version = version
        try:
            generation = generation_for(version)
        except UnverifiedHiveVersionError:
            if not allow_unverified:
                raise
            warnings.warn(
                f"Hive {version} is not a release this PyHive has verified; "
                "using the newest installed Hive API.",
                stacklevel=3,
            )
            self._adopt_latest_backend()
            return
        self._adopt_generation(version, generation)

    def _adopt_generation(self, server_version: str, generation: str) -> None:
        cls = type(self)
        if cls.GENERATION is not None:
            if cls.GENERATION != generation:
                raise GenerationMismatchError(
                    server_version, versions_for_generation(cls.GENERATION)
                )
            return
        if cls.BACKEND is not None and not issubclass(
            cls, backend_class_for(generation)
        ):
            raise GenerationMismatchError(server_version, versions_served_by(cls))
        self.__class__ = client_class_for(generation, cls)

    def _adopt_latest_backend(self) -> None:
        if type(self).BACKEND is None:
            self.__class__ = default_client_class(type(self))

    @classmethod
    def from_api_token(
        cls,
        api_token: str,
        hive_url: str,
        *,
        refresh_token: str | None = None,
        timeout: Union["Timeout", float] | None = None,
        headers: dict[str, str] | None = None,
        verify: bool | str | None = None,
        proxy: Optional["ProxyTypes"] = None,
        skip_version_check: bool = False,
        auth_strategy: Literal["sso", "cache"] | None = None,
        **kwargs: Any,
    ) -> Self:
        """Construct a client using an existing Hive API token.

        This is mainly intended for advanced integrations. In most user-facing
        scenarios, prefer :meth:`from_sso`, which performs the browser-based
        Hive SSO flow and then creates the client from the resulting token.

        By default (no ``refresh_token``/``auth_strategy``) this uses the
        bare token as-is: automatic refresh is *not* supported, and if it
        expires you must create a new :class:`HiveClient` with a
        freshly-issued token. Passing ``auth_strategy="sso"`` or
        ``"cache"`` together with a ``refresh_token`` enables automatic
        refresh on a 401 (the same mechanism :meth:`from_sso` uses).

        A personal access token (``hive_pat_...``) given without a refresh
        token is handled exactly like :meth:`from_access_token`.
        """

        if (
            auth_strategy is None
            and refresh_token is None
            and looks_like_personal_access_token(api_token)
        ):
            return cls.from_access_token(
                api_token,
                hive_url,
                timeout=timeout,
                headers=headers,
                verify=verify,
                proxy=proxy,
                skip_version_check=skip_version_check,
                **kwargs,
            )

        return cls(
            "token-auth",  # placeholder username for repr/debugging
            "unused",
            hive_url,
            timeout=timeout,
            headers=headers,
            verify=verify,
            proxy=proxy,
            skip_version_check=skip_version_check,
            existing_token=api_token,
            refresh_token=refresh_token,
            auth_strategy=auth_strategy,
            **kwargs,
        )

    @classmethod
    def from_access_token(
        cls,
        access_token: str,
        hive_url: str,
        *,
        timeout: Union["Timeout", float] | None = None,
        headers: dict[str, str] | None = None,
        verify: bool | str | None = None,
        proxy: Optional["ProxyTypes"] = None,
        skip_version_check: bool = False,
        **kwargs: Any,
    ) -> Self:
        """Construct a client from a Hive personal access token (``hive_pat_...``).

        Create one in Hive from the account menu (Access Tokens). The token is
        never refreshed: once it expires or is revoked, requests raise
        :class:`~pyhive.src.access_tokens.AccessTokenRejectedError`. A
        read-only token raises :class:`httpx.HTTPStatusError` (403) on writes.

        Raises:
            ValueError: ``access_token`` is not a well formed Hive personal
                access token (checked offline, including its checksum).
        """

        access_token = access_token.strip()
        if not is_valid_personal_access_token(access_token):
            msg = (
                "Not a valid Hive personal access token: expected 'hive_pat_' "
                "followed by 46 letters and digits. Check it was copied whole."
            )
            raise ValueError(msg)

        return cls(
            "access-token",  # placeholder username for repr/debugging
            "unused",
            hive_url,
            timeout=timeout,
            headers=headers,
            verify=verify,
            proxy=proxy,
            skip_version_check=skip_version_check,
            existing_token=access_token,
            auth_strategy="access_token",
            refresh_token=None,
            **kwargs,
        )

    @classmethod
    def from_sso(
        cls,
        hive_url: str,
        *,
        timeout: Union["Timeout", float] | None = None,
        headers: dict[str, str] | None = None,
        verify: bool | str | None = None,
        proxy: Optional["ProxyTypes"] = None,
        skip_version_check: bool = False,
        **kwargs: Any,
    ) -> Self:
        """
        Instantiate a HiveClient using interactive browser-based SSO authentication.

        Args:
            hive_url (str): The base URL of the Hive server.
            timeout (Optional[Union[Timeout, float]]): Request timeout configuration.
            headers (Optional[dict[str, str]]): Additional headers to apply to the client.
            verify (Optional[Union[bool, str]]): SSL verification requirements.
            proxy (Optional[ProxyTypes]): Proxy configuration.
            skip_version_check (bool): Bypass API version compatibility checking.
            **kwargs (object): Additional client configuration parameters.

        Returns:
            HiveClient: An authenticated instance of the HiveClient.
        """

        # Trigger the browser-based OIDC flow
        user_token = get_sso_token(hive_url=hive_url, verify=verify)

        # Delegate to from_api_token to construct the actual client
        return cls.from_api_token(
            api_token=user_token[0],
            refresh_token=user_token[1],
            hive_url=hive_url,
            timeout=timeout,
            headers=headers,
            verify=verify,
            proxy=proxy,
            skip_version_check=skip_version_check,
            auth_strategy="sso",
            **kwargs,
        )

    def __repr__(self) -> str:
        """Return a short representation including username and hive_url.

        The representation intentionally omits secrets.
        """

        return f"HiveClient({self.username!r}, input(), {self.hive_url!r})"

    def __enter__(self) -> Self:
        """Enter context manager and return this client instance.

        The underlying :class:`httpx.Client` is managed by this object's
        lifecycle; entering the context returns the authenticated client so
        callers can perform API calls.
        """
        return self

    def __exit__(
        self,
        type_: type[BaseException] | None,
        value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        """Exit the context and close the underlying httpx session.

        This delegates to the managed :class:`httpx.Client`'s ``__exit__``
        method to ensure resources are released.
        """

        self._session.__exit__(type_, value, traceback)

    def _api_version_check(self) -> tuple[str, str]:
        """Validate that the Hive server runs a release PyHive has verified.

        Fetches the server version via ``get_hive_version`` and looks it up,
        by exact match, in the ``hive_versions.toml`` table. Returns the
        server version and the generation serving it.

        Raises:
            UnverifiedHiveVersionError: (a ``RuntimeError``) if the server
                version is not in the table.
        """
        version = self.get_hive_version()
        return version, generation_for(version)

    def get_hive_version(self) -> str:
        """Return the Hive server version string (e.g., '1.2.3')."""
        data = self.get("/api/core/schema/")
        assert isinstance(data, dict)
        version = data.get("info", {}).get("version", "")
        if not isinstance(version, str) or not re.match(r"^\d+\.\d+\.\d+", version):
            raise ValueError("Invalid version string received from server")
        return version

    def register_sso_service(
        self,
        service_name: str,
        redirect_uris: list[str] | str | None = None,
    ) -> dict[str, str]:
        """Register an SSO client app with Hive and return its id and secret."""
        return generate_sso_client_credentials(self, service_name, redirect_uris)
