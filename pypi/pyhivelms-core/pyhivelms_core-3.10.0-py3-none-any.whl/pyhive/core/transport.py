"""
Name: transport.py
Purpose: The HiveTransport protocol, the only surface backend mixins may call (#42).
Created: 2026-11-25

Everything Hive does the same way in every API generation lives behind this
protocol: authentication, retries, token refresh, pagination and error mapping.
A Hive change to any of those is a core change, never a new generation.
Bump ``TRANSPORT_PROTOCOL_VERSION`` whenever a member is removed or changes
meaning; adding a member is backwards compatible.
"""

from collections.abc import Iterator
from typing import Any, Protocol, runtime_checkable

import httpx

TRANSPORT_PROTOCOL_VERSION = 1


@runtime_checkable
class HiveTransport(Protocol):
    """Authenticated access to one Hive server."""

    hive_url: str

    def get(
        self,
        endpoint: str,
        params: httpx.QueryParams | None = None,
        follow_redirects: bool = False,
    ) -> dict[str, Any] | list[Any]:
        """GET a JSON object or list."""

    def get_json(
        self,
        endpoint: str,
        params: httpx.QueryParams | None = None,
        follow_redirects: bool = False,
    ) -> Any:
        """GET any JSON value, scalars included."""

    def get_bytes(
        self, endpoint: str, params: dict[str, Any] | None = None
    ) -> bytes | None:
        """GET a raw body, or ``None`` when Hive answers 404."""

    def paginate(
        self, endpoint: str, params: httpx.QueryParams | None = None
    ) -> Iterator[dict[str, Any]]:
        """Yield every raw item of a list endpoint, following DRF ``next`` links."""

    def post(self, endpoint: str, data: dict[Any, Any]) -> dict[str, Any]:
        """POST JSON and return the JSON object Hive answers with."""

    def post_action(self, endpoint: str, data: dict[Any, Any]) -> None:
        """POST JSON to an endpoint that answers with an empty body."""

    def post_empty(self, endpoint: str) -> None:
        """POST an empty body."""

    def put(self, endpoint: str, data: dict[Any, Any]) -> dict[Any, Any]:
        """PUT JSON and return the JSON object Hive answers with."""

    def put_empty(self, endpoint: str) -> None:
        """PUT an empty body."""

    def patch(self, endpoint: str, data: dict[Any, Any]) -> dict[Any, Any]:
        """PATCH JSON and return the JSON object Hive answers with."""

    def patch_action(self, endpoint: str, data: dict[Any, Any]) -> None:
        """PATCH JSON to an endpoint that answers with an empty body."""

    def delete(self, endpoint: str, force: bool = False) -> None:
        """DELETE a resource."""

    def map_http_error(self, exc: httpx.HTTPStatusError) -> Exception:
        """Return the exception to raise for a failed write."""
