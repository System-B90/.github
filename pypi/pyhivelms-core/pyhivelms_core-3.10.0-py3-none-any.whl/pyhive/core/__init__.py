"""Hive-version-independent core: transport protocol, client shell and backend registry (#42)."""

from .generations import (
    BackendNotInstalledError,
    GenerationMismatchError,
    backend_class_for,
    client_class_for,
    register_generation,
    registered_generations,
)
from .transport import TRANSPORT_PROTOCOL_VERSION, HiveTransport

__all__ = [
    "TRANSPORT_PROTOCOL_VERSION",
    "BackendNotInstalledError",
    "GenerationMismatchError",
    "HiveTransport",
    "backend_class_for",
    "client_class_for",
    "register_generation",
    "registered_generations",
]
