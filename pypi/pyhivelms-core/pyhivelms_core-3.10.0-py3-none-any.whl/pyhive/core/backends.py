"""
Name: backends.py
Purpose: Which Hive API backends are installed, and the command that adds or
    removes one in the current environment (#42 phase 5).
Created: 2026-11-25

Nothing here prompts: the interactive picker lives in the CLI. Users see Hive
versions; generation names appear only in distribution names.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import sysconfig
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

from ..src.api_versions import HIVE_VERSION_GENERATIONS, generation_for
from .generations import registered_generations

ORG_INDEX = "https://system-b90.github.io/.github/pypi/"
NO_PROMPT_ENV = "PYHIVE_NO_BACKEND_PROMPT"


@dataclass(frozen=True)
class BackendStatus:
    """One API generation: the Hive versions it serves and whether its backend is installed."""

    generation: str
    versions: tuple[str, ...]
    installed: bool
    newest: bool

    @property
    def distribution(self) -> str:
        """The backend's distribution name."""
        return f"pyhivelms-backend-{self.generation}"

    @property
    def label(self) -> str:
        """The Hive versions it serves, comma separated."""
        return ", ".join(self.versions)


@dataclass(frozen=True)
class Plan:
    """The command that changes the installed backends, and whether PyHive may run it."""

    command: tuple[str, ...]
    runnable: bool
    reason: str = ""

    @property
    def shell(self) -> str:
        """The command as one line to copy."""
        return " ".join(
            f'"{p}"' if " " in p or "<" in p or ">" in p else p for p in self.command
        )


def statuses() -> list[BackendStatus]:
    """Every generation in the version table, oldest first."""
    installed = set(registered_generations())
    generations = list(dict.fromkeys(HIVE_VERSION_GENERATIONS.values()))
    return [
        BackendStatus(
            generation,
            tuple(v for v, g in HIVE_VERSION_GENERATIONS.items() if g == generation),
            generation in installed,
            generation == generations[-1],
        )
        for generation in generations
    ]


def status_for(hive_version: str) -> BackendStatus:
    """The backend serving ``hive_version`` (raises ``UnverifiedHiveVersionError`` if unlisted)."""
    generation = generation_for(hive_version)
    return next(s for s in statuses() if s.generation == generation)


def requirement(distribution: str) -> str:
    """A lockstep requirement matching the installed core's version."""
    try:
        core = version("pyhivelms-core")
    except PackageNotFoundError:
        return distribution
    release = core.split("+", 1)[0]
    major = int(release.split(".", 1)[0])
    return f"{distribution}>={release},<{major + 1}"


def _in_virtualenv() -> bool:
    return sys.prefix != getattr(sys, "base_prefix", sys.prefix)


def _externally_managed() -> bool:
    stdlib = sysconfig.get_path("stdlib")
    return bool(stdlib) and (Path(stdlib) / "EXTERNALLY-MANAGED").is_file()


def _prefix_parts() -> list[str]:
    return [p.lower() for p in Path(sys.prefix).parts]


def plan(distributions: list[str], *, remove: bool = False) -> Plan:
    """How to install (or remove) ``distributions`` here. Never retried by PyHive."""
    parts = _prefix_parts()
    if "pipx" in parts and "venvs" in parts:
        names = distributions if remove else [requirement(d) for d in distributions]
        verb = "uninject" if remove else "inject"
        runnable = shutil.which("pipx") is not None
        return Plan(
            ("pipx", verb, "pyhivelms", *names),
            runnable,
            "" if runnable else "pipx is not on PATH",
        )
    if "uv" in parts and "tools" in parts:
        withs = [arg for d in distributions for arg in ("--with", requirement(d))]
        return Plan(
            ("uv", "tool", "install", "--force", "pyhivelms", *withs),
            False,
            "PyHive runs as a uv tool: reinstall it with the backends you want",
        )
    if remove:
        command = (sys.executable, "-m", "pip", "uninstall", "-y", *distributions)
    else:
        command = (
            sys.executable,
            "-m",
            "pip",
            "install",
            "--extra-index-url",
            ORG_INDEX,
            *(requirement(d) for d in distributions),
        )
    if _in_virtualenv():
        return Plan(command, True)
    if _externally_managed():
        return Plan(
            command,
            False,
            "this Python is externally managed (PEP 668): use a virtualenv or pipx",
        )
    if not remove:
        command = (*command[:4], "--user", *command[4:])
    return Plan(command, True)


def run(plan_: Plan) -> int:
    """Run a runnable plan once and return its exit code (no retries)."""
    if not plan_.runnable:
        raise RuntimeError(plan_.reason)
    env = dict(os.environ, PIP_DISABLE_PIP_VERSION_CHECK="1")
    return subprocess.run(list(plan_.command), env=env, check=False).returncode
