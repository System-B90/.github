"""
Name: generations.py
Purpose: Which installed backend serves each API generation, and the
    per-generation HiveClient classes assembled from it (#42).
Created: 2026-11-25

A generation is an internal name for one Hive API model shape
(``hive_versions.toml``). Backend distributions declare the generations they
serve as ``pyhive.backends`` entry points (name = generation, value = the
backend's client class); ``register_generation`` adds one at runtime.
"""

from collections.abc import Sequence
from importlib.metadata import EntryPoint, entry_points
from typing import TYPE_CHECKING, TypeVar, cast

from ..src.api_versions import HIVE_VERSION_GENERATIONS

if TYPE_CHECKING:
    from .shell import HiveClient

ENTRY_POINT_GROUP = "pyhive.backends"
INSTALL_HINT = 'pip install --upgrade "pyhivelms"'


def install_command(hive_version: str | None) -> str:
    """The pip command installing the backend for ``hive_version`` (or every default one)."""
    if hive_version is None:
        return INSTALL_HINT
    return f'pip install --upgrade "pyhivelms[{hive_version}]"'


ClientT = TypeVar("ClientT", bound="HiveClient")

_REGISTRY: dict[str, type["HiveClient"]] = {}
_CLASSES: dict[tuple[str | None, type, type], type] = {}


class GenerationMismatchError(RuntimeError):
    """A version-specific client was pointed at a Hive server of another API generation."""

    def __init__(self, server_version: str, client_versions: Sequence[str]) -> None:
        self.server_version = server_version
        self.client_versions = list(client_versions)
        super().__init__(
            f"This client serves Hive {', '.join(client_versions)}, but the server "
            f"runs Hive {server_version}, whose API is incompatible. Use "
            "pyhive.HiveClient, which adapts to the server's version."
        )


class BackendNotInstalledError(LookupError):
    """No installed backend serves the Hive version the server runs."""

    def __init__(self, generation: str) -> None:
        self.generation = generation
        versions = [v for v, g in HIVE_VERSION_GENERATIONS.items() if g == generation]
        self.install_command = install_command(versions[0] if versions else None)
        super().__init__(
            f"PyHive supports Hive {', '.join(versions) or generation}, but the "
            f"package that serves it is not installed. Run: {self.install_command}"
        )


def _entry_points() -> dict[str, EntryPoint]:
    return {ep.name: ep for ep in entry_points(group=ENTRY_POINT_GROUP)}


def register_generation(generation: str, client_cls: type["HiveClient"]) -> None:
    """Serve ``generation`` with ``client_cls``, ahead of any installed entry point."""
    if _REGISTRY.get(generation, client_cls) is not client_cls:
        raise ValueError(f"Generation {generation!r} is already registered")
    _REGISTRY[generation] = client_cls
    _CLASSES.clear()


def registered_generations() -> list[str]:
    """Every generation some backend serves, in ``hive_versions.toml`` order first."""
    known = {*_REGISTRY, *_entry_points()}
    ordered = [
        g for g in dict.fromkeys(HIVE_VERSION_GENERATIONS.values()) if g in known
    ]
    return ordered + sorted(known.difference(ordered))


def backend_package_for(generation: str) -> str | None:
    """The top-level package of the backend serving ``generation``, without importing it."""
    if generation in _REGISTRY:
        return _REGISTRY[generation].__module__.partition(".")[0]
    ep = _entry_points().get(generation)
    return ep.module.partition(".")[0] if ep is not None else None


def latest_backend_package() -> str | None:
    """The backend serving the newest generation that has one installed."""
    for generation in reversed(registered_generations()):
        if generation in HIVE_VERSION_GENERATIONS.values():
            return backend_package_for(generation)
    return None


def backend_class_for(generation: str) -> type["HiveClient"]:
    """The backend client class serving ``generation``.

    Raises:
        BackendNotInstalledError: no installed backend serves it.
    """
    if generation not in _REGISTRY:
        ep = _entry_points().get(generation)
        if ep is None:
            raise BackendNotInstalledError(generation)
        _REGISTRY[generation] = ep.load()
    return _REGISTRY[generation]


def versions_served_by(cls: type["HiveClient"]) -> list[str]:
    """Every Hive version whose generation is served by ``cls``'s backend."""
    return [
        version
        for version, generation in HIVE_VERSION_GENERATIONS.items()
        if backend_package_for(generation) == cls.BACKEND
    ]


def _derive(
    base: type[ClientT], backend: type["HiveClient"], generation: str | None
) -> type[ClientT]:
    from .shell import HiveClient  # pylint: disable=import-outside-toplevel

    key = (generation, base, backend)
    if key in _CLASSES:
        return cast("type[ClientT]", _CLASSES[key])
    if issubclass(base, backend):
        bases: tuple[type, ...] = (base,)
    elif base is HiveClient:
        bases = (backend,)
    elif base.BACKEND is None:
        bases = (base, backend)
    else:
        raise TypeError(f"{base.__qualname__} cannot be served by {backend.__module__}")
    if generation is None and len(bases) == 1:
        return cast("type[ClientT]", bases[0])
    name = base.__name__ if generation is None else f"{base.__name__}_{generation}"
    _CLASSES[key] = type(
        name,
        bases,
        {
            "GENERATION": generation,
            "__module__": bases[0].__module__,
            "__qualname__": name,
        },
    )
    return cast("type[ClientT]", _CLASSES[key])


def client_class_for(generation: str, base: type[ClientT]) -> type[ClientT]:
    """Return the class serving ``generation`` for an instance of ``base``, cached."""
    return _derive(base, backend_class_for(generation), generation)


def default_client_class(base: type[ClientT]) -> type[ClientT]:
    """The class used without a version check: ``base`` on top of the latest installed backend."""
    for generation in reversed(registered_generations()):
        if generation in HIVE_VERSION_GENERATIONS.values():
            return _derive(base, backend_class_for(generation), None)
    raise BackendNotInstalledError(next(reversed(HIVE_VERSION_GENERATIONS.values())))
