"""
Name: aliases.py
Purpose: Keep the 3.x import paths (pyhive.client, pyhive.types,
    pyhive.src.types) working once their code lives in a backend package (#42).
Created: 2026-11-25

A ``sys.meta_path`` finder resolves each old path to the same module object in
the latest installed backend, so classes stay identical under both names and
patching either path patches both.
"""

import importlib
import importlib.abc
import importlib.machinery
import sys
from types import ModuleType

from ..src.api_versions import UnverifiedHiveVersionError, generation_for
from .generations import (
    INSTALL_HINT,
    backend_package_for,
    install_command,
    latest_backend_package,
)

HIVE_VERSION_PREFIX = "pyhive.hive.v"

_FIXED = {"pyhive.client.sso_utils": "pyhive.core.sso_utils"}
_INTO_BACKEND = {
    "pyhive.client": "client",
    "pyhive.src.types": "types",
    "pyhive.types": "public_types",
}


def _hive_version_target(name: str) -> str:
    version = name[len(HIVE_VERSION_PREFIX) :].replace("_", ".")
    try:
        generation = generation_for(version)
    except UnverifiedHiveVersionError as exc:
        raise ModuleNotFoundError(str(exc), name=name) from None
    backend = backend_package_for(generation)
    if backend is None:
        raise ModuleNotFoundError(
            f"No module named {name!r}: the package serving Hive {version} is not "
            f"installed. Run: {install_command(version)}",
            name=name,
        )
    return f"{backend}.hive_api"


def alias_target(name: str) -> str | None:
    """The real module behind ``name`` (a 3.x path or ``pyhive.hive.v<X_Y_Z>``), else ``None``."""
    if (
        name.startswith(HIVE_VERSION_PREFIX)
        and "." not in name[len(HIVE_VERSION_PREFIX) :]
    ):
        return _hive_version_target(name)
    for alias, target in _FIXED.items():
        if name == alias or name.startswith(alias + "."):
            return target + name[len(alias) :]
    for alias, submodule in _INTO_BACKEND.items():
        if name == alias or name.startswith(alias + "."):
            backend = latest_backend_package()
            if backend is None:
                raise ModuleNotFoundError(
                    f"No module named {name!r}: no PyHive backend is installed. "
                    f"Run: {INSTALL_HINT}",
                    name=name,
                )
            return f"{backend}.{submodule}{name[len(alias) :]}"
    return None


class _AliasLoader(importlib.abc.Loader):
    def __init__(self, target: str) -> None:
        self._target = target
        self._spec: importlib.machinery.ModuleSpec | None = None

    def create_module(self, spec: importlib.machinery.ModuleSpec) -> ModuleType:
        module = importlib.import_module(self._target)
        self._spec = module.__spec__
        return module

    def exec_module(self, module: ModuleType) -> None:
        # module_from_spec overwrote __spec__ with the alias's; the module keeps its real one
        module.__spec__ = self._spec


class _AliasFinder(importlib.abc.MetaPathFinder):
    def find_spec(
        self,
        fullname: str,
        path: object = None,
        target: ModuleType | None = None,
    ) -> importlib.machinery.ModuleSpec | None:
        del path, target
        real = alias_target(fullname)
        if real is None:
            return None
        return importlib.machinery.ModuleSpec(fullname, _AliasLoader(real))


_FINDER = _AliasFinder()


def install() -> None:
    """Put the alias finder first on ``sys.meta_path`` (idempotent)."""
    if _FINDER not in sys.meta_path:
        sys.meta_path.insert(0, _FINDER)
