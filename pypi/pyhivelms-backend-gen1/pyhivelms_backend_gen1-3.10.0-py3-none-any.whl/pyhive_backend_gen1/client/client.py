"""High-level Hive API client aggregator."""

from typing import ClassVar

from pyhive.core.shell import HiveClient as _HiveClientShell

from .assignment_responses import AssignmentResponsesClientMixin
from .assignments import AssignmentClientMixin
from .classes import ClassesClientMixin
from .exercises import ExerciseClientMixin
from .fields import FieldsClientMixin
from .help import HelpClientMixin
from .lessons import LessonClientMixin
from .modules import ModuleClientMixin
from .notifications import NotificationClientMixin
from .programs import ProgramClientMixin
from .queues import QueuesClientMixin
from .schedule import ScheduleClientMixin
from .seating import SeatingClientMixin
from .subjects import SubjectClientMixin
from .tags import TagClientMixin
from .users import UserClientMixin


class HiveClient(  # pylint: disable=too-many-ancestors,abstract-method
    ProgramClientMixin,
    SubjectClientMixin,
    ModuleClientMixin,
    ExerciseClientMixin,
    AssignmentClientMixin,
    UserClientMixin,
    ClassesClientMixin,
    FieldsClientMixin,
    AssignmentResponsesClientMixin,
    QueuesClientMixin,
    HelpClientMixin,
    LessonClientMixin,
    NotificationClientMixin,
    ScheduleClientMixin,
    SeatingClientMixin,
    TagClientMixin,
    _HiveClientShell,
):
    """The Hive API client this backend serves: every resource mixin on top of the core shell."""

    BACKEND: ClassVar[str | None] = "pyhive_backend_gen1"
