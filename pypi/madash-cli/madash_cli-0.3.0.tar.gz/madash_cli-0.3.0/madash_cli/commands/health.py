"""
Name: health.py
Purpose: `madash health` — the unauthenticated liveness probe served at
         /api/health, the same one the container healthcheck reads.
Created: 2026-09-27
Author: Michael K. Steinberg
"""

from __future__ import annotations

import typer

from madash_cli.commands._common import show
from madash_cli.context import state

_PATH = "/api/health"

# The route is deliberately dependency-free (Hive being down must not restart
# the container), so it only ever answers "ok" while the app is serving.
_HEALTHY = "ok"


def health() -> None:
    """Check that Madash is up.

    Exits non-zero unless the server answers `ok`, so this is usable as a
    shell gate: `madash health || echo "down"`.
    """
    with state.client() as client:
        # Not client.get: /api/health does not speak the response envelope.
        report = client.get_raw(_PATH)

    show(report, title="Health")

    if not isinstance(report, dict) or report.get("status") != _HEALTHY:
        raise typer.Exit(1)
