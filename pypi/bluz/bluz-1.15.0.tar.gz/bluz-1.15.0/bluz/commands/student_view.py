"""
Name: student_view.py
Purpose: The student board (#656) — the read-only per-day projection a student
         session may call, plus the focused-time report the board sends.
         Mirrors ui/src/api-client/student-view.ts.
Created: 2026-09-18
Author: Michael K. Steinberg
"""

from __future__ import annotations

import typer

from bluz.commands._common import LIMIT_OPTION, OFFSET_OPTION, session, show
from bluz.output import abort, success

app = typer.Typer(
    help="The student board (read-only projection).", no_args_is_help=True
)


@app.command("schedule")
def schedule(
    date: str = typer.Option(
        None,
        "--date",
        help="Day to show (ISO). Staff-only preview — a student session is "
        "always served its own current day.",
    ),
    iteration: str = typer.Option(
        None, "--iteration", "--it", help="Iteration id (staff preview only)."
    ),
    limit: int = LIMIT_OPTION,
    offset: int = OFFSET_OPTION,
) -> None:
    """One day of the student board — the `StudentEvent` projection, never raw events."""
    with session() as bz:
        show(
            bz.student_view.schedule(date, iteration=iteration),
            title="Student schedule",
            limit=limit,
            offset=offset,
        )


@app.command("report-engagement")
def report_engagement(
    seconds: int = typer.Argument(..., help="Focused seconds to add to today's count."),
) -> None:
    """Add focused board time to the caller's own daily counter.

    The user and the date come from the session and the server clock, so this
    can only ever add to the reporter's own number, for today; the increment
    is clamped and the daily total capped server-side.
    """
    with session() as bz:
        bz.student_view.report_engagement(seconds)
    success(f"Reported {seconds}s of engagement")


@app.command("monitor")
def monitor(
    date: str = typer.Option(
        None, "--date", help="Day to show (ISO). Defaults to the server's today."
    ),
    limit: int = LIMIT_OPTION,
    offset: int = OFFSET_OPTION,
) -> None:
    """Every student's focused board time and suspected attempts (staff only).

    Mirrors the staff student monitor: students with attempts first, then by
    focused time. A Checker session is refused.
    """
    with session() as bz:
        result = bz.student_view.monitor(date)
    show(
        result.rows,
        title=f"Student monitor {result.date or ''}".strip(),
        limit=limit,
        offset=offset,
    )


@app.command("push-reload")
def push_reload() -> None:
    """Force every open student board to reload now (staff only).

    Sent over the students' websocket; each board reloads after a short
    random delay so they do not all hit the server at once.
    """
    with session() as bz:
        bz.student_view.push_reload()
    success("Pushed a reload to every student board")


@app.command("refresh-interval")
def refresh_interval(
    seconds: int = typer.Argument(
        None,
        help="New interval in seconds (10-3600). Omit to show the current one.",
    ),
) -> None:
    """Show or set how often every student board refreshes (staff only).

    Boards do not follow schedule edits live; they refetch on this interval.
    Mirrors the interval field on the student preview bar.
    """
    with session() as bz:
        if seconds is None:
            current = bz.student_view.refresh_interval()
            show(
                {
                    "refreshSeconds": current,
                    "source": "staff" if current else "default",
                },
                title="Student board refresh",
            )
            return
        try:
            bz.student_view.set_refresh_interval(seconds)
        except ValueError as error:
            abort(str(error))
    success(f"Student boards refresh every {seconds}s (from their next refresh)")
