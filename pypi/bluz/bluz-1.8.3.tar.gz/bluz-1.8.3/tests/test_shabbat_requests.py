"""
Name: test_shabbat_requests.py
Purpose: Wire contract for `bluz shabbat` — one GET, the date as a query.
Created: 2026-10-14
Author: Michael K. Steinberg
"""

from __future__ import annotations


def test_shabbat_reads_the_window_for_the_given_date(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope("GET", "/api/shabbat", {"candleLighting": "17:48"})

    result = run_cli(stub, "shabbat", "2026-10-14")

    assert result.exit_code == 0
    assert stub.last().method == "GET"
    assert stub.last().path == "/api/shabbat"
    assert stub.last().query == {"date": ["2026-10-14"]}
