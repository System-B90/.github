"""
Name: test_prayers_requests.py
Purpose: Wire contract for `bluz prayers` — one GET, the date as a query.
Created: 2026-10-26
Author: Michael K. Steinberg
"""

from __future__ import annotations


def test_prayers_reads_the_week_for_the_given_date(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope(
        "GET",
        "/api/prayers",
        [{"date": "2026-10-14", "prayer": "mincha", "start": "13:00", "end": "13:30"}],
    )

    result = run_cli(stub, "prayers", "2026-10-14")

    assert result.exit_code == 0
    assert stub.last().method == "GET"
    assert stub.last().path == "/api/prayers"
    assert stub.last().query == {"date": ["2026-10-14"]}
