"""
Name: shabbat.py
Purpose: `bluz shabbat` — Shabbat times and Friday/Saturday event bounds for a
         week, resolved by the server so no calendar code runs on the client.
         Mirrors ui/src/api-client/shabbat.ts.
Created: 2026-10-14
Author: Michael K. Steinberg
"""

from __future__ import annotations

import typer

from bluz.commands._common import session, show


def shabbat(
    date: str = typer.Argument(
        ..., help="Any date (YYYY-MM-DD) in the Sunday-to-Saturday week."
    ),
) -> None:
    """Candle lighting, havdalah and the event bounds around them (Beer Sheva).

    `fridayLastEventEnd` is candle lighting − 2h and `saturdayFirstEventStart`
    is havdalah + 30m (RULES.md R-32). Times are Israel local.
    """
    with session() as bz:
        show(bz.shabbat.window(date), title="Shabbat")
