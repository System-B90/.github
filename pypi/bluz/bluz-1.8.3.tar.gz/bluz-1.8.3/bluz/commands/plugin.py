"""
Name: plugin.py
Purpose: `bluz plugin install` — fetch the `bluz` Claude Code plugin served by a
         Bluz instance at /api/cli-dist, unpack it as a local marketplace and
         install it through the `claude` CLI.
Created: 2026-10-14
Author: Michael K. Steinberg
"""

from __future__ import annotations

import io
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

import typer

from bluz.commands._common import session
from bluz.output import success, warn

app = typer.Typer(
    help="The bluz Claude Code plugin served by the Bluz instance.",
    no_args_is_help=True,
)

_MARKETPLACE = "bluz"
_PLUGIN = "bluz"
_DEPRECATED_PLUGIN = "bluz-cli"


def _marketplace_dir() -> Path:
    return Path(typer.get_app_dir("bluz")) / "claude-marketplace"


def _claude(executable: str, *args: str) -> bool:
    # The resolved path, not bare "claude": on Windows it is a .cmd/.exe shim.
    result = subprocess.run([executable, "plugin", *args], check=False)
    return result.returncode == 0


@app.command()
def install() -> None:
    """Download the plugin, register it as marketplace `bluz`, install `bluz@bluz`."""
    with session() as bz:
        base_url = bz.http.config.require_url()
        name = bz.system.cli_dist().get("plugin")
        if not name:
            raise typer.BadParameter("This Bluz instance serves no plugin archive.")
        data = bz.system.cli_dist_file(name)

    target = _marketplace_dir()
    shutil.rmtree(target, ignore_errors=True)
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        archive.extractall(target)
    # The SessionStart hook installs the CLI from the instance it came from.
    (target / _PLUGIN / "instance.json").write_text(
        json.dumps({"url": base_url}) + "\n", encoding="utf-8"
    )

    claude = shutil.which("claude")
    if not claude:
        warn("`claude` not on PATH. Install the plugin from Claude Code with:")
        typer.echo(f"claude plugin marketplace add {target}")
        typer.echo(f"claude plugin install {_PLUGIN}@{_MARKETPLACE}")
        return

    if not _claude(claude, "marketplace", "update", _MARKETPLACE):
        _claude(claude, "marketplace", "add", str(target))
    if not _claude(claude, "install", f"{_PLUGIN}@{_MARKETPLACE}"):
        raise typer.Exit(1)
    success(
        f"Installed Claude Code plugin {_PLUGIN}@{_MARKETPLACE} — restart Claude Code"
    )
    warn(
        f"`{_DEPRECATED_PLUGIN}` is deprecated. If installed: "
        f"claude plugin uninstall {_DEPRECATED_PLUGIN}"
    )
