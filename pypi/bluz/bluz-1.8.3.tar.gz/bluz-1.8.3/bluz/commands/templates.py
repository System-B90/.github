"""
Name: templates.py
Purpose: Schedule week templates (#997): list, inspect, create, retime, make
         default and delete. Mirrors ui/src/api-client/week-templates.ts.
Created: 2026-10-17
Author: Michael K. Steinberg
"""

from __future__ import annotations

import typer

from bluz.commands._common import session, show
from bluz.output import success

app = typer.Typer(help="Schedule week templates.", no_args_is_help=True)

TIME_FIELDS = {
    "day_start": "day_start_time",
    "weekend_home_start": "weekend_home_start_time",
    "breakfast": "breakfast_time",
    "lunch": "lunch_time",
    "dinner": "dinner_time",
    "shacharit": "shacharit_time",
    "mincha": "mincha_time",
    "arvit": "arvit_time",
}


@app.command("list")
def list_templates() -> None:
    """List every template, the default first."""
    with session() as bz:
        show(bz.templates.list(), title="Week templates")


@app.command()
def get(
    template_id: str = typer.Argument(..., help="Template id."),
) -> None:
    """Show a template and its events."""
    with session() as bz:
        show(bz.templates.get(template_id), title=template_id)


@app.command()
def create(
    name: str = typer.Argument(..., help="Template name."),
    copy_times_from: str | None = typer.Option(
        None,
        "--copy-times-from",
        help="Template id to copy times from (default: the default template).",
    ),
) -> None:
    """Create a template, seeded with the linked curriculum's recurring events, parked."""
    with session() as bz:
        created = bz.templates.create(name, copy_times_from=copy_times_from)
    success(f"Created template {created.name} ({created.id})")
    show(created)


@app.command("set-times")
def set_times(
    template_id: str = typer.Argument(..., help="Template id."),
    name: str | None = typer.Option(None, "--name", help="New name."),
    day_start: str | None = typer.Option(None, "--day-start", help="HH:mm"),
    weekend_home_start: str | None = typer.Option(
        None, "--weekend-home-start", help="HH:mm, after a weekend at home."
    ),
    breakfast: str | None = typer.Option(None, "--breakfast", help="HH:mm"),
    lunch: str | None = typer.Option(None, "--lunch", help="HH:mm"),
    dinner: str | None = typer.Option(None, "--dinner", help="HH:mm"),
    shacharit: str | None = typer.Option(None, "--shacharit", help="HH:mm"),
    mincha: str | None = typer.Option(None, "--mincha", help="HH:mm"),
    arvit: str | None = typer.Option(None, "--arvit", help="HH:mm"),
    apply: bool = typer.Option(
        False,
        "--apply/--no-apply",
        help="Also re-plan weeks already cut with this template (hand-edited events are kept).",
    ),
) -> None:
    """Rename a template or change its day-start, meal and prayer times."""
    given = {
        "day_start": day_start,
        "weekend_home_start": weekend_home_start,
        "breakfast": breakfast,
        "lunch": lunch,
        "dinner": dinner,
        "shacharit": shacharit,
        "mincha": mincha,
        "arvit": arvit,
    }
    fields: dict[str, str] = {
        TIME_FIELDS[key]: value for key, value in given.items() if value is not None
    }
    if name is not None:
        fields["name"] = name
    if not fields:
        raise typer.BadParameter("Nothing to change: pass --name or a time option.")
    with session() as bz:
        result = bz.templates.update(template_id, apply_to_cut_weeks=apply, **fields)
    success(f"Saved template {result.template.name}")
    show(result)


@app.command("set-default")
def set_default(
    template_id: str = typer.Argument(..., help="Template id."),
) -> None:
    """Make a template the default, used when a cut names none."""
    with session() as bz:
        result = bz.templates.update(template_id, is_default=True)
    success(f"{result.template.name} is now the default template")


@app.command()
def delete(
    template_id: str = typer.Argument(..., help="Template id."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Delete a template. Weeks already cut from it are unchanged."""
    if not yes:
        typer.confirm(f"Delete week template {template_id}?", abort=True)
    with session() as bz:
        bz.templates.delete(template_id)
    success(f"Deleted template {template_id}")
