"""
Name: prayers.py
Purpose: `bluz prayers` — the daily prayer windows of a week, resolved by the
         server from the week template the week was cut with.
         Mirrors ui/src/api-client/prayer-windows.ts.
Created: 2026-10-26
Author: Michael K. Steinberg
"""

from __future__ import annotations

import typer

from bluz.commands._common import ITERATION_OPTION, session, show


def prayers(
    date: str = typer.Argument(
        ..., help="Any date (YYYY-MM-DD) in the Sunday-to-Saturday week."
    ),
    iteration: str = ITERATION_OPTION,
) -> None:
    """Shacharit, Mincha and Arvit windows per day (Beer Sheva).

    Lengthened on Rosh Chodesh, fasts and the like (`reasons`). A schedule
    tint, not events. Times are Israel local; `end` is "24:00" past midnight.
    """
    with session() as bz:
        show(bz.prayers.week(date, iteration=iteration), title="Prayers")
