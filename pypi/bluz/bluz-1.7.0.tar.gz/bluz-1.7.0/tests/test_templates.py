"""
Name: test_templates.py
Purpose: Wire contracts for schedule week templates (#997): the `bz.templates`
         SDK namespace, the `bluz templates` commands and the cut's
         `--template` option.
Created: 2026-10-17
Author: Michael K. Steinberg
"""

from __future__ import annotations

import json
from datetime import time

from bluz.models import WeekTemplate, WeekTemplateSaveResult

TEMPLATE = {
    "id": "t1",
    "name": "Base",
    "isDefault": True,
    "eventCount": 3,
    "dayStartTime": "07:45",
    "lunchTime": "12:30",
}
SAVED = {
    "template": TEMPLATE,
    "applied": {"weeks": 2, "updatedEvents": 5, "skippedConflicts": 1},
}


def test_sdk_lists_and_parses_templates(stub_bluz, sdk):
    stub = stub_bluz()
    stub.envelope("GET", "/api/week-templates", [TEMPLATE])

    [template] = sdk(stub).templates.list()

    assert isinstance(template, WeekTemplate)
    assert template.day_start_time == time(7, 45)
    assert template.lunch_time == time(12, 30)
    assert template.is_default is True


def test_sdk_update_camelcases_fields_and_carries_the_apply_answer(stub_bluz, sdk):
    stub = stub_bluz()
    stub.envelope("PATCH", "/api/week-templates/t1", SAVED)

    result = sdk(stub).templates.update(
        "t1", lunch_time="12:30", apply_to_cut_weeks=True
    )

    assert stub.last().body == {"lunchTime": "12:30", "applyToCutWeeks": True}
    assert isinstance(result, WeekTemplateSaveResult)
    assert result.applied is not None
    assert result.applied.weeks == 2


def test_sdk_get_scopes_course_resolution_to_an_iteration(stub_bluz, sdk):
    stub = stub_bluz()
    stub.envelope("GET", "/api/week-templates/t1", {"template": TEMPLATE, "events": []})

    sdk(stub).templates.get("t1", iteration="2026b")

    assert stub.last().path == "/api/week-templates/t1"
    assert stub.last().query.get("it") == ["2026b"]


def test_create_command_posts_the_name(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope("POST", "/api/week-templates", TEMPLATE)

    result = run_cli(stub, "templates", "create", "Holidays", "--copy-times-from", "t1")

    assert result.exit_code == 0
    assert stub.last().body == {"name": "Holidays", "copyTimesFrom": "t1"}


def test_set_times_command_sends_only_given_fields(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope("PATCH", "/api/week-templates/t1", SAVED)

    result = run_cli(
        stub,
        "templates",
        "set-times",
        "t1",
        "--lunch",
        "12:30",
        "--mincha",
        "13:15",
        "--apply",
    )

    assert result.exit_code == 0
    assert stub.last().body == {
        "lunchTime": "12:30",
        "minchaTime": "13:15",
        "applyToCutWeeks": True,
    }


def test_set_times_command_refuses_an_empty_change(stub_bluz, run_cli):
    stub = stub_bluz()

    result = run_cli(stub, "templates", "set-times", "t1")

    assert result.exit_code != 0
    assert stub.requests == []


def test_set_default_and_delete_commands(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope("PATCH", "/api/week-templates/t1", SAVED)
    stub.envelope("DELETE", "/api/week-templates/t2", None)

    assert run_cli(stub, "templates", "set-default", "t1").exit_code == 0
    assert stub.last().body == {"isDefault": True, "applyToCutWeeks": False}

    assert run_cli(stub, "templates", "delete", "t2", "--yes").exit_code == 0
    assert stub.last().method == "DELETE"


def test_cut_command_sends_the_chosen_template(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope("POST", "/api/gantt/curriculums/c-1/cut", {"createdEvents": 1})

    result = run_cli(
        stub, "gantt", "curriculums", "cut", "c-1", "--yes", "--template", "t1"
    )

    assert result.exit_code == 0
    assert stub.last().body["templateId"] == "t1"


def test_settings_list_no_longer_offers_meal_or_prayer_keys(stub_bluz, run_cli):
    result = run_cli(stub_bluz(), "settings", "list")

    assert result.exit_code == 0
    assert "prayerTimes" not in result.stdout
    assert "mealTimes" not in result.stdout
    assert json.loads(result.stdout) == ["schedule"]
