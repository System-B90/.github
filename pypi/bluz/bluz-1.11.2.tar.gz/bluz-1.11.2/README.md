# Bluz (`bluz`)

Script and drive the Bluz scheduling & curriculum server from Python. One
package gives you:

- **A typed Python SDK** — `from bluz import Bluz`. Pydantic models with real
  `date`/`datetime`/`time` fields, navigable like the data itself (iterate a
  curriculum for its syllabuses, look children up by title, call
  `.update()`/`.delete()` on the objects). Ships `py.typed`; passes
  `mypy --strict`.
- **The `bluz` CLI** — every `/api/*` route as a command, built on the same SDK.

It ships with every Bluz version.

## Quick Start

```bash
# 1. Install (from the repo root; [ipython] adds a nicer REPL)
pip install "./cli[ipython]"

# 2. Point it at your Bluz server and store a session token (interactive)
bluz login

# 3. Script it
ipython
```

No repo checkout? Every Bluz instance serves its own matching CLI and the
`bluz` Claude Code plugin (the `/bluz` skill) at
`/api/cli-dist` — the AI assistant panel shows these exact commands:

```bash
pip install --trusted-host <bluz-host> "https://<bluz-host>/api/cli-dist/bluz-<version>-py3-none-any.whl"
bluz login --url https://<bluz-host>   # add --insecure if the host's CA is not trusted
bluz plugin install          # Claude Code plugin bluz@bluz
```

```python
from bluz import Bluz, EventType, today
from datetime import timedelta

bz = Bluz()  # uses `bluz login` / BLUZ_URL + BLUZ_TOKEN
bz.iterations.current()  # Iteration(id='2026b', ...)

cur = bz.gantt.curriculums["Bis90 2026"]  # by title or id — one request, whole tree
for syllabus in cur:  # Curriculum → Syllabus → Module → GanttEvent
    for module in syllabus:
        print(syllabus.title, module.title, sum(e.minimum_duration for e in module))
cur["Mathematics"]["Algebra"]["Intro"].minimum_duration

week = bz.events.list(today(), today() + timedelta(days=7))
week.where(type=EventType.LECTURE)  # Collection: list + lookup/filter helpers
```

```bash
# 4. Or use the CLI
bluz iterations list
bluz rooms list
bluz gantt curriculums list
bluz --json events list --start 2026-01-01T00:00:00Z --end 2026-01-08T00:00:00Z
bluz calendar export-ics --start 2026-01-01T00:00:00Z --end 2026-02-01T00:00:00Z -o schedule.ics

# 4. Or drive the whole thing from a menu
bluz interactive
```

Run any command with `--help` for its options, e.g. `bluz gantt modules --help`.

## Python SDK

### Finding your way around

Tab completion on `bz.` is the table of contents — every API area is an
attribute:

| `bz.`                                                                  | What it covers                                                                         |
| ---------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| `iterations`                                                           | course runs: `current()`, `["2026a"]`, `register`, `patch`, `usage`                    |
| `courses`, `rooms`, `outsiders`, `colors`                              | directories: `list()`, `get(id)`, `["name"]`, `create`, `update`, `delete`             |
| `reservations`                                                         | room bookings: `list(room=, start=, end=)`, `create`, `cancel`                         |
| `events`                                                               | calendar: `list(start, end)`, `get(*ids)`, `create`, `update`, `history`, `export_ics` |
| `drafts`, `snapshots`                                                  | shared drafts; restore points (`snapshot.restore()`)                                   |
| `gantt.curriculums` … `gantt.days`                                     | the curriculum engine, plus the cut pipeline on `gantt.curriculums`                    |
| `settings`, `personal`                                                 | app settings (`schedule()`), the user's own settings                                   |
| `templates`                                                            | week templates: day-start, meal and prayer times plus placed events (#997)             |
| `google`, `hive`, `ai`, `shabbat`, `prayers`, `student_view`, `system` | integrations, Hive reference data, the assistant, the student board, health            |
| `http`                                                                 | the raw client — `bz.http.get("/api/...")` for anything without a method               |

In IPython, `bz.gantt.curriculums?` shows a namespace's docstring and
examples, `Curriculum??` shows the source, and models print as one line
(`Curriculum(id='c1', title='Bis90', is_draft=False, children=7)`) rather than
a field dump. `curriculum.tree()` renders the whole tree.

Plain-text overviews, one item per line (no color codes — fine for logs and
screen readers):

```python
bz.help()                 # every namespace and method
bz.gantt.modules.help()   # one namespace, with signatures
Curriculum.help()         # a model's fields (with wire names), properties, methods
```

Every model's docstring also starts with a generated field table, so
`help(Event)` and `Event?` list the attributes first.

### Signing in

```python
bz = Bluz()                                # reuses `bluz login` / BLUZ_URL + BLUZ_TOKEN
bz = Bluz.login("https://bluz.example")    # browser sign-in, saved for SDK and CLI
bz.whoami()                                # SessionInfo(user=..., expires=...)
bz.require_login()                         # fail fast before any write
```

`bluz auth whoami` is the CLI equivalent, and exits non-zero when signed out.

### Access tokens (scripts, CI)

For unattended use, create a personal access token instead of storing a
login session: in the web UI under **Settings → Personal → טוקני גישה**, or
from a logged-in CLI.

```bash
bluz auth tokens create "nightly export" --expires-in-days 90            # read-only (GET only)
bluz auth tokens create "sync bot" --read-write --expires-in-days 30     # can change data
bluz auth tokens list
bluz auth tokens revoke "nightly export"
```

```bash
export BLUZ_URL=https://bluz.example
export BLUZ_TOKEN=bluz_pat_...      # PowerShell: $env:BLUZ_TOKEN = "bluz_pat_..."
bluz auth whoami
```

```python
bz = Bluz("https://bluz.example", token="bluz_pat_...")
bz.access_tokens.create("ci", scope=AccessTokenScope.READ_WRITE, expires_in_days=30)
```

- Tokens act as you. `ReadOnly` tokens may only make GET requests; anything
  else returns 403. `ReadWrite` tokens can do whatever you can.
- The secret is shown once. The server stores only its SHA-256 hash.
- Lifetimes: 7, 30, 90, 180 or 365 days. No non-expiring tokens.
- A token cannot create tokens; creating one needs a real `bluz login`.
- No Hive through a token. `bz.hive`, `rooms list` (Hive rooms) and the
  curriculum Excel export answer 403 `HiveSessionRequiredError`; use a
  `bluz login` session for those. Hive-derived extras (subject names in
  shuffle alignment, cut names, live lesson push) are skipped. A token never
  borrows the server's Hive service account, so it cannot see more of Hive
  than its owner.

### Conventions

- **Attributes are snake_case** (`event.start_time`); the wire is camelCase.
  Fields the server sends that this version does not know are kept, so
  `model.to_wire()` and every update round-trip losslessly.
- **Dates are typed**: `datetime` (timezone-aware) for instants, `date` for
  calendar days, `time` for `"HH:mm"` settings. Pass `date`/`datetime` or ISO
  strings to any method. `bluz.today()` is today on the Bluz wall clock
  (Asia/Jerusalem).
- **Ids or objects**: every argument that names a thing takes its id or the
  object (`bz.reservations.list(room=bz.rooms["Lab"])`).
- **Lookups**: `api["title or id"]` and `node["child title"]` raise
  `NotFoundError`; `collection.find(...)` returns `None` instead.
- **Iteration scope**: iteration-aware calls default to the current
  iteration. `bz.scoped("2026a")` (or `iteration.scoped()`) is a session that
  reads another iteration by default.
- **Errors**: everything derives from `bluz.BluzError`; server errors are
  `BluzApiError` with `.error_name`, `.error_message`, `.http_status`.
- A response that does not fit its model is kept unvalidated with a
  `ResponseShapeWarning`. Make it fatal in your tests with
  `warnings.simplefilter("error", bluz.errors.ResponseShapeWarning)`.

### Examples

Runnable scripts live inside the package:

```bash
python -m bluz.examples                    # list them
python -m bluz.examples walk_curriculum    # run one against your server
```

| Example               | Shows                                                                               |
| --------------------- | ----------------------------------------------------------------------------------- |
| `script_template`     | boilerplate: flags, login check, dry-run switch, error exit codes                   |
| `login_and_session`   | every way to get a session; whoami and expiry                                       |
| `walk_curriculum`     | tree navigation, per-syllabus totals                                                |
| `build_syllabus`      | creating syllabuses/modules/events on a draft copy                                  |
| `excel_to_syllabus`   | flat Excel sheet (Hebrew or English headers) → syllabuses, create-or-reuse, dry run |
| `excel_wide_syllabus` | hand-made workbook, one sheet per syllabus with module header rows                  |
| `syllabus_to_excel`   | curriculum → Excel in the importer's layout (round trip)                            |
| `weekly_load`         | date-range queries, hours per course                                                |
| `course_tree`         | the course tree with linked syllabuses                                              |
| `room_utilization`    | booked hours per room from events and reservations                                  |
| `shuffle_audit`       | checks every shuffle of a syllabus gets equal time                                  |
| `compare_iterations`  | reading a past iteration with `bz.scoped()`                                         |
| `cut_dry_run`         | the plan-then-confirm cut flow, read-only                                           |
| `safe_bulk_edit`      | snapshot → edit → roll back on failure                                              |
| `export_calendar`     | ICS + CSV export on the Israel wall clock                                           |

The Excel examples need `pip install "./cli[excel]"`.

## Interactive mode

`bluz interactive` opens a searchable menu over the command tree instead of
asking you to remember flags:

1. Pick a group (`gantt`, `events`, `calendar`, …) or a command.
2. Answer one prompt per **required** argument.
3. Add **optional** values from a list — pick `(run it)` when you are done.

The command then runs and renders exactly as it would on the command line, and
the menu comes back, so a session is a sequence of calls rather than one. A
failed call prints its error and the loop continues.

The menu is generated from the real Click command tree, so every command in
this README — and every one added later — appears in it without a second list
to maintain. It needs a terminal: piped or redirected, it tells you to run the
command directly instead of failing inside a prompt.

## Authentication

Bluz authenticates browser requests with a **next-auth session cookie**. The CLI
reuses that same credential:

1. Sign in to Bluz in your browser.
2. Open dev-tools → Application → Cookies and copy the value of
   `__Secure-next-auth.session-token` (HTTPS) or `next-auth.session-token` (HTTP).
3. Run `bluz login` and paste it when prompted.

Credentials are stored per-user (location shown by `bluz auth config`). On
Linux/macOS the config file is written with `0600` permissions. On Windows,
`chmod(0600)` only toggles the read-only DOS attribute and does not restrict
who can read the file — it relies on your user account's own file
permissions, same as most local config files. For self-signed certificates,
pass `--insecure`.

### Configuration precedence

Each setting resolves in this order (first wins):

| Source      | URL        | Token        | Insecure        |
| ----------- | ---------- | ------------ | --------------- |
| CLI flag    | `--url`    | `--token`    | `--insecure`    |
| Environment | `BLUZ_URL` | `BLUZ_TOKEN` | `BLUZ_INSECURE` |
| Config file | `url`      | `token`      | `insecure`      |

A local `.env` is loaded automatically, so `BLUZ_*` vars there are honoured.

## Command groups

| Group                      | What it covers                                                                                                                                                                                                                                                                                                                      |
| -------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `bluz auth`                | `login`, `logout`, `config`, `hive-status`, `ws-ticket`                                                                                                                                                                                                                                                                             |
| `bluz iterations`          | list / current / get / register / patch / set-current / delete / sync-hive                                                                                                                                                                                                                                                          |
| `bluz rooms`               | list / create / update / delete / set-info                                                                                                                                                                                                                                                                                          |
| `bluz courses`             | list / create / update / delete                                                                                                                                                                                                                                                                                                     |
| `bluz reservations`        | list / create / cancel                                                                                                                                                                                                                                                                                                              |
| `bluz outsiders`           | list / create / update / delete                                                                                                                                                                                                                                                                                                     |
| `bluz events`              | list / get / create / update / delete / compare                                                                                                                                                                                                                                                                                     |
| `bluz calendar`            | `drafts` (shared drafts CRUD), `snapshots` (capture / restore / delete), `export-ics`, `validate-alignment` (R-50/R-51)                                                                                                                                                                                                             |
| `bluz settings`            | get / set (+ schedule helpers)                                                                                                                                                                                                                                                                                                      |
| `bluz templates`           | list / get / create / set-times / set-default / delete week templates; `gantt curriculums cut --template <id>` cuts with one                                                                                                                                                                                                        |
| `bluz personal`            | get / set — per-user filters and Google Calendar toggles                                                                                                                                                                                                                                                                            |
| `bluz colors`              | list / get / create / update / delete — custom event colors                                                                                                                                                                                                                                                                         |
| `bluz hive`                | read-only Hive reference data: users / students / classes / subjects / modules / rooms / lessons / avatar, plus `activate-lessons`                                                                                                                                                                                                  |
| `bluz integrations google` | status / connect / disconnect / sync / calendars / select-calendar / purge                                                                                                                                                                                                                                                          |
| `bluz shabbat`             | Shabbat times and Friday/Saturday event bounds for a week (server-resolved)                                                                                                                                                                                                                                                         |
| `bluz prayers`             | Daily prayer windows (Shacharit/Mincha/Arvit) for a week (server-resolved)                                                                                                                                                                                                                                                          |
| `bluz student-view`        | `schedule` (one day of the student board), `report-engagement`, `push-reload`, `refresh-interval [SECONDS]` (how often boards refresh)                                                                                                                                                                                              |
| `bluz ai`                  | `tools` (capabilities + whether AI is configured), `chat` (streaming), `benchmark`                                                                                                                                                                                                                                                  |
| `bluz gantt`               | `curriculums`, `syllabuses`, `modules`, `events`, `days`, `weeks` (CRUD + link/reorder), curriculum export/import/constraints/mappings/duplicate/execution, the cut pipeline (`cut-preview`, `cut-plan`, `cut`, `reload`, `cut-status`, `pull-back`), `execution` / `recreate-occurrence`, shuffle groups and recurrence exceptions |

### The cut pipeline

`cut` materializes a published, iteration-linked curriculum into real schedule
events. Preview first — it runs the same planner with no gating and no writes:

```bash
bluz gantt curriculums cut-preview <id>
bluz gantt curriculums cut <id>          # --force to re-cut; --template / --week / --park-non-template
bluz gantt curriculums reload <id>       # update a cut schedule; --template / --week / --placement auto|park
bluz gantt curriculums cut-status <id>
bluz gantt curriculums pull-back <id>    # soft-delete the generated events
bluz gantt curriculums execution <id>    # תכנון מול ביצוע (plan vs. actual)
```

Gating failures are coded, and nothing is written when they fire: `draft`,
`no-iteration`, `already-cut`, `foreign-cut` (HTTP 409) and `invalid-plan`
(HTTP 400). `foreign-cut` means the linked iteration still holds a live cut of a
_different_ curriculum — pull that one back before cutting this one.

### Parent ids on gantt lists

`bluz gantt <entity> list` returns `{id, title}` rows. Add `--with-parents` to
get each row's parent id too (`syllabusId` on modules, `moduleId` on events,
and so on; `null` when the child has no junction row):

```bash
bluz gantt modules list --with-parents --json
```

### Recurring gantt events

```bash
bluz gantt events except-occurrence <event-id> --curriculum-id <c> --day-id <d>
bluz gantt events materialize <event-id> --curriculum-id <c> --module-id <m> --day-id <d>
bluz gantt events duplicate <event-id> --module-id <m>
bluz gantt curriculums recurrence-exceptions <id>
```

### Iteration scoping

Calendar reads and writes target the current iteration unless you pass
`--iteration/--it` (the server's `it` query param). Writes to a past iteration
are rejected server-side. Supported by `bluz events`, `bluz courses`,
`bluz calendar drafts`, `bluz calendar snapshots` and `bluz calendar export-ics`.
Rooms and outsiders are global (not per-iteration), so they take no flag.

### Google Calendar

`bluz integrations google connect` takes the authorization code produced by the
browser-side Google Identity Services popup — there is no terminal-only OAuth
flow. `status` reports whether the server is configured at all; on deployments
without Google credentials the integration is simply off.

### The AI assistant

```bash
bluz ai tools                      # what it can do; `enabled: false` when no key is configured
bluz ai chat "מה יש ביום ראשון?"    # streams the answer as it is generated
bluz ai benchmark                  # provider self-test (throttled to once an hour)
```

A turn that wants to **write** stops and waits for a human, exactly as in the
browser. Re-run with `--approve <toolCallId> --messages <transcript>` to let one
call through, or pass `--yes` to approve and resume in a single invocation.

Several staff can mirror into one shared calendar: its owner shares it in
Google with "make changes to events", each user runs
`bluz integrations google calendars` and `select-calendar --id <id>` on it, and
every Bluz event is then written there once. `purge --scope orphaned` removes
Bluz-created copies whose event is gone, moved iteration, or left your sync
scope; `purge --scope all` wipes every Bluz-created copy (hand-made Google
events are never touched).

## Global options

- `--json` — emit raw JSON instead of Rich tables (script-friendly).
- `--url`, `--token`, `--insecure/--secure` — override config for one invocation.
- `--version` — print the CLI version.

## Output

By default results render as Rich tables. Add `--json` for machine-readable
output:

```bash
bluz --json iterations list | jq '.[].id'
```

## Versioning

The CLI version is single-sourced in `bluz/__init__.py` and tracks the Bluz
release version — `python -m sb90_deploy publish` bumps it alongside the `package.json`
manifests so every Bluz version ships a matching CLI.
