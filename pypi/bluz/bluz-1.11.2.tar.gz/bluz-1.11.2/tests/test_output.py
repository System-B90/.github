"""
Name: test_output.py
Purpose: Regression tests for rendering server data as Rich tables.
Created: 2026-10-30
Author: Michael K. Steinberg
"""

from __future__ import annotations

from bluz import output


def test_bracketed_text_is_printed_verbatim_not_as_markup(capsys):
    output.render(
        [{"name": "[bold]Intro[/bold]", "notes": "see [/x]"}],
        as_json=False,
    )
    output.render({"[b]": "a[/i]"}, as_json=False)

    printed = capsys.readouterr().out
    assert "[bold]Intro[/bold]" in printed
    assert "see [/x]" in printed
    assert "a[/i]" in printed
