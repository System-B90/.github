"""
Name: test_student_view_requests.py
Purpose: Wire contracts for `bluz student-view` — the day projection and the
         focused-time report the board sends.
Created: 2026-09-18
Author: Michael K. Steinberg
"""

from __future__ import annotations


def test_schedule_reads_the_projection_route(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope("GET", "/api/student-view/schedule", {"events": []})

    result = run_cli(stub, "student-view", "schedule")

    assert result.exit_code == 0
    assert stub.last().method == "GET"
    assert stub.last().path == "/api/student-view/schedule"
    assert stub.last().query == {}


def test_schedule_passes_the_staff_preview_date_and_iteration(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope("GET", "/api/student-view/schedule", {"events": []})

    result = run_cli(
        stub, "student-view", "schedule", "--date", "2026-03-01", "--it", "2026a"
    )

    assert result.exit_code == 0
    assert stub.last().query == {"date": ["2026-03-01"], "it": ["2026a"]}


def test_report_engagement_posts_only_the_duration(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope("POST", "/api/student-view/engagement", None)

    result = run_cli(stub, "student-view", "report-engagement", "45")

    assert result.exit_code == 0
    assert stub.last().method == "POST"
    # No user id and no date: the server takes both from the session and its
    # own clock, so a client can only ever add to its own counter.
    assert stub.last().body == {"seconds": 45}


def test_refresh_interval_merges_into_the_student_view_setting(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope(
        "GET",
        "/api/settings/studentView",
        {"eventNameMode": "full", "typeLabels": {"הרצאה": "ה"}},
    )
    stub.envelope("POST", "/api/settings/studentView", None)

    result = run_cli(stub, "student-view", "refresh-interval", "45")

    assert result.exit_code == 0, result.output
    assert stub.last().method == "POST"
    # The naming options are written back untouched.
    assert stub.last().body == {
        "eventNameMode": "full",
        "typeLabels": {"הרצאה": "ה"},
        "refreshSeconds": 45,
    }


def test_refresh_interval_shows_the_current_value(stub_bluz, run_cli):
    stub = stub_bluz()
    stub.envelope(
        "GET",
        "/api/settings/studentView",
        {"eventNameMode": "symbol", "typeLabels": {}, "refreshSeconds": 30},
    )

    result = run_cli(stub, "--json", "student-view", "refresh-interval")

    assert result.exit_code == 0, result.output
    assert '"refreshSeconds": 30' in result.output
    assert stub.last().method == "GET"


def test_refresh_interval_rejects_out_of_range_without_a_write(stub_bluz, run_cli):
    stub = stub_bluz()

    result = run_cli(stub, "student-view", "refresh-interval", "5")

    assert result.exit_code != 0
    assert all(request.method != "POST" for request in stub.requests)
