"""
Name: calendar.py
Purpose: Shared calendar drafts, snapshots (+restore) and ICS export.
         Thin Typer layer over `bluz.api.calendar` (DraftsAPI, SnapshotsAPI).
Created: 2026-07-30
Author: Michael K. Steinberg
"""

from __future__ import annotations

from pathlib import Path

import typer

from bluz.commands._common import (
    ITERATION_OPTION,
    LIMIT_OPTION,
    OFFSET_OPTION,
    parse_json,
    read_json_file,
    session,
    show,
    write_file,
)
from bluz.output import success

app = typer.Typer(
    help="Shared calendar drafts, snapshots and ICS export.", no_args_is_help=True
)

drafts_app = typer.Typer(help="Shared calendar drafts.", no_args_is_help=True)
snapshots_app = typer.Typer(help="Calendar snapshots.", no_args_is_help=True)


def _events_from(data: str | None, file: Path | None) -> list | None:
    """
    Read an events array from --events JSON or --events-file.

    Returns None when neither flag was passed, so an update that only touches
    the label leaves the draft's events alone instead of clearing them.
    """
    if data is not None and file is not None:
        raise typer.BadParameter("Pass --events or --events-file, not both.")
    if file is not None:
        payload = read_json_file(file, what="--events-file")
    elif data is not None:
        payload = parse_json(data, what="--events")
    else:
        return None
    if not isinstance(payload, list):
        raise typer.BadParameter("Events payload must be a JSON array of events.")
    return payload


# --- drafts -----------------------------------------------------------------


@drafts_app.command("list")
def list_drafts(
    iteration: str = ITERATION_OPTION,
    limit: int = LIMIT_OPTION,
    offset: int = OFFSET_OPTION,
) -> None:
    """List shared draft summaries (newest-updated first)."""
    with session() as bz:
        show(
            bz.drafts.list(iteration=iteration),
            title="Calendar drafts",
            limit=limit,
            offset=offset,
        )


@drafts_app.command("get")
def get_draft(
    draft_id: str = typer.Argument(..., help="Draft id."),
    iteration: str = ITERATION_OPTION,
) -> None:
    """Fetch one draft including its events."""
    with session() as bz:
        show(bz.drafts.get(draft_id, iteration=iteration))


@drafts_app.command("create")
def create_draft(
    label: str = typer.Option(..., "--label", help="Draft label."),
    events: str = typer.Option(None, "--events", help="Events as a JSON array."),
    events_file: Path = typer.Option(
        None, "--events-file", help="Path to a JSON file holding the events array."
    ),
    iteration: str = ITERATION_OPTION,
) -> None:
    """Create a shared draft from a set of events."""
    events_body = _events_from(events, events_file) or []
    with session() as bz:
        result = bz.drafts.create(label, events_body, iteration=iteration)
    success(f"Created draft {label!r}")
    show(result)


@drafts_app.command("update")
def update_draft(
    draft_id: str = typer.Argument(..., help="Draft id."),
    label: str = typer.Option(None, "--label", help="New label (optional)."),
    events: str = typer.Option(None, "--events", help="Events as a JSON array."),
    events_file: Path = typer.Option(
        None, "--events-file", help="Path to a JSON file holding the events array."
    ),
    iteration: str = ITERATION_OPTION,
) -> None:
    """Replace a draft's events (and optionally its label)."""
    events_body = _events_from(events, events_file)
    with session() as bz:
        result = bz.drafts.update(
            draft_id, label=label, events=events_body, iteration=iteration
        )
    success(f"Updated draft {draft_id}")
    show(result)


@drafts_app.command("delete")
def delete_draft(
    draft_id: str = typer.Argument(..., help="Draft id."),
    iteration: str = ITERATION_OPTION,
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Delete a shared draft."""
    if not yes:
        typer.confirm(f"Delete draft {draft_id}?", abort=True)
    with session() as bz:
        bz.drafts.delete(draft_id, iteration=iteration)
    success(f"Deleted draft {draft_id}")


# --- snapshots --------------------------------------------------------------


@snapshots_app.command("list")
def list_snapshots(
    iteration: str = ITERATION_OPTION,
    limit: int = LIMIT_OPTION,
    offset: int = OFFSET_OPTION,
) -> None:
    """List snapshot summaries (newest first)."""
    with session() as bz:
        show(
            bz.snapshots.list(iteration=iteration),
            title="Calendar snapshots",
            limit=limit,
            offset=offset,
        )


@snapshots_app.command("get")
def get_snapshot(
    snapshot_id: str = typer.Argument(..., help="Snapshot id."),
    iteration: str = ITERATION_OPTION,
) -> None:
    """Fetch one snapshot including its captured events."""
    with session() as bz:
        show(bz.snapshots.get(snapshot_id, iteration=iteration))


@snapshots_app.command("create")
def create_snapshot(
    label: str = typer.Option(..., "--label", help="Snapshot label."),
    events: str = typer.Option(None, "--events", help="Events as a JSON array."),
    events_file: Path = typer.Option(
        None, "--events-file", help="Path to a JSON file holding the events array."
    ),
    iteration: str = ITERATION_OPTION,
) -> None:
    """Capture a snapshot from the supplied events."""
    events_body = _events_from(events, events_file) or []
    with session() as bz:
        result = bz.snapshots.create(label, events_body, iteration=iteration)
    success(f"Created snapshot {label!r}")
    show(result)


@snapshots_app.command("delete")
def delete_snapshot(
    snapshot_id: str = typer.Argument(..., help="Snapshot id."),
    iteration: str = ITERATION_OPTION,
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Delete a snapshot."""
    if not yes:
        typer.confirm(f"Delete snapshot {snapshot_id}?", abort=True)
    with session() as bz:
        bz.snapshots.delete(snapshot_id, iteration=iteration)
    success(f"Deleted snapshot {snapshot_id}")


@snapshots_app.command("restore")
def restore_snapshot(
    snapshot_id: str = typer.Argument(..., help="Snapshot id."),
    iteration: str = ITERATION_OPTION,
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Restore the calendar to a snapshot (archives live events in its range)."""
    if not yes:
        typer.confirm(
            f"Restore snapshot {snapshot_id}? Live events in its date range will be archived.",
            abort=True,
        )
    with session() as bz:
        result = bz.snapshots.restore(snapshot_id, iteration=iteration)
    success(f"Restored snapshot {snapshot_id}")
    show(result)


# --- ICS export -------------------------------------------------------------


@app.command("export-ics")
def export_ics(
    start_date: str = typer.Option(..., "--start", "--sd", help="ISO range start."),
    end_date: str = typer.Option(..., "--end", "--ed", help="ISO range end."),
    output: Path = typer.Option(None, "--output", "-o", help="Destination .ics path."),
    iteration: str = ITERATION_OPTION,
) -> None:
    """Export the schedule in a date range as an ICS calendar (max 366 days)."""
    with session() as bz:
        data = bz.events.export_ics(start_date, end_date, iteration=iteration)
    if output is None:
        typer.echo(data.decode("utf-8", errors="replace"))
        return
    write_file(output, data, what="export")
    success(f"Exported schedule → {output} ({len(data)} bytes)")


# --- shuffle alignment ------------------------------------------------------


@app.command("validate-alignment")
def validate_alignment(
    start_date: str = typer.Option(None, "--start", "--sd", help="ISO range start."),
    end_date: str = typer.Option(None, "--end", "--ed", help="ISO range end."),
    draft: str = typer.Option(None, "--draft", help="Check a saved draft instead."),
    events_file: Path = typer.Option(
        None, "--events-file", help="Check an unsaved events array (JSON file)."
    ),
    iteration: str = ITERATION_OPTION,
) -> None:
    """Check R-50/R-51 shuffle alignment; exits 1 when violations exist."""
    events = _events_from(None, events_file)
    if events is None and draft is None and (start_date is None or end_date is None):
        raise typer.BadParameter("Pass --start and --end, --draft, or --events-file.")
    with session() as bz:
        violations = bz.events.validate_alignment(
            start_date,
            end_date,
            draft=draft,
            events=events,
            iteration=iteration,
        )
    if violations:
        show(violations, title="Shuffle alignment violations")
        raise typer.Exit(code=1)
    success("All shuffles aligned.")


@app.command("validate-rule")
def validate_rule(
    rule_id: str = typer.Argument(..., help="Rule id, e.g. R-12 (see /rules)."),
    start_date: str = typer.Option(None, "--start", "--sd", help="ISO range start."),
    end_date: str = typer.Option(None, "--end", "--ed", help="ISO range end."),
    draft: str = typer.Option(None, "--draft", help="Check a saved draft instead."),
    events_file: Path = typer.Option(
        None, "--events-file", help="Check an unsaved events array (JSON file)."
    ),
    iteration: str = ITERATION_OPTION,
) -> None:
    """Check one schedule rule (R-xx); exits 1 when violations exist."""
    events = _events_from(None, events_file)
    if events is None and draft is None and (start_date is None or end_date is None):
        raise typer.BadParameter("Pass --start and --end, --draft, or --events-file.")
    with session() as bz:
        violations = bz.events.validate_rule(
            rule_id,
            start_date,
            end_date,
            draft=draft,
            events=events,
            iteration=iteration,
        )
    if violations:
        show(violations, title=f"{rule_id} violations")
        raise typer.Exit(code=1)
    success(f"{rule_id} holds.")


app.add_typer(drafts_app, name="drafts")
app.add_typer(snapshots_app, name="snapshots")
