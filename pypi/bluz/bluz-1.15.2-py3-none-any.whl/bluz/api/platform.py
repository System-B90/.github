"""
Name: platform.py
Purpose: The smaller API namespaces — app settings, personal settings, Google
         Calendar, Hive reference data, the AI assistant, the student board
         and platform probes (health, Hive status, WebSocket ticket).
         Mirrors ui/src/api-client/{settings,personal-settings,
         google-calendar,hive,ai,student-view}.ts.
Created: 2026-10-02
Author: Michael K. Steinberg
"""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from datetime import date
from typing import TYPE_CHECKING, Any, Literal

from bluz.api._base import Resource, iso, ref
from bluz.models._base import BluzModel, Collection, camel_payload
from bluz.models.misc import (
    AccessToken,
    AccessTokenScope,
    AiCapabilities,
    CreatedAccessToken,
    GoogleCalendarList,
    GoogleCalendarStatus,
    GooglePurgeResult,
    GoogleSyncResult,
    HealthReport,
    HiveActivationTick,
    PersonalSettings,
    PrayerWindow,
    ScheduleSettings,
    ShabbatWindow,
    StudentMonitor,
    StudentSchedule,
    WeekTemplate,
    WeekTemplateSaveResult,
)

if TYPE_CHECKING:
    from bluz.models.iterations import Iteration

__all__ = [
    "KNOWN_SETTING_KEYS",
    "SCHEDULE_SETTING_KEY",
    "AccessTokensAPI",
    "AiAPI",
    "GoogleCalendarAPI",
    "HiveAPI",
    "PersonalSettingsAPI",
    "PrayersAPI",
    "SettingsAPI",
    "ShabbatAPI",
    "StudentViewAPI",
    "WeekTemplatesAPI",
]

_SETTINGS = "/api/settings"
_PERSONAL = "/api/personal-settings"
_ACCESS_TOKENS = "/api/access-tokens"
_GOOGLE = "/api/integrations/google-calendar"
_HIVE = "/api/hive"
_AI = "/api/ai"
_STUDENT = "/api/student-view"
# Deliberately outside student-view/: tracking data *about* students (staff only).
_STUDENT_MONITOR = "/api/student-monitor"
_SHABBAT = "/api/shabbat"
_PRAYERS = "/api/prayers"
_CLI_DIST = "/api/cli-dist"
_TEMPLATES = "/api/week-templates"

# Well-known setting keys. Kept in step with api-shared/types/settings/* —
# the server has no enumeration route. Meal and prayer times moved into week
# templates (#997): see `bz.templates`.
SCHEDULE_SETTING_KEY = "schedule"
HIVE_INTEGRATION_SETTING_KEY = "hiveIntegration"
STUDENT_VIEW_SETTING_KEY = "studentView"
KNOWN_SETTING_KEYS = [
    SCHEDULE_SETTING_KEY,
    HIVE_INTEGRATION_SETTING_KEY,
    STUDENT_VIEW_SETTING_KEY,
]
# Bounds the server accepts for studentView.refreshSeconds (student-view.ts).
STUDENT_REFRESH_MIN_SECONDS = 10
STUDENT_REFRESH_MAX_SECONDS = 3600


def _body(value: Any) -> Any:
    return value.to_wire() if isinstance(value, BluzModel) else value


class SettingsAPI(Resource):
    """`bz.settings` — application-wide keyed settings.

    Examples:
        >>> bz.settings.schedule().calendar_day_start_time
        >>> bz.settings.set("schedule", {"calendarDayStartTime": "07:00", ...})
    """

    keys = KNOWN_SETTING_KEYS

    def get(self, name: str, *, iteration: str | Iteration | None = None) -> Any:
        """A setting's raw value. Settings are stored per iteration."""
        return self._http.get(f"{_SETTINGS}/{name}", params={"it": self._it(iteration)})

    def set(
        self, name: str, value: Any, *, iteration: str | Iteration | None = None
    ) -> None:
        """Write a setting (a model or plain JSON)."""
        self._http.post(
            f"{_SETTINGS}/{name}", json=_body(value), params={"it": self._it(iteration)}
        )

    def schedule(self, *, iteration: str | Iteration | None = None) -> ScheduleSettings:
        """The calendar's visible hours (`time` values)."""
        return self._one(
            ScheduleSettings, self.get(SCHEDULE_SETTING_KEY, iteration=iteration) or {}
        )

    def set_schedule(self, value: ScheduleSettings | Mapping[str, Any]) -> None:
        """Write the schedule settings (a model or a wire dict)."""
        self.set(SCHEDULE_SETTING_KEY, value)

    def update_hive_integration(self, **fields: Any) -> dict[str, Any]:
        """Merge `fields` into the Hive integration setting; `None` drops one.

        The setting is one object, so whatever is not named is kept as stored
        (the lesson driver defaults to the activator, as the server does).
        """
        current = dict(self.get(HIVE_INTEGRATION_SETTING_KEY) or {})
        current.setdefault("lessonDriver", "activator")
        for key, value in fields.items():
            if value is None:
                current.pop(key, None)
            else:
                current[key] = value
        self.set(HIVE_INTEGRATION_SETTING_KEY, current)
        return current

    def set_hive_calendar_file(self, path: str | None) -> dict[str, Any]:
        """Point the Hive ICS sidecar at `path` (relative to its shared dir).

        `None` clears it, so the sidecar's own HIVE_CALENDAR_FILE applies.
        """
        return self.update_hive_integration(calendarFile=path or None)

    def set_hive_feed_window(self, hours: int) -> dict[str, Any]:
        """Hours before the start and after the end of today the feed carries."""
        return self.update_hive_integration(feedWindowHours=hours)


class WeekTemplatesAPI(Resource):
    """`bz.templates` — schedule week templates (#997).

    A template is a week of placed events plus the day-start, meal and prayer
    times a cut uses. Cutting a week with one pins its placed events to their
    weekday and time; the planner fills in around them.

    Examples:
        >>> bz.templates.list()
        >>> bz.templates.update("tpl-id", lunch_time="12:30", apply_to_cut_weeks=True)
    """

    def list(self) -> Collection[WeekTemplate]:
        """Every template, the default first."""
        return self._many(WeekTemplate, self._http.get(_TEMPLATES) or [])

    def get(
        self, template: WeekTemplate | str, *, iteration: str | Iteration | None = None
    ) -> Any:
        """A template and its events, courses resolved against `iteration`."""
        return self._http.get(
            f"{_TEMPLATES}/{_template_ref(template)}",
            params={"it": self._it(iteration)},
        )

    def create(self, name: str, *, copy_times_from: str | None = None) -> WeekTemplate:
        """A new template, seeded with the linked curriculum's recurring events, parked."""
        body: dict[str, Any] = {"name": name}
        if copy_times_from:
            body["copyTimesFrom"] = copy_times_from
        return self._one(WeekTemplate, self._http.post(_TEMPLATES, json=body))

    def update(
        self,
        template: WeekTemplate | str,
        *,
        apply_to_cut_weeks: bool = False,
        **fields: Any,
    ) -> WeekTemplateSaveResult:
        """Rename, retime (`lunch_time="12:30"`, ...) or set `is_default=True`.

        `apply_to_cut_weeks` re-plans the weeks already cut with this template;
        events edited by hand since the cut are left alone.
        """
        body = {**camel_payload(**fields), "applyToCutWeeks": apply_to_cut_weeks}
        return self._one(
            WeekTemplateSaveResult,
            self._http.patch(f"{_TEMPLATES}/{_template_ref(template)}", json=body),
        )

    def delete(self, template: WeekTemplate | str) -> None:
        """Delete a template. The default one cannot be deleted."""
        self._http.delete(f"{_TEMPLATES}/{_template_ref(template)}")


def _template_ref(template: WeekTemplate | str) -> str:
    return template.id if isinstance(template, WeekTemplate) else template


class PersonalSettingsAPI(Resource):
    """`bz.personal` — the signed-in user's own preferences."""

    def get(self) -> PersonalSettings:
        """The signed-in user's own settings."""
        return self._one(PersonalSettings, self._http.get(_PERSONAL) or {})

    def replace(
        self, settings: PersonalSettings | Mapping[str, Any]
    ) -> PersonalSettings:
        """Write the whole document verbatim."""
        return self._one(
            PersonalSettings, self._http.post(_PERSONAL, json=_body(settings))
        )

    def update(self, **fields: Any) -> PersonalSettings:
        """Change some fields; the rest are read first and carried over
        (the endpoint replaces the whole document)."""
        current = self._http.get(_PERSONAL) or {}
        return self.replace({**current, **camel_payload(**fields)})


class AccessTokensAPI(Resource):
    """`bz.access_tokens` — personal access tokens for scripts and the CLI.

    A token acts as you. `READ_ONLY` tokens may only read (GET); `READ_WRITE`
    tokens can do anything you can. Creating one needs a real sign-in
    (`bluz login`): a token cannot mint further tokens.

    Examples:
        >>> created = bz.access_tokens.create("nightly export", expires_in_days=90)
        >>> created.token  # shown once — store it as BLUZ_TOKEN
        >>> bz.access_tokens.list()
        >>> bz.access_tokens["nightly export"].revoke()
    """

    def list(self) -> Collection[AccessToken]:
        """Your tokens, newest first (expired ones included until cleaned up)."""
        return self._many(AccessToken, self._http.get(_ACCESS_TOKENS))

    def __getitem__(self, name_or_id: str) -> AccessToken:
        return self.list()[name_or_id]

    def create(
        self,
        name: str,
        *,
        scope: AccessTokenScope | str = AccessTokenScope.READ_ONLY,
        expires_in_days: int = 30,
    ) -> CreatedAccessToken:
        """Mint a token. `expires_in_days` is one of 7, 30, 90, 180, 365."""
        data = self._http.post(
            _ACCESS_TOKENS,
            json={
                "name": name,
                "scope": str(AccessTokenScope(scope)),
                "expiresInDays": expires_in_days,
            },
        )
        return self._one(CreatedAccessToken, data)

    def revoke(self, token: AccessToken | str) -> None:
        """Revoke a token (or its id) immediately."""
        self._http.delete(f"{_ACCESS_TOKENS}/{ref(token)}")

    def current(self) -> AccessToken:
        """The token this session is signed in with (fails on a session login)."""
        data = self._http.get(f"{_ACCESS_TOKENS}/current") or {}
        return self._one(AccessToken, data.get("accessToken") or {})


class GoogleCalendarAPI(Resource):
    """`bz.google` — the per-user Google Calendar mirror."""

    def status(self) -> GoogleCalendarStatus:
        """Whether Google Calendar is configured on the server and linked for you."""
        return self._one(GoogleCalendarStatus, self._http.get(f"{_GOOGLE}/status"))

    def connect(self, code: str) -> None:
        """Exchange an authorization code (from the web UI's GIS popup) for tokens."""
        self._http.post(f"{_GOOGLE}/connect", json={"code": code})

    def disconnect(self) -> None:
        """Revoke your stored Google tokens."""
        self._http.post(f"{_GOOGLE}/disconnect")

    def sync(self) -> GoogleSyncResult:
        """Manual two-way sync over the next 90 days."""
        return self._one(GoogleSyncResult, self._http.post(f"{_GOOGLE}/sync") or {})

    def calendars(self) -> GoogleCalendarList:
        """Calendars you can mirror into, and which one is selected."""
        return self._one(GoogleCalendarList, self._http.get(f"{_GOOGLE}/calendars"))

    def select_calendar(
        self, calendar_id: str | None = None, *, create_new: bool = False
    ) -> Any:
        """Point the link at another calendar — exactly one of `calendar_id` / `create_new`."""
        if bool(calendar_id) == create_new:
            raise ValueError("Pass exactly one of calendar_id or create_new=True.")
        payload: dict[str, Any] = (
            {"createNew": True} if create_new else {"calendarId": calendar_id}
        )
        return self._http.post(f"{_GOOGLE}/calendars", json=payload)

    def purge(
        self, scope: Literal["orphaned", "all"] = "orphaned"
    ) -> GooglePurgeResult:
        """Remove Bluz-created events from the linked Google calendar."""
        if scope not in ("orphaned", "all"):
            raise ValueError("scope must be 'orphaned' or 'all'.")
        return self._one(
            GooglePurgeResult,
            self._http.post(f"{_GOOGLE}/purge", json={"scope": scope}) or {},
        )


class HiveAPI(Resource):
    """`bz.hive` — Hive LMS reference data, proxied read-only through Bluz.

    Results are plain dicts (Hive's own schema). For a typed Hive client, use
    PyHive directly.
    """

    def _list(
        self, name: str, params: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        return self._http.get(f"{_HIVE}/{name}", params=params) or []

    def users(self) -> list[dict[str, Any]]:
        """Hive staff users."""
        return self._list("users")

    def students(self) -> list[dict[str, Any]]:
        """Hive students."""
        return self._list("students")

    def classes(self) -> list[dict[str, Any]]:
        """Hive classes (student groups — Bluz shuffles map onto these)."""
        return self._list("classes")

    def subjects(self) -> list[dict[str, Any]]:
        """Hive subjects."""
        return self._list("subjects")

    def modules(self) -> list[dict[str, Any]]:
        """Hive modules."""
        return self._list("modules")

    def rooms(self) -> list[dict[str, Any]]:
        """Hive rooms."""
        return self._list("rooms")

    def lessons(
        self,
        *,
        module_id: int | str | None = None,
        program_ids: list[int] | str | None = None,
    ) -> list[dict[str, Any]]:
        """Hive lessons, optionally by module or parent program ids."""
        if isinstance(program_ids, list):
            program_ids = ",".join(str(pid) for pid in program_ids)
        return self._list(
            "lessons",
            {
                "module__id": module_id,
                "module__parent_subject__parent_program_id__in": program_ids,
            },
        )

    def activate_lessons(self) -> HiveActivationTick:
        """Run one lesson-activation pass now (idempotent)."""
        return self._one(
            HiveActivationTick, self._http.post(f"{_HIVE}/lesson-activation")
        )

    def avatar(self, user_id: int | str) -> bytes | None:
        """A Hive user's avatar image bytes, or None when they have none."""
        data = self._http.get(f"{_HIVE}/users/avatars/{user_id}")
        return data if isinstance(data, bytes) else None


class AiAPI(Resource):
    """`bz.ai` — the in-app assistant."""

    def tools(self) -> AiCapabilities:
        """What the assistant can do (`enabled: False` when no model key is set)."""
        return self._one(AiCapabilities, self._http.get(f"{_AI}/tools"))

    def models(self) -> Any:
        """Models the configured backend lists (`models` empty, with `error`,
        when it cannot list them)."""
        return self._http.get(f"{_AI}/models")

    def benchmark(self) -> Any:
        """Provider self-test (throttled server-side to once an hour)."""
        return self._http.post(f"{_AI}/benchmark")

    def stream(self, payload: Mapping[str, Any]) -> Iterator[dict[str, Any]]:
        """Raw chat frames for a full request payload (see `chat`)."""
        return self._http.stream_sse(f"{_AI}/chat", json=dict(payload))

    def chat(
        self,
        prompt: str | None,
        *,
        messages: list[dict[str, Any]] | None = None,
        iteration: str | Iteration | None = None,
        curriculum_id: str | None = None,
        model: str | None = None,
        approved_tool_call_ids: list[str] | None = None,
    ) -> Iterator[dict[str, Any]]:
        """Ask one question; yields stream frames (`delta`, `tool_start`, ..., `done`).

        Write tools stop the turn with `awaitingApproval` on the `done` frame;
        to continue, resend the transcript with `approved_tool_call_ids` and
        `prompt=None`: a new user message there would sit between the model's
        tool calls and their results.
        """
        turn = [] if prompt is None else [{"role": "user", "content": prompt}]
        payload = {
            "messages": [*(messages or []), *turn],
            "iterationId": self._it(iteration),
            "curriculumId": curriculum_id,
            "model": model,
            "approvedToolCallIds": list(approved_tool_call_ids or []),
        }
        return self.stream(
            {key: value for key, value in payload.items() if value not in (None, [])}
        )

    def ask(self, prompt: str, **kwargs: Any) -> str:
        """Convenience: the assistant's full text answer to one question."""
        return "".join(
            frame.get("text", "")
            for frame in self.chat(prompt, **kwargs)
            if frame.get("type") == "delta"
        )


class StudentViewAPI(Resource):
    """`bz.student_view` — the read-only per-day student board."""

    def schedule(
        self,
        day: date | str | None = None,
        *,
        iteration: str | Iteration | None = None,
    ) -> StudentSchedule:
        """One day of the board (staff may preview any day)."""
        return self._one(
            StudentSchedule,
            self._http.get(
                f"{_STUDENT}/schedule",
                params={"date": iso(day), "it": self._it(iteration)},
            ),
        )

    def report_engagement(self, seconds: int) -> None:
        """Add focused seconds to the caller's own daily counter."""
        self._http.post(f"{_STUDENT}/engagement", json={"seconds": seconds})

    def monitor(self, day: date | str | None = None) -> StudentMonitor:
        """Every student's focused time and suspected attempts on `day` (staff only).

        Defaults to the server's current app day.
        """
        return self._one(
            StudentMonitor,
            self._http.get(_STUDENT_MONITOR, params={"date": iso(day)}),
        )

    def push_reload(self) -> None:
        """Force every open student board to reload (staff only)."""
        self._http.post("/api/student-reload")

    def refresh_interval(self) -> int | None:
        """The staff-set board refresh interval in seconds, or None for the default.

        Boards do not follow edits live; they refetch on this interval.
        """
        stored = self._http.get(
            f"{_SETTINGS}/{STUDENT_VIEW_SETTING_KEY}", params={"it": None}
        )
        return (stored or {}).get("refreshSeconds")

    def set_refresh_interval(self, seconds: int) -> None:
        """Set how often every student board refetches (staff only).

        The rest of the student-view setting (the naming options) is written
        back as stored. Open boards switch at their next refetch.
        """
        if not STUDENT_REFRESH_MIN_SECONDS <= seconds <= STUDENT_REFRESH_MAX_SECONDS:
            raise ValueError(
                f"seconds must be {STUDENT_REFRESH_MIN_SECONDS}-"
                f"{STUDENT_REFRESH_MAX_SECONDS}, got {seconds}"
            )
        current = dict(
            self._http.get(
                f"{_SETTINGS}/{STUDENT_VIEW_SETTING_KEY}", params={"it": None}
            )
            or {"eventNameMode": "symbol", "typeLabels": {}}
        )
        current["refreshSeconds"] = seconds
        self._http.post(f"{_SETTINGS}/{STUDENT_VIEW_SETTING_KEY}", json=current)


class ShabbatAPI(Resource):
    """`bz.shabbat` — Shabbat times, resolved server-side (no client hebcal)."""

    def window(self, day: date | str) -> ShabbatWindow:
        """Candle lighting, havdalah and Friday/Saturday event bounds for `day`'s week."""
        return self._one(
            ShabbatWindow,
            self._http.get(_SHABBAT, params={"date": iso(day)}),
        )


class PrayersAPI(Resource):
    """`bz.prayers` — daily prayer windows, resolved server-side (schedule tint, not events)."""

    def week(
        self, day: date | str, *, iteration: str | Iteration | None = None
    ) -> Collection[PrayerWindow]:
        """Shacharit/Mincha/Arvit windows of every day in `day`'s week."""
        return self._many(
            PrayerWindow,
            self._http.get(
                _PRAYERS, params={"date": iso(day), "it": self._it(iteration)}
            ),
        )


class SystemAPI(Resource):
    """`bz.system` — platform probes."""

    def health(self) -> HealthReport:
        """`/api/health`. Answers its own shape (not the envelope), 503 when unhealthy."""
        return self._one(HealthReport, self._http.get_raw("/api/health"))

    def hive_status(self) -> Any:
        """Whether the server can reach Hive with the session's credentials."""
        return self._http.get("/api/auth/hive-status")

    def cli_dist(self) -> dict[str, str | None]:
        """`/api/cli-dist` — file names of the served CLI wheel and skills archive."""
        manifest: dict[str, str | None] = self._http.get_raw(_CLI_DIST)
        return manifest

    def cli_dist_file(self, name: str) -> bytes:
        """One file from `/api/cli-dist` (the wheel or the skills archive)."""
        data: bytes = self._http.get(f"{_CLI_DIST}/{name}")
        return data

    def ws_ticket(self) -> Any:
        """A short-lived WebSocket ticket (a bare `{ticket}`, not the envelope)."""
        return self._http.get_raw("/api/ws-ticket")
