"""
Name: calendar.py
Purpose: `bz.events`, `bz.drafts`, `bz.snapshots` — the schedule itself, its
         change log, shared drafts, restore points and the ICS export.
         Mirrors ui/src/api-client/{calendar,calendar-drafts,
         calendar-snapshots}.ts.
Created: 2026-10-02
Author: Michael K. Steinberg
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from datetime import date, datetime
from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from bluz.api._base import Resource, iso, ref
from bluz.errors import BluzApiError
from bluz.models._base import BluzModel, Collection, camel_payload, to_wire
from bluz.models.calendar import (
    CalendarDraft,
    CalendarSnapshot,
    Event,
    EventHistoryEntry,
    SnapshotRestoreResult,
)

if TYPE_CHECKING:
    from bluz.models.iterations import Iteration

__all__ = ["DraftsAPI", "EventsAPI", "SnapshotsAPI"]

_BASE = "/api/event"
_DRAFTS = "/api/calendar/drafts"
_SNAPSHOTS = "/api/calendar/snapshots"
_ALIGNMENT = "/api/calendar/validate/shuffle-alignment"

DateLike = datetime | date | str


def _event_payload(event: Event | Mapping[str, Any], fields: dict[str, Any]) -> Any:
    return camel_payload(event, **fields)


class EventsAPI(Resource):
    """`bz.events` — calendar events.

    Examples:
        >>> week = bz.events.list("2026-11-01", "2026-11-08")
        >>> lectures = week.where(type=EventType.LECTURE)
        >>> bz.events.export_ics("2026-11-01", "2026-12-01")[:100]
    """

    def list(
        self,
        start: DateLike,
        end: DateLike,
        *,
        iteration: str | Iteration | None = None,
    ) -> Collection[Event]:
        """Events in `[start, end)`. Dates may be `date`, `datetime` or ISO strings."""
        params = {"sd": iso(start), "ed": iso(end), "it": self._it(iteration)}
        return self._many(Event, self._http.get(_BASE, params=params))

    def get(
        self,
        *ids: str,
        iteration: str | Iteration | None = None,
    ) -> Collection[Event]:
        """Events by id: `bz.events.get("a", "b")`."""
        params = {"ids": ",".join(ids), "it": self._it(iteration)}
        return self._many(Event, self._http.get(_BASE, params=params))

    def create(
        self,
        event: Event | Mapping[str, Any] | None = None,
        /,
        *,
        iteration: str | Iteration | None = None,
        **fields: Any,
    ) -> Event:
        """Create an event from a model, a wire dict and/or snake_case fields."""
        return self._one(
            Event,
            self._http.put(
                _BASE,
                json=_event_payload(event or {}, fields),
                params={"it": self._it(iteration)},
            ),
        )

    def update(
        self,
        event: Event | Mapping[str, Any] | None = None,
        /,
        *,
        iteration: str | Iteration | None = None,
        **fields: Any,
    ) -> Event:
        """Replace an event (the payload must include `id`)."""
        return self._one(
            Event,
            self._http.post(
                _BASE,
                json=_event_payload(event or {}, fields),
                params={"it": self._it(iteration)},
            ),
        )

    def delete(
        self, event: Event | str, *, iteration: str | Iteration | None = None
    ) -> None:
        """Delete (archive) an event by id or object."""
        self._http.delete(_BASE, json=ref(event), params={"it": self._it(iteration)})

    def create_many(
        self,
        events: Iterable[Event | Mapping[str, Any]],
        *,
        iteration: str | Iteration | None = None,
    ) -> Collection[Event]:
        """Create many events in one request (one insertMany, one undo step)."""
        return self._many(
            Event,
            self._http.put(
                f"{_BASE}/bulk",
                json=_events_body(events) or [],
                params={"it": self._it(iteration)},
            ),
        )

    def delete_many(
        self,
        events: Iterable[Event | str],
        *,
        iteration: str | Iteration | None = None,
    ) -> None:
        """Delete (archive) many events by id or object in one request."""
        self._http.delete(
            f"{_BASE}/bulk",
            json=[ref(event) for event in events],
            params={"it": self._it(iteration)},
        )

    def compare(
        self,
        start: DateLike,
        end: DateLike,
        iteration_a: str | Iteration | None = None,
        iteration_b: str | Iteration | None = None,
    ) -> Any:
        """Diff the events of two iterations over the same range."""
        params = {
            "sd": iso(start),
            "ed": iso(end),
            "itA": ref(iteration_a),
            "itB": ref(iteration_b),
        }
        return self._http.get(f"{_BASE}/compare", params=params)

    def history(
        self, event: Event | str, *, iteration: str | Iteration | None = None
    ) -> Collection[EventHistoryEntry]:
        """Change log for one event, newest first."""
        return self._many(
            EventHistoryEntry,
            self._http.get(
                f"{_BASE}/history",
                params={"id": ref(event), "it": self._it(iteration)},
            ),
        )

    def export_ics(
        self,
        start: DateLike,
        end: DateLike,
        *,
        iteration: str | Iteration | None = None,
    ) -> bytes:
        """The schedule in a range (max 366 days) as an ICS calendar."""
        data = self._http.get(
            "/api/event/export/ics",
            params={"sd": iso(start), "ed": iso(end), "it": self._it(iteration)},
        )
        if isinstance(data, str):
            data = data.encode("utf-8")
        if not isinstance(data, bytes):
            raise BluzApiError(
                "InvalidResponse",
                f"Expected an ICS payload, got {type(data).__name__}: {str(data)[:200]}",
            )
        return data

    def validate_alignment(
        self,
        start: DateLike | None = None,
        end: DateLike | None = None,
        *,
        draft: CalendarDraft | str | None = None,
        events: Iterable[Event | Mapping[str, Any]] | None = None,
        iteration: str | Iteration | None = None,
    ) -> Sequence[dict[str, Any]]:
        """R-50/R-51 shuffle-alignment violations (#1000); empty means aligned.

        Checks exactly one source: inline `events` (an unsaved draft), a saved
        `draft`, or the live calendar between `start` and `end`.
        """
        body = _schedule_source(start, end, draft=draft, events=events)
        return list(
            self._http.post(_ALIGNMENT, json=body, params={"it": self._it(iteration)})
            or []
        )

    def validate_rule(
        self,
        rule_id: str,
        start: DateLike | None = None,
        end: DateLike | None = None,
        *,
        draft: CalendarDraft | str | None = None,
        events: Iterable[Event | Mapping[str, Any]] | None = None,
        iteration: str | Iteration | None = None,
    ) -> Sequence[dict[str, Any]]:
        """One schedule rule's violations (`R-xx`, see /rules); empty means it holds.

        Same sources as `validate_alignment`. The server rejects a rule it does
        not check automatically.
        """
        body = _schedule_source(start, end, draft=draft, events=events)
        return list(
            self._http.post(
                f"/api/calendar/validate/{quote(rule_id, safe='')}",
                json=body,
                params={"it": self._it(iteration)},
            )
            or []
        )


def _schedule_source(
    start: DateLike | None,
    end: DateLike | None,
    *,
    draft: CalendarDraft | str | None,
    events: Iterable[Event | Mapping[str, Any]] | None,
) -> dict[str, Any]:
    """Exactly one schedule source: inline `events`, a saved `draft`, or a range."""
    if events is not None:
        return {"events": _events_body(events)}
    if draft is not None:
        return {"draftId": ref(draft)}
    if start is not None and end is not None:
        return {"start": iso(start), "end": iso(end)}
    raise ValueError("Pass events, draft, or both start and end.")


def _events_body(events: Iterable[Event | Mapping[str, Any]] | None) -> Any:
    if events is None:
        return None
    return [
        to_wire(event) if isinstance(event, BluzModel) else event for event in events
    ]


class DraftsAPI(Resource):
    """`bz.drafts` — named, shared, editable working copies of the calendar."""

    def list(
        self, *, iteration: str | Iteration | None = None
    ) -> Collection[CalendarDraft]:
        """Draft summaries, newest-updated first (no events — see `get`)."""
        return self._many(
            CalendarDraft, self._http.get(_DRAFTS, params={"it": self._it(iteration)})
        )

    def get(
        self, draft: CalendarDraft | str, *, iteration: str | Iteration | None = None
    ) -> CalendarDraft:
        """One draft including its events."""
        params = {"id": ref(draft), "it": self._it(iteration)}
        return self._one(CalendarDraft, self._http.get(_DRAFTS, params=params))

    def create(
        self,
        label: str,
        events: Iterable[Event | Mapping[str, Any]] = (),
        *,
        iteration: str | Iteration | None = None,
    ) -> CalendarDraft:
        """Create a shared draft holding `events` (models or wire dicts)."""
        body = {"label": label, "events": _events_body(events) or []}
        return self._one(
            CalendarDraft,
            self._http.post(_DRAFTS, json=body, params={"it": self._it(iteration)}),
        )

    def update(
        self,
        draft: CalendarDraft | str,
        *,
        label: str | None = None,
        events: Iterable[Event | Mapping[str, Any]] | None = None,
        iteration: str | Iteration | None = None,
    ) -> CalendarDraft:
        """Relabel and/or replace the events. Omitted arguments are left alone."""
        body = camel_payload(id=ref(draft), label=label, events=_events_body(events))
        return self._one(
            CalendarDraft,
            self._http.put(_DRAFTS, json=body, params={"it": self._it(iteration)}),
        )

    def delete(
        self, draft: CalendarDraft | str, *, iteration: str | Iteration | None = None
    ) -> None:
        """Delete a shared draft."""
        self._http.delete(_DRAFTS, params={"id": ref(draft), "it": self._it(iteration)})


class SnapshotsAPI(Resource):
    """`bz.snapshots` — immutable restore points of the calendar."""

    def list(
        self, *, iteration: str | Iteration | None = None
    ) -> Collection[CalendarSnapshot]:
        """Snapshot summaries, newest first (no events — see `get`)."""
        return self._many(
            CalendarSnapshot,
            self._http.get(_SNAPSHOTS, params={"it": self._it(iteration)}),
        )

    def get(
        self,
        snapshot: CalendarSnapshot | str,
        *,
        iteration: str | Iteration | None = None,
    ) -> CalendarSnapshot:
        """One snapshot including its captured events."""
        params = {"id": ref(snapshot), "it": self._it(iteration)}
        return self._one(CalendarSnapshot, self._http.get(_SNAPSHOTS, params=params))

    def create(
        self,
        label: str,
        events: Iterable[Event | Mapping[str, Any]] = (),
        *,
        iteration: str | Iteration | None = None,
    ) -> CalendarSnapshot:
        """Capture a restore point from `events` (models or wire dicts)."""
        body = {"label": label, "events": _events_body(events) or []}
        return self._one(
            CalendarSnapshot,
            self._http.post(_SNAPSHOTS, json=body, params={"it": self._it(iteration)}),
        )

    def delete(
        self,
        snapshot: CalendarSnapshot | str,
        *,
        iteration: str | Iteration | None = None,
    ) -> None:
        """Delete a snapshot (the live calendar is not touched)."""
        self._http.delete(
            _SNAPSHOTS, params={"id": ref(snapshot), "it": self._it(iteration)}
        )

    def restore(
        self,
        snapshot: CalendarSnapshot | str,
        *,
        iteration: str | Iteration | None = None,
    ) -> SnapshotRestoreResult:
        """Restore the calendar to a snapshot (archives live events in its range)."""
        return self._one(
            SnapshotRestoreResult,
            self._http.post(
                f"{_SNAPSHOTS}/restore",
                params={"id": ref(snapshot), "it": self._it(iteration)},
            ),
        )
