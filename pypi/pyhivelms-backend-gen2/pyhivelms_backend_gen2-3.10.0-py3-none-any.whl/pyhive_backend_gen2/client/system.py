"""System mixin for HiveClient.

Covers server time and the PowerSync token endpoint. Meant only for use as a
mixin on HiveClient.
"""

from .client_shared import ClientCoreMixin


class SystemClientMixin(ClientCoreMixin):
    """Mixin that exposes system-level endpoints."""

    def get_server_time(self) -> str:
        """Return the server's current time string."""
        data = self.get_json("/api/core/time/")
        assert isinstance(data, str)
        return data
