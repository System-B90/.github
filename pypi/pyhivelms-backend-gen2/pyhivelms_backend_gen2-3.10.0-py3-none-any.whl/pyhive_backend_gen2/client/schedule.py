"""Schedule mixin for HiveClient.

Covers calendar events, event categories/tags/taggings/attendees/instructors and
the daily review generator under ``/api/core/schedule/``. Meant only for use as
a mixin on HiveClient.
"""

import datetime
from collections.abc import Iterable
from typing import TYPE_CHECKING

from ..types.schedule_event import ScheduleEvent
from .client_shared import ClientCoreMixin
from .utils import UUIDLike, resolve_item_or_uuid

if TYPE_CHECKING:
    from ..types.lesson import Lesson
    from ..types.module import Module


def _optional_str(value: UUIDLike | None) -> str | None:
    return None if value is None else str(value)


def _optional_iso(value: datetime.datetime | None) -> str | None:
    return None if value is None else value.isoformat()


class ScheduleClientMixin(ClientCoreMixin):  # pylint: disable=too-many-public-methods
    """Mixin that exposes schedule endpoints."""

    def get_schedule_events(
        self,
        *,
        start__lt: datetime.datetime | None = None,
        end__gt: datetime.datetime | None = None,
        start__gte: datetime.datetime | None = None,
        end__lte: datetime.datetime | None = None,
        lesson__id: "UUIDLike | Lesson | None" = None,
    ) -> Iterable[ScheduleEvent]:
        """Yield ``ScheduleEvent`` objects (Hive 8 filters start__lt/end__gt, older start__gte/end__lte)."""
        return self._get_core_items(
            "/api/core/schedule/events/",
            ScheduleEvent,
            start__lt=_optional_iso(start__lt),
            end__gt=_optional_iso(end__gt),
            start__gte=_optional_iso(start__gte),
            end__lte=_optional_iso(end__lte),
            lesson__id=_optional_str(resolve_item_or_uuid(lesson__id)),
        )

    def get_schedule_event(self, event_id: "UUIDLike | ScheduleEvent") -> ScheduleEvent:
        """Return a single ``ScheduleEvent`` by its id."""
        from . import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.get(f"/api/core/schedule/events/{resolve_item_or_uuid(event_id)}/")
        assert isinstance(data, dict)
        return ScheduleEvent.from_dict(data, hive_client=self)

    def delete_schedule_event(self, event_id: "UUIDLike | ScheduleEvent") -> None:
        """Delete a schedule event by id (Hive <= 7.3.0; Hive 8 events are read-only)."""
        self.delete(f"/api/core/schedule/events/{resolve_item_or_uuid(event_id)}/")

    # --- Categories ---

    # --- Attendees / instructors / tags / taggings (Hive <= 7.3.0 only) ---

    # --- Daily review ---

    def create_daily_review(
        self, date: datetime.date, *, show_lesson_names: bool = True
    ) -> "Module":
        """Generate (and persist) the Daily Review module for ``date``."""
        from ..types.module import Module
        from . import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.post(
            "/api/core/schedule/daily_review/",
            {"date": date.isoformat(), "show_lesson_names": show_lesson_names},
        )
        assert isinstance(data, dict)
        return Module.from_dict(data, hive_client=self)
