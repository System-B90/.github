"""Hive API Client module."""

# Rebuild Pydantic models to resolve forward references
from ..types.assignment import Assignment
from ..types.assignment_notification import AssignmentNotification
from ..types.assignment_response import AssignmentResponse
from ..types.assignment_response_content import AssignmentResponseContent
from ..types.autocheck_status import AutoCheckStatus
from ..types.class_ import Class
from ..types.client_info import ClientInfo
from ..types.event import Event
from ..types.event_attendees_type_0_item import EventAttendeesType0Item
from ..types.event_color import EventColor
from ..types.exercise import Exercise
from ..types.form_field import FormField
from ..types.help_ import Help
from ..types.help_notification import HelpNotification
from ..types.help_response import HelpResponse
from ..types.help_response_segel_nested import HelpResponseSegelNested
from ..types.lesson import Lesson
from ..types.lesson_rule import LessonRule
from ..types.me import Me
from ..types.module import Module
from ..types.notification import Notification
from ..types.notification_nested import NotificationNested
from ..types.program import Program
from ..types.queue import Queue
from ..types.queue_item import QueueItem
from ..types.schedule_event import ScheduleEvent
from ..types.seating import Seating
from ..types.sso_application import SsoApplication
from ..types.subject import Subject
from ..types.tag import Tag
from ..types.top_help_response_checker import TopHelpResponseChecker
from ..types.user import User
from .client import HiveClient  # re-export

Assignment.model_rebuild()
AssignmentNotification.model_rebuild()
AssignmentResponse.model_rebuild()
AssignmentResponseContent.model_rebuild()
AutoCheckStatus.model_rebuild()
Class.model_rebuild()
ClientInfo.model_rebuild()
Event.model_rebuild()
EventAttendeesType0Item.model_rebuild()
EventColor.model_rebuild()
Exercise.model_rebuild()
FormField.model_rebuild()
Help.model_rebuild()
HelpNotification.model_rebuild()
HelpResponse.model_rebuild()
HelpResponseSegelNested.model_rebuild()
Lesson.model_rebuild()
LessonRule.model_rebuild()
Me.model_rebuild()
Module.model_rebuild()
Notification.model_rebuild()
NotificationNested.model_rebuild()
Program.model_rebuild()
Queue.model_rebuild()
QueueItem.model_rebuild()
ScheduleEvent.model_rebuild()
Seating.model_rebuild()
SsoApplication.model_rebuild()
Subject.model_rebuild()
Tag.model_rebuild()
TopHelpResponseChecker.model_rebuild()
User.model_rebuild()

__all__ = ["HiveClient"]
