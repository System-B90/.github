"""Shared client utilities and common mixin base for Hive API access.

- ``ClientCoreMixin``: base class that provides ``_get_core_items`` used by resource mixins.
"""

from collections.abc import Iterable
from typing import Any, cast

import httpx

from pyhive.src.authenticated_hive_client import AuthenticatedHiveClient

from .utils import CoreItemTypeT


class ClientCoreMixin(AuthenticatedHiveClient):
    """Common mixin base that exposes ``_get_core_items`` for list endpoints.

    This relies on the authenticated transport provided by the base client and is designed to be used only on
    the composed ``HiveClient``.
    """

    def _get_core_items(
        self,
        endpoint: str,
        item_type: type[CoreItemTypeT],
        /,
        extra_ctor_params: dict[str, Any] | None = None,
        **kwargs: (
            str
            | int
            | bool
            | None
            | list[str]
            | list[int]
            | list[bool]
            | Iterable[str]
            | Iterable[int]
            | Iterable[bool]
        ),
    ) -> Iterable[CoreItemTypeT]:
        """Yield typed items from a list endpoint, with ``kwargs`` as query parameters."""
        from . import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"

        if extra_ctor_params is None:
            extra_ctor_params = {}

        query_params = httpx.QueryParams()
        for name, value in kwargs.items():
            if value is None:
                continue
            if isinstance(value, list):
                query_params = query_params.set(name, ",".join(str(x) for x in value))
            else:
                query_params = query_params.set(name, value)

        for raw in self.paginate(endpoint, params=query_params):
            # Every curated model defines from_dict; HiveCoreItem itself does not.
            yield cast(Any, item_type).from_dict(
                raw, **extra_ctor_params, hive_client=self
            )
