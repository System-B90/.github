"""PyHive backend for the Hive API generation of Hive 8.0.4 (gen4).

Serves every generation until each gets its own backend (#42 phase 3b).
"""
