"""
Name: hive_api.py
Purpose: Everything this backend's Hive API generation offers, with a HiveClient
    pinned to it (#42 phase 4).
Created: 2026-11-25

Imported as ``pyhive.hive.v<X_Y_Z>`` for every Hive version this backend
serves (the same module object for each). Its ``HiveClient`` raises
``GenerationMismatchError`` against a server of another generation instead of
adapting the way ``pyhive.HiveClient`` does.
"""

from typing import ClassVar

from .client import HiveClient as _BackendClient
from .public_types import *  # pylint: disable=wildcard-import
from .public_types import __all__ as _PUBLIC_TYPES

assert _BackendClient.BACKEND is not None
GENERATION: str = _BackendClient.BACKEND.removeprefix("pyhive_backend_")


class HiveClient(_BackendClient):  # pylint: disable=too-many-ancestors,abstract-method
    """A Hive client for exactly this Hive API generation."""

    GENERATION: ClassVar[str | None] = GENERATION


__all__ = ["GENERATION", "HiveClient", *_PUBLIC_TYPES]  # noqa: PLE0604
