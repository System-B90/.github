"""High-level Hive API client aggregator."""

from types import TracebackType
from typing import TYPE_CHECKING, Literal, Optional, Union

from typing_extensions import Self

from pyhive.client.sso_utils import generate_sso_client_credentials, get_sso_token

from ..src.access_tokens import (
    is_valid_personal_access_token,
    looks_like_personal_access_token,
)
from ..src.api_versions import generation_for
from .assignment_responses import AssignmentResponsesClientMixin
from .assignments import AssignmentClientMixin
from .classes import ClassesClientMixin
from .exercises import ExerciseClientMixin
from .fields import FieldsClientMixin
from .help import HelpClientMixin
from .lessons import LessonClientMixin
from .modules import ModuleClientMixin
from .notifications import NotificationClientMixin
from .programs import ProgramClientMixin
from .queues import QueuesClientMixin
from .schedule import ScheduleClientMixin
from .seating import SeatingClientMixin
from .sso_admin import SsoAdminClientMixin
from .subjects import SubjectClientMixin
from .system import SystemClientMixin
from .tags import TagClientMixin
from .users import UserClientMixin
from .version import VersionClientMixin

if TYPE_CHECKING:
    from httpx import Timeout
    from httpx._types import ProxyTypes


class HiveClient(  # pylint: disable=too-many-ancestors,abstract-method
    ProgramClientMixin,
    SubjectClientMixin,
    ModuleClientMixin,
    ExerciseClientMixin,
    AssignmentClientMixin,
    UserClientMixin,
    ClassesClientMixin,
    FieldsClientMixin,
    AssignmentResponsesClientMixin,
    QueuesClientMixin,
    HelpClientMixin,
    VersionClientMixin,
    LessonClientMixin,
    NotificationClientMixin,
    ScheduleClientMixin,
    SeatingClientMixin,
    SsoAdminClientMixin,
    SystemClientMixin,
    TagClientMixin,
):
    """Aggregated HTTP client for accessing Hive API resources."""

    def __init__(
        self,
        username: str,
        password: str,
        hive_url: str,
        *,
        skip_version_check: bool = False,
        timeout: Union["Timeout", float] | None = None,
        headers: dict[str, str] | None = None,
        verify: bool | str | None = None,
        proxy: Optional["ProxyTypes"] = None,
        existing_token: str | None = None,
        auth_strategy: Literal["sso", "cache", "access_token"] | None = None,
        refresh_token: str | None = None,
        **kwargs: object,
    ):
        super().__init__(
            username,
            password,
            hive_url,
            timeout=timeout,
            headers=headers,
            verify=verify,
            proxy=proxy,
            existing_token=existing_token,
            auth_strategy=auth_strategy,
            refresh_token=refresh_token,
            **kwargs,
        )
        if not skip_version_check:
            self._api_version_check()

    @classmethod
    def from_api_token(
        cls,
        api_token: str,
        hive_url: str,
        *,
        refresh_token: str | None = None,
        timeout: Union["Timeout", float] | None = None,
        headers: dict[str, str] | None = None,
        verify: bool | str | None = None,
        proxy: Optional["ProxyTypes"] = None,
        skip_version_check: bool = False,
        auth_strategy: Literal["sso", "cache"] | None = None,
        **kwargs: object,
    ) -> "HiveClient":
        """Construct a client using an existing Hive API token.

        This is mainly intended for advanced integrations. In most user-facing
        scenarios, prefer :meth:`from_sso`, which performs the browser-based
        Hive SSO flow and then creates the client from the resulting token.

        By default (no ``refresh_token``/``auth_strategy``) this uses the
        bare token as-is: automatic refresh is *not* supported, and if it
        expires you must create a new :class:`HiveClient` with a
        freshly-issued token. Passing ``auth_strategy="sso"`` or
        ``"cache"`` together with a ``refresh_token`` enables automatic
        refresh on a 401 (the same mechanism :meth:`from_sso` uses).

        A personal access token (``hive_pat_...``) given without a refresh
        token is handled exactly like :meth:`from_access_token`.
        """

        if (
            auth_strategy is None
            and refresh_token is None
            and looks_like_personal_access_token(api_token)
        ):
            return cls.from_access_token(
                api_token,
                hive_url,
                timeout=timeout,
                headers=headers,
                verify=verify,
                proxy=proxy,
                skip_version_check=skip_version_check,
                **kwargs,
            )

        return cls(
            "token-auth",  # placeholder username for repr/debugging
            "unused",
            hive_url,
            timeout=timeout,
            headers=headers,
            verify=verify,
            proxy=proxy,
            skip_version_check=skip_version_check,
            existing_token=api_token,
            refresh_token=refresh_token,
            auth_strategy=auth_strategy,
            **kwargs,
        )

    @classmethod
    def from_access_token(
        cls,
        access_token: str,
        hive_url: str,
        *,
        timeout: Union["Timeout", float] | None = None,
        headers: dict[str, str] | None = None,
        verify: bool | str | None = None,
        proxy: Optional["ProxyTypes"] = None,
        skip_version_check: bool = False,
        **kwargs: object,
    ) -> "HiveClient":
        """Construct a client from a Hive personal access token (``hive_pat_...``).

        Create one in Hive from the account menu (Access Tokens). The token is
        never refreshed: once it expires or is revoked, requests raise
        :class:`~pyhive.src.access_tokens.AccessTokenRejectedError`. A
        read-only token raises :class:`httpx.HTTPStatusError` (403) on writes.

        Raises:
            ValueError: ``access_token`` is not a well formed Hive personal
                access token (checked offline, including its checksum).
        """

        access_token = access_token.strip()
        if not is_valid_personal_access_token(access_token):
            msg = (
                "Not a valid Hive personal access token: expected 'hive_pat_' "
                "followed by 46 letters and digits. Check it was copied whole."
            )
            raise ValueError(msg)

        return cls(
            "access-token",  # placeholder username for repr/debugging
            "unused",
            hive_url,
            timeout=timeout,
            headers=headers,
            verify=verify,
            proxy=proxy,
            skip_version_check=skip_version_check,
            existing_token=access_token,
            auth_strategy="access_token",
            refresh_token=None,
            **kwargs,
        )

    @classmethod
    def from_sso(
        cls,
        hive_url: str,
        *,
        timeout: Union["Timeout", float] | None = None,
        headers: dict[str, str] | None = None,
        verify: bool | str | None = None,
        proxy: Optional["ProxyTypes"] = None,
        skip_version_check: bool = False,
        **kwargs: object,
    ) -> "HiveClient":
        """
        Instantiate a HiveClient using interactive browser-based SSO authentication.

        Args:
            hive_url (str): The base URL of the Hive server.
            timeout (Optional[Union[Timeout, float]]): Request timeout configuration.
            headers (Optional[dict[str, str]]): Additional headers to apply to the client.
            verify (Optional[Union[bool, str]]): SSL verification requirements.
            proxy (Optional[ProxyTypes]): Proxy configuration.
            skip_version_check (bool): Bypass API version compatibility checking.
            **kwargs (object): Additional client configuration parameters.

        Returns:
            HiveClient: An authenticated instance of the HiveClient.
        """

        # Trigger the browser-based OIDC flow
        user_token = get_sso_token(hive_url=hive_url, verify=verify)

        # Delegate to from_api_token to construct the actual client
        return cls.from_api_token(
            api_token=user_token[0],
            refresh_token=user_token[1],
            hive_url=hive_url,
            timeout=timeout,
            headers=headers,
            verify=verify,
            proxy=proxy,
            skip_version_check=skip_version_check,
            auth_strategy="sso",
            **kwargs,
        )

    def __repr__(self) -> str:
        """Return a short representation including username and hive_url.

        The representation intentionally omits secrets.
        """

        return f"HiveClient({self.username!r}, input(), {self.hive_url!r})"

    def __enter__(self) -> Self:
        """Enter context manager and return this client instance.

        The underlying :class:`httpx.Client` is managed by this object's
        lifecycle; entering the context returns the authenticated client so
        callers can perform API calls.
        """
        return self

    def __exit__(
        self,
        type_: type[BaseException] | None,
        value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        """Exit the context and close the underlying httpx session.

        This delegates to the managed :class:`httpx.Client`'s ``__exit__``
        method to ensure resources are released.
        """

        self._session.__exit__(type_, value, traceback)

    def _api_version_check(self) -> None:
        """Validate that the Hive server runs a release PyHive has verified.

        Fetches the server version via ``get_hive_version`` and looks it up,
        by exact match, in the ``hive_versions.toml`` table.

        Raises:
            UnverifiedHiveVersionError: (a ``RuntimeError``) if the server
                version is not in the table.
        """
        generation_for(self.get_hive_version())

    def register_sso_service(
        self,
        service_name: str,
        redirect_uris: list[str] | str | None = None,
    ) -> dict[str, str]:
        return generate_sso_client_credentials(self, service_name, redirect_uris)
