"""Queues mixin for HiveClient.

Queues (a module's queue, or one user's own queue) and the items inside them:
listing, creation, editing, duplication and deletion, plus adding, reordering,
expanding and removing items.
"""

from collections.abc import Iterable
from typing import TYPE_CHECKING, Any, Optional

from pyhive.client.utils import resolve_item_or_id

from ..src.types.enums.queue_rule_enum import QueueRuleEnum
from ..src.types.queue import Queue
from ..src.types.queue_item import QueueItem
from .client_shared import ClientCoreMixin

if TYPE_CHECKING:
    from ..src.types.class_ import ClassLike
    from ..src.types.exercise import ExerciseLike
    from ..src.types.module import ModuleLike
    from ..src.types.queue import QueueLike
    from ..src.types.queue_item import QueueItemLike
    from ..src.types.user import UserLike


def _items_path(queue: "QueueLike") -> str:
    return f"/api/core/queues/{resolve_item_or_id(queue)}/items/"


class QueuesClientMixin(ClientCoreMixin):
    """Mixin that exposes queue and queue-item endpoints."""

    def get_queues(  # pylint: disable=too-many-arguments
        self,
        *,
        user: Optional["UserLike"] = None,
        module: Optional["ModuleLike"] = None,
        class_: Optional["ClassLike"] = None,
        mentor: Optional["UserLike"] = None,
        program__id__in: list[int] | None = None,
        user_queues: bool | None = None,
    ) -> Iterable[Queue]:
        """Yield queues, filtered by owner, class, mentor or program.

        ``user_queues=True`` keeps only users' own queues, ``False`` only module queues.
        """
        return self._get_core_items(
            "/api/core/queues/",
            Queue,
            user=None if user is None else resolve_item_or_id(user),
            module=None if module is None else resolve_item_or_id(module),
            class__id=None if class_ is None else resolve_item_or_id(class_),
            mentor__id=None if mentor is None else resolve_item_or_id(mentor),
            program__id__in=program__id__in,
            user__isnull=None if user_queues is None else str(not user_queues).lower(),
        )

    def get_queue(self, queue_id: int) -> Queue:
        """Return a single queue by ``queue_id``."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.get(f"/api/core/queues/{queue_id}/")
        assert isinstance(data, dict)
        return Queue.from_dict(
            data,
            hive_client=self,
        )

    def create_queue(
        self,
        name: str,
        description: str = "",
        module: Optional["ModuleLike"] = None,
        user: Optional["UserLike"] = None,
    ) -> Queue:
        """Create a queue owned by exactly one of ``module`` or ``user``."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        if (module is None) == (user is None):
            raise ValueError("A queue belongs to exactly one of a module or a user.")

        payload: dict[str, str | int | None] = {
            "name": name,
            "description": description,
            "module": None,
            "user": None,
        }

        if module is not None:
            payload["module"] = resolve_item_or_id(module)
        if user is not None:
            payload["user"] = resolve_item_or_id(user)

        return Queue.from_dict(
            self.post("/api/core/queues/", payload),
            hive_client=self,
        )

    def update_queue(
        self,
        queue: "QueueLike",
        *,
        name: str | None = None,
        description: str | None = None,
    ) -> Queue:
        """Rename or re-describe a queue; ``None`` leaves a field as it is."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        fields = {
            key: value
            for key, value in (("name", name), ("description", description))
            if value is not None
        }
        data = self.patch(f"/api/core/queues/{resolve_item_or_id(queue)}/", fields)
        return Queue.from_dict(data, hive_client=self)

    def duplicate_queue(self, queue: "QueueLike", name: str) -> Queue:
        """Copy a queue and its items under ``name``; the copy keeps the original's owner."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.post(
            f"/api/core/queues/{resolve_item_or_id(queue)}/duplicate/", {"name": name}
        )
        return Queue.from_dict(data, hive_client=self)

    def delete_queue(self, queue: "QueueLike") -> None:
        """Delete a queue by id or instance."""
        self.delete(f"/api/core/queues/{resolve_item_or_id(queue)}/")

    # --- Items ---

    def get_queue_items(self, queue: "QueueLike") -> Iterable[QueueItem]:
        """Yield the items of ``queue`` in order."""
        return self._get_core_items(
            _items_path(queue),
            QueueItem,
            extra_ctor_params={"queue_id": resolve_item_or_id(queue)},
        )

    def get_queue_item(self, queue: "QueueLike", item: "QueueItemLike") -> QueueItem:
        """Return one item of ``queue``."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.get(f"{_items_path(queue)}{resolve_item_or_id(item)}/")
        assert isinstance(data, dict)
        return QueueItem.from_dict(
            data, hive_client=self, queue_id=resolve_item_or_id(queue)
        )

    def add_queue_item(  # pylint: disable=too-many-arguments
        self,
        queue: "QueueLike",
        *,
        exercise: Optional["ExerciseLike"] = None,
        nested_queue: "Queue | int | None" = None,
        module: Optional["ModuleLike"] = None,
        order: int | None = None,
        queue_rule: QueueRuleEnum | str = QueueRuleEnum.CHOOSE,
        enabled: bool = True,
        continue_on_redo: bool = False,
    ) -> QueueItem:
        """Add one of an exercise, a nested queue or a module's exercises to ``queue``.

        ``order`` is the 0-based position (later items shift down); default appends.
        """
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        targets = [x for x in (exercise, nested_queue, module) if x is not None]
        if len(targets) != 1:
            raise ValueError("Pass exactly one of exercise, nested_queue or module.")
        if order is None:
            order = sum(1 for _ in self.get_queue_items(queue))
        # Hive requires every key, unused targets included.
        payload: dict[str, Any] = {
            "order": order,
            "set_exercise_id": None
            if exercise is None
            else resolve_item_or_id(exercise),
            "set_nested_queue_id": (
                None if nested_queue is None else resolve_item_or_id(nested_queue)
            ),
            "set_module_id": None if module is None else resolve_item_or_id(module),
            "set_tags_id": [],
            "queue_rule": QueueRuleEnum(queue_rule).value,
            "enabled": enabled,
            "continue_on_redo": continue_on_redo,
        }
        data = self.post(_items_path(queue), payload)
        return QueueItem.from_dict(
            data, hive_client=self, queue_id=resolve_item_or_id(queue)
        )

    def update_queue_item(
        self,
        queue: "QueueLike",
        item: "QueueItemLike",
        *,
        queue_rule: QueueRuleEnum | str | None = None,
        enabled: bool | None = None,
        continue_on_redo: bool | None = None,
    ) -> QueueItem:
        """Change an item's rule or flags; ``None`` leaves a setting as it is.

        Hive only reorders through :meth:`move_queue_item`.
        """
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        # Hive's PATCH handler reads "order" unconditionally (500 without it) and
        # rejects any change to it, so send the item's current order, read fresh.
        current = self.get_queue_item(queue, item)
        fields: dict[str, Any] = {"order": current.order}
        if queue_rule is not None:
            fields["queue_rule"] = QueueRuleEnum(queue_rule).value
        if enabled is not None:
            fields["enabled"] = enabled
        if continue_on_redo is not None:
            fields["continue_on_redo"] = continue_on_redo
        data = self.patch(f"{_items_path(queue)}{resolve_item_or_id(item)}/", fields)
        return QueueItem.from_dict(
            data, hive_client=self, queue_id=resolve_item_or_id(queue)
        )

    def move_queue_item(
        self, queue: "QueueLike", item: "QueueItemLike", new_order: int
    ) -> QueueItem:
        """Move an item to 0-based position ``new_order``; Hive renumbers the rest."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.post(
            f"{_items_path(queue)}{resolve_item_or_id(item)}/move/",
            {"new_order": new_order},
        )
        return QueueItem.from_dict(
            data, hive_client=self, queue_id=resolve_item_or_id(queue)
        )

    def expand_queue_item(self, queue: "QueueLike", item: "QueueItemLike") -> None:
        """Replace a nested-queue item with the nested queue's own items, in place."""
        self.post_action(f"{_items_path(queue)}{resolve_item_or_id(item)}/expand/", {})

    def delete_queue_item(self, queue: "QueueLike", item: "QueueItemLike") -> None:
        """Remove an item from ``queue``."""
        self.delete(f"{_items_path(queue)}{resolve_item_or_id(item)}/")
