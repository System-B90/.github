"""
Exercise resource mixin for HiveClient.

Provides listing and retrieval of Exercise records, with rich filtering, plus
creation, update, deletion, student notification and file/preview downloads,
via the Hive API. Intended for mixing into the main HiveClient only.
"""

from collections.abc import Iterable, Mapping
from typing import TYPE_CHECKING, Any, Optional

import httpx

from ..src.types.enums.assignment_response_type_enum import AssignmentResponseTypeEnum
from ..src.types.enums.exercise_patbas_enum import PatbasEnum
from ..src.types.enums.exercise_preview_types import ExercisePreviewTypes
from ..src.types.exercise import Exercise
from .client_shared import ClientCoreMixin
from .utils import resolve_item_or_id

if TYPE_CHECKING:
    from ..src.types.class_ import ClassLike
    from ..src.types.exercise import ExerciseLike
    from ..src.types.form_field import FormField
    from ..src.types.module import ModuleLike
    from ..src.types.subject import SubjectLike


class ExerciseClientMixin(ClientCoreMixin):
    """
    Mixin class providing exercise-related API methods for HiveClient.

    Methods
    -------
    get_exercises(parent_module__id=None, parent_module=None, parent_subject=None, exercise_name=None, ...)
        List all or filtered exercises via the Hive API. Supports advanced hierarchical filtering.
    get_exercise(exercise_id)
        Retrieve a single exercise by id.
    create_exercise(...)
        Create a new exercise under a parent module.
    update_exercise(exercise)
        Commit the local state of an exercise to the server (PUT).
    patch_exercise(exercise, **fields)
        Partially update an exercise (PATCH).
    delete_exercise(exercise)
        Delete an exercise by id or instance.
    notify_exercise_students(exercise, classes, response_type, contents, ...)
        Post a response to the exercise's assignments for students in ``classes``.
    get_exercise_student_files(exercise) / get_exercise_patbas_files(exercise)
        Download an exercise's student or patbas files.
    get_exercise_preview(exercise, asset=None) / get_exercise_patbas_preview(exercise, asset=None)
        Download an exercise's preview or patbas preview.
    """

    # Fields the exercise endpoints accept on write; the rest are server-computed.
    _EXERCISE_WRITABLE_FIELDS = (
        "name",
        "parent_module",
        "download",
        "preview",
        "patbas_preview",
        "patbas_download",
        "is_lecture",
        "style",
        "order",
        "tags",
        "patbas",
        "on_creation_data",
        "autocheck_tag",
        "autodone",
        "expected_duration",
        "segel_brief",
    )

    # NOTE: Intended to be used only as part of the HiveClient composite class
    def get_exercises(  # pylint: disable=too-many-arguments
        self,
        *,
        parent_module__id: int | None = None,
        parent_module__parent_subject__id: int | None = None,
        parent_module__parent_subject__parent_program__id__in: list[int] | None = None,
        queue__id: int | None = None,
        tags__id__in: list[int] | None = None,
        parent_module: Optional["ModuleLike"] = None,
        parent_subject: Optional["SubjectLike"] = None,
        exercise_name: str | None = None,
    ) -> Iterable[Exercise]:
        """Yield ``Exercise`` objects, supporting rich parent-based filtering."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        if parent_module is not None and parent_module__id is not None:
            assert parent_module__id == resolve_item_or_id(parent_module)
        parent_module__id = (
            parent_module__id
            if parent_module__id is not None
            else resolve_item_or_id(parent_module)
        )
        if parent_subject is not None and parent_module__parent_subject__id is not None:
            assert parent_module__parent_subject__id == resolve_item_or_id(
                parent_subject
            )
        parent_module__parent_subject__id = (
            parent_module__parent_subject__id
            if parent_module__parent_subject__id is not None
            else resolve_item_or_id(parent_subject)
        )
        exercises: Iterable[Exercise] = self._get_core_items(
            "/api/core/course/exercises/",
            Exercise,
            parent_module__id=parent_module__id,
            parent_module__parent_subject__id=parent_module__parent_subject__id,
            parent_module__parent_subject__parent_program__id__in=parent_module__parent_subject__parent_program__id__in,
            queue__id=queue__id,
            tags__id__in=tags__id__in,
        )
        if exercise_name is not None:
            exercises = filter(lambda e: e.name == exercise_name, exercises)
        return exercises

    def get_exercise(self, exercise_id: int) -> Exercise:
        """Return a single ``Exercise`` by its id."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = self.get(f"/api/core/course/exercises/{exercise_id}/")
        assert isinstance(data, dict)
        return Exercise.from_dict(
            data,
            hive_client=self,
        )

    def create_exercise(
        self,
        name: str,
        order: int,
        parent_module: "ModuleLike",
        *,
        download: bool = False,
        preview: ExercisePreviewTypes = ExercisePreviewTypes.DISABLED,
        patbas_preview: ExercisePreviewTypes = ExercisePreviewTypes.DISABLED,
        style: str = "",
        patbas_download: bool = False,
        patbas: PatbasEnum = PatbasEnum.NEVER,
        on_creation_data: str = "",
        autocheck_tag: str = "",
        autodone: bool = False,
        expected_duration: str = "",
        segel_brief: str = "",
        is_lecture: bool = False,
        tags: list[str] | None = None,
    ) -> Exercise:
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"

        payload: dict[str, str | int | list[int] | list[str]] = {
            "name": name,
            "parent_module": resolve_item_or_id(parent_module),
            "download": download,
            "preview": preview,
            "patbas_preview": patbas_preview,
            "patbas_download": patbas_download,
            "is_lecture": is_lecture,
            "style": style,
            "order": order,
            "tags": tags if tags is not None else [],
            "patbas": patbas,
            "on_creation_data": on_creation_data,
            "autocheck_tag": autocheck_tag,
            "autodone": autodone,
            "expected_duration": expected_duration,
            "segel_brief": segel_brief,
        }

        return Exercise.from_dict(
            self.post("/api/core/course/exercises/", payload),
            hive_client=self,
        )

    def delete_exercise(self, exercise: "ExerciseLike") -> None:
        self.delete(f"/api/core/course/exercises/{resolve_item_or_id(exercise)}/")

    def update_exercise(self, exercise: Exercise) -> Exercise:
        """Commits the local state of the exercise to the server."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        data = exercise.to_dict()
        payload = {k: data[k] for k in self._EXERCISE_WRITABLE_FIELDS if k in data}
        response = self.put(f"/api/core/course/exercises/{exercise.id}/", payload)
        return Exercise.from_dict(response, hive_client=self)

    def patch_exercise(self, exercise: "ExerciseLike", **fields: object) -> Exercise:
        """Partially update an exercise with the given fields."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        response = self.patch(
            f"/api/core/course/exercises/{resolve_item_or_id(exercise)}/", dict(fields)
        )
        return Exercise.from_dict(response, hive_client=self)

    def notify_exercise_students(  # pylint: disable=too-many-arguments
        self,
        exercise: "ExerciseLike",
        *,
        classes: Iterable["ClassLike"],
        response_type: AssignmentResponseTypeEnum,
        contents: Mapping["FormField | int", str],
        currently_assigned: bool = False,
        dear_student: bool = True,
        hide_checker_name: bool | None = None,
        segel_only: bool | None = None,
    ) -> None:
        """Post a response, filling ``contents`` (form field -> text), to the exercise's students in ``classes``."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        payload: dict[str, Any] = {
            "classes": [resolve_item_or_id(c) for c in classes],
            "response_type": response_type.value,
            "contents": [
                {"field": resolve_item_or_id(field), "content": content}
                for field, content in contents.items()
            ],
            "currently_assigned": currently_assigned,
            "dear_student": dear_student,
        }
        if hide_checker_name is not None:
            payload["hide_checker_name"] = hide_checker_name
        if segel_only is not None:
            payload["segel_only"] = segel_only
        self._post(
            f"/api/core/course/exercises/{resolve_item_or_id(exercise)}/notify_students/",
            payload,
        ).raise_for_status()

    def get_exercise_student_files(self, exercise: "ExerciseLike") -> bytes | None:
        """Return the exercise's student files, or ``None`` if it has none."""
        return self._get_exercise_file(exercise, "student_files")

    def get_exercise_patbas_files(self, exercise: "ExerciseLike") -> bytes | None:
        """Return the exercise's patbas files, or ``None`` if it has none."""
        return self._get_exercise_file(exercise, "patbas_files")

    def get_exercise_preview(
        self, exercise: "ExerciseLike", asset: str | None = None
    ) -> bytes | None:
        """Return the exercise's preview (or one ``asset`` of it), or ``None``."""
        return self._get_exercise_file(exercise, "preview", asset=asset)

    def get_exercise_patbas_preview(
        self, exercise: "ExerciseLike", asset: str | None = None
    ) -> bytes | None:
        """Return the exercise's patbas preview (or one ``asset`` of it), or ``None``."""
        return self._get_exercise_file(exercise, "patbas_preview", asset=asset)

    def _get_exercise_file(
        self, exercise: "ExerciseLike", action: str, **params: Any
    ) -> bytes | None:
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        response = self._session.get(
            f"/api/core/course/exercises/{resolve_item_or_id(exercise)}/{action}/",
            params={k: v for k, v in params.items() if v is not None},
        )
        if response.status_code == httpx.codes.NOT_FOUND.value:
            return None
        response.raise_for_status()
        return response.content
