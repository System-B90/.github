"""
Name: users.py
Purpose: User management CLI subparser for Hive utilizing RESTful CRUD operations.
Created: 2026-04-07
Author: Michael K. Steinberg
"""

from enum import Enum
from typing import TYPE_CHECKING, Annotated, Any, cast

from typer import (  # pyright: ignore[reportUnknownVariableType]
    Argument,
    Context,
    Option,
    colors,
    echo,
    secho,
)

from pyhive.cli.base import PyHiveTyper
from pyhive.cli.client_factory import (
    HIVE_URL_OPTION,
    VERIFY_OPTION,
    get_hive_client,
)
from pyhive.cli.formatter import (
    print_error_and_exit,
    print_formatted_list,
    print_info,
    print_result,
)
from pyhive.cli.queues import id_or_none
from pyhive.src.types.common import UNSET, Unset
from pyhive.types import ClearanceEnum, GenderEnum, StatusEnum


def _member_names(enum_cls: type[Enum]) -> type[Enum]:
    names = {name: name for name in enum_cls.__members__}
    return cast("type[Enum]", Enum(f"{enum_cls.__name__}Name", names, type=str))


# Typer builds a case-insensitive choice from an Enum annotation; Option(click_type=...)
# was removed in Typer 0.29. The str mixin keeps the parsed values usable as plain names.
if TYPE_CHECKING:
    ClearanceName = str
    GenderName = str
    StatusName = str
else:
    ClearanceName = _member_names(ClearanceEnum)
    GenderName = _member_names(GenderEnum)
    StatusName = _member_names(StatusEnum)

user_app = PyHiveTyper(help="Manage Hive users.")


@user_app.callback(invoke_without_command=True)
def user_callback(
    ctx: Context,
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    if ctx.invoked_subcommand is None:
        list_users(hive_url=hive_url, verify=verify)


@user_app.command(name="list")
def list_users(
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """
    Retrieve a list of users from the Hive server.

    Args:
        hive_url (str): The base URL of the Hive instance.
        verify (bool): Whether to verify SSL certificates.

    Returns:
        None
    """
    try:
        print_info(f"Fetching users from {hive_url}...")
        client = get_hive_client(hive_url=hive_url, verify=verify)

        users = sorted([x.to_dict() for x in client.get_users()], key=lambda x: x["id"])

        def text_output() -> None:
            secho(f"\nFound {len(users)} users:", fg=colors.GREEN)
            print_formatted_list(
                data=users,
                template="- [{id}]  ({number})  {username}",
                keys=["id", "number", "username"],
            )

        print_result({"users": users}, text_output)

    except Exception as e:
        print_error_and_exit(
            message=f"Failed to fetch users: {e}",
            error_data={"error": "User fetch failed", "details": str(e)},
        )


@user_app.command(name="create")
def create_user(
    clearance: Annotated[
        ClearanceName,
        Option(help="Clearance level for the user.", case_sensitive=False),
    ],
    gender: Annotated[
        GenderName, Option(help="Gender of the user.", case_sensitive=False)
    ],
    username: str = Argument(..., help="Username for the new account"),
    password: str = Option(
        ..., prompt=True, hide_input=True, help="Password for the account"
    ),
    status: Annotated[
        StatusName, Option(help="Initial user status.", case_sensitive=False)
    ] = StatusEnum.PRESENT.name,
    number: int | None = Option(None, help="Identification number"),
    first_name: str | None = Option(None, help="User's first name"),
    last_name: str | None = Option(None, help="User's last name"),
    avatar_filename: str | None = Option(None, help="Avatar filename"),
    teacher: bool | None = Option(None, help="Set teacher status"),
    confirmed: bool | None = Option(None, help="Set confirmed status"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """
    Create a new user on the Hive server using Enum names for selection.

    Args:
        username (str): The username for the new account.
        password (str): Password for the account.
        clearance (str): The name of the clearance level.
        gender (str): The name of the gender.
        status (str): The name of the status.
        number (int | None): Identification number.
        first_name (str | None): User's first name.
        last_name (str | None): User's last name.
        avatar_filename (str | None): Avatar filename.
        teacher (bool | None): Set teacher status.
        confirmed (bool | None): Set confirmed status.
        hive_url (str): The base URL of the Hive instance.
        verify (bool): Whether to verify SSL certificates.

    Returns:
        None
    """
    try:
        print_info(f"Creating user '{username}' at {hive_url}...")
        client = get_hive_client(hive_url=hive_url, verify=verify)

        user = client.create_user(
            username=username,
            password=password,
            clearance=ClearanceEnum[clearance.upper()],
            gender=GenderEnum[gender.upper()],
            status=StatusEnum[status.upper()],
            number=number,
            first_name=first_name,
            last_name=last_name,
            avatar_filename=avatar_filename,
            teacher=teacher,
            confirmed=confirmed,
        )

        user_data: dict[str, Any] = getattr(user, "model_dump", lambda: vars(user))()

        def text_output() -> None:
            secho("\nUser successfully created!", fg=colors.GREEN)
            echo(f"ID: {getattr(user, 'id', 'N/A')}")
            echo(f"Username: {user.username}")
            echo(f"Clearance: {user.clearance.name}")

        print_result({"user": user_data, "status": "created"}, text_output)

    except Exception as e:
        print_error_and_exit(
            message=f"Failed to create user: {e}",
            error_data={"error": "User creation failed", "details": str(e)},
        )


@user_app.command(name="delete")
def delete_user(
    user_id: int = Argument(..., help="ID of the user to delete"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """
    Delete an existing user from the Hive server.

    Args:
        user_id (str): The ID of the user to remove.
        hive_url (str): The base URL of the Hive instance.
        verify (bool): Whether to verify SSL certificates.

    Returns:
        None
    """
    try:
        print_info(f"Deleting user '{user_id}' from {hive_url}...")
        client = get_hive_client(hive_url=hive_url, verify=verify)

        success = True
        try:
            client.delete_user(user=user_id)
        except RuntimeError:
            success = False

        if not success:
            raise ValueError(f"User {user_id} could not be deleted or does not exist.")

        def text_output() -> None:
            secho(f"\nUser '{user_id}' successfully deleted.", fg=colors.GREEN)

        print_result({"deleted_user_id": user_id, "status": "success"}, text_output)

    except Exception as e:
        print_error_and_exit(
            message=f"Failed to delete user: {e}",
            error_data={"error": "User deletion failed", "details": str(e)},
        )


@user_app.command(name="set-queues")
def set_queues(  # pylint: disable=too-many-arguments
    user_id: int = Argument(..., help="ID of the user"),
    queue: str | None = Option(
        None, help="Class queue: a queue id, or 'none' to clear"
    ),
    user_queue: str | None = Option(
        None, help="The user's own queue: a queue id, or 'none' to clear"
    ),
    override_queue: str | None = Option(
        None, help="Override queue: a queue id, or 'none' to clear"
    ),
    disable_queue: bool | None = Option(
        None, "--disable-queue/--enable-queue", help="Disable or enable the class queue"
    ),
    disable_user_queue: bool | None = Option(
        None,
        "--disable-user-queue/--enable-user-queue",
        help="Disable or enable the user's own queue",
    ),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Assign, clear or disable a user's queues; options left out stay as they are."""
    refs: dict[str, int | None | Unset] = {
        name: UNSET
        if value is None
        else id_or_none(value, "--" + name.replace("_", "-"))
        for name, value in (
            ("queue", queue),
            ("user_queue", user_queue),
            ("override_queue", override_queue),
        )
    }
    if all(isinstance(v, Unset) for v in refs.values()) and (
        disable_queue is None and disable_user_queue is None
    ):
        print_error_and_exit(
            "Nothing to change: pass --queue, --user-queue, --override-queue"
            " or a --disable/--enable flag."
        )
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        user = client.set_user_queues(
            user_id,
            queue=refs["queue"],
            user_queue=refs["user_queue"],
            override_queue=refs["override_queue"],
            disable_queue=disable_queue,
            disable_user_queue=disable_user_queue,
        )
        data = {
            "id": user.id,
            "queue": user.queue_id,
            "disable_queue": user.disable_queue,
            "user_queue": user.user_queue_id,
            "disable_user_queue": user.disable_user_queue,
            "override_queue": user.override_queue_id,
        }

        def text_output() -> None:
            secho(f"\nUser {user_id}'s queues:", fg=colors.GREEN)
            for key, value in data.items():
                if key != "id":
                    echo(f"  {key}: {value}")

        print_result({"user": data}, text_output)
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Failed to set user {user_id}'s queues: {e}",
            error_data={"error": "User queue update failed", "details": str(e)},
        )
