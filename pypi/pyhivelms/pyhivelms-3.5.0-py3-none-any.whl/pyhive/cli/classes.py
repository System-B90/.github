"""Classes CLI subcommand group."""

from typing import Any

import typer

from pyhive.cli.base import PyHiveTyper
from pyhive.cli.client_factory import (
    HIVE_URL_OPTION,
    VERIFY_OPTION,
    get_hive_client,
)
from pyhive.cli.formatter import (
    print_error_and_exit,
    print_formatted_list,
    print_info,
    print_result,
)
from pyhive.cli.queues import id_or_none

class_app = PyHiveTyper(help="Manage Hive classes.")


@class_app.callback(invoke_without_command=True)
def class_callback(
    ctx: typer.Context,
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    if ctx.invoked_subcommand is None:
        list_classes(hive_url=hive_url, verify=verify)


@class_app.command(name="list")
def list_classes(
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """List all classes."""
    try:
        print_info(f"Fetching classes from {hive_url}...")
        client = get_hive_client(hive_url=hive_url, verify=verify)
        classes = sorted(
            [x.to_dict() for x in client.get_classes()], key=lambda x: x["id"]
        )

        def text_output() -> None:
            typer.secho(f"\nFound {len(classes)} classes:", fg=typer.colors.GREEN)
            print_formatted_list(
                data=classes,
                template="- [{id}]  {name}  (program: {program})",
                keys=["id", "name", "program"],
            )

        print_result({"classes": classes}, text_output)

    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Failed to fetch classes: {e}",
            error_data={"error": "Class fetch failed", "details": str(e)},
        )


@class_app.command(name="get")
def get_class(
    class_id: int = typer.Argument(..., help="ID of the class"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Get a class by ID."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        hive_class = client.get_class(class_id)
        data: dict[str, Any] = hive_class.to_dict()

        def text_output() -> None:
            for key, value in data.items():
                typer.echo(f"{key}: {value}")

        print_result({"class": data}, text_output)

    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Failed to get class {class_id}: {e}",
            error_data={"error": "Class get failed", "details": str(e)},
        )


@class_app.command(name="delete")
def delete_class(
    class_id: int = typer.Argument(..., help="ID of the class to delete"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Delete a class by ID."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        client.delete_class(class_id)

        def text_output() -> None:
            typer.secho(f"\nClass '{class_id}' deleted.", fg=typer.colors.GREEN)

        print_result({"deleted_class_id": class_id, "status": "success"}, text_output)

    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Failed to delete class {class_id}: {e}",
            error_data={"error": "Class deletion failed", "details": str(e)},
        )


@class_app.command(name="set-queue")
def set_queue(
    class_id: int = typer.Argument(..., help="ID of the class"),
    queue: str = typer.Argument(..., help="Queue id, or 'none' to clear"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Set the class queue of every student in a class."""
    queue_id = id_or_none(queue, "QUEUE")
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        client.set_class_queue(class_id, queue_id)

        def text_output() -> None:
            done = "cleared" if queue_id is None else f"set to {queue_id}"
            typer.secho(
                f"\nClass {class_id}: every student's queue {done}.",
                fg=typer.colors.GREEN,
            )

        print_result(
            {"class_id": class_id, "queue": queue_id, "status": "success"}, text_output
        )
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Failed to set class {class_id}'s queue: {e}",
            error_data={"error": "Class queue assignment failed", "details": str(e)},
        )


@class_app.command(name="set-lesson")
def set_lesson(
    class_id: int = typer.Argument(..., help="ID of the class"),
    lesson: str = typer.Argument(
        ..., help="Lesson id (a UUID on Hive 7.3+, an integer before), or 'none'"
    ),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Apply a lesson's queue rules to every student in a class."""
    lesson_id = None if lesson.strip().lower() == "none" else lesson.strip()
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        client.set_class_lesson(class_id, lesson_id)

        def text_output() -> None:
            done = "unset" if lesson_id is None else f"set to {lesson_id}"
            typer.secho(f"\nClass {class_id}: lesson {done}.", fg=typer.colors.GREEN)

        print_result(
            {"class_id": class_id, "lesson": lesson_id, "status": "success"},
            text_output,
        )
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Failed to set class {class_id}'s lesson: {e}",
            error_data={"error": "Class lesson assignment failed", "details": str(e)},
        )


@class_app.command(name="clear-override-queues")
def clear_override_queues(
    class_id: int = typer.Argument(..., help="ID of the class"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Clear the override queue of every student in a class (Hive 6.1.1+)."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        client.unassign_class_override_queues(class_id)

        def text_output() -> None:
            typer.secho(
                f"\nClass {class_id}: override queues cleared.", fg=typer.colors.GREEN
            )

        print_result({"class_id": class_id, "status": "success"}, text_output)
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Failed to clear class {class_id}'s override queues: {e}",
            error_data={"error": "Override queue clearing failed", "details": str(e)},
        )
