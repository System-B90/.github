"""Auth CLI subcommand group: sign in once and reuse the cached Hive URL and token."""

import os
from datetime import datetime
from typing import Any

import typer

from pyhive.cli.base import PyHiveTyper
from pyhive.cli.client_factory import (
    VERIFY_OPTION,
    clear_credentials,
    default_hive_url,
    get_cached_hive_url,
    get_cached_tokens,
    save_credentials,
)
from pyhive.cli.formatter import print_error_and_exit, print_info, print_result
from pyhive.cli.state import state
from pyhive.client import HiveClient
from pyhive.client.sso_utils import get_sso_token
from pyhive.src.access_tokens import looks_like_personal_access_token

auth_app = PyHiveTyper(
    help="Sign in once; later commands reuse the Hive URL and token."
)


@auth_app.command(name="login")
def login(
    hive_url: str | None = typer.Option(
        None, help="Hive server URL. Asked for when omitted, unless --json is set."
    ),
    verify: bool = VERIFY_OPTION,
) -> None:
    """Sign in with SSO (or check a personal access token given with --token) and cache it in the OS keyring."""
    hive_url = hive_url or state.hive_url
    if hive_url is None:
        hive_url = (
            default_hive_url()
            if state.use_json
            else typer.prompt("Hive URL", default=default_hive_url())
        )
    hive_url = hive_url.rstrip("/")

    if state.access_token:
        _login_with_access_token(hive_url, verify, state.access_token)
        return

    try:
        print_info(f"Opening your browser to sign in to {hive_url}...")
        access_token: str
        refresh_token: str
        expires_at: datetime
        access_token, refresh_token, expires_at = get_sso_token(
            hive_url=hive_url, verify=verify
        )
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Sign-in failed: {e}",
            error_data={"error": "Sign-in failed", "details": str(e)},
        )

    try:
        save_credentials(hive_url, access_token, refresh_token)
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Signed in, but could not save to the OS keyring: {e}",
            error_data={"error": "Keyring write failed", "details": str(e)},
        )

    def text_output() -> None:
        typer.secho(f"Signed in to {hive_url}.", fg=typer.colors.GREEN)
        typer.echo("Later commands use this server and token without signing in again.")

    print_result({"hive_url": hive_url, "expires_at": expires_at}, text_output)


def _login_with_access_token(hive_url: str, verify: bool, token: str) -> None:
    token = token.strip()
    if not looks_like_personal_access_token(token):
        print_error_and_exit(
            message="auth login --token only accepts personal access tokens (hive_pat_...).",
            error_data={"error": "Not a personal access token"},
        )

    try:
        client = HiveClient.from_access_token(token, hive_url, verify=verify)
        me = client.get("/api/core/management/users/me/")
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Sign-in failed: {e}",
            error_data={"error": "Sign-in failed", "details": str(e)},
        )

    try:
        save_credentials(hive_url, token, None)
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Token works, but could not save it to the OS keyring: {e}",
            error_data={"error": "Keyring write failed", "details": str(e)},
        )

    username = me.get("username") if isinstance(me, dict) else None

    def text_output() -> None:
        typer.secho(
            f"Signed in to {hive_url} as {username} with a personal access token.",
            fg=typer.colors.GREEN,
        )
        typer.echo("Later commands use this server and token until it expires or is revoked.")

    print_result(
        {"hive_url": hive_url, "username": username, "token_type": "personal_access_token"},
        text_output,
    )


def _token_type(access_token: str | None, refresh_token: str | None) -> str | None:
    if access_token and looks_like_personal_access_token(access_token):
        return "personal_access_token"
    if access_token and refresh_token:
        return "sso"
    return None


@auth_app.command(name="status")
def status() -> None:
    """Show the cached Hive URL and whether a token is cached; makes no network calls."""
    access_token, refresh_token = get_cached_tokens()
    token_type = _token_type(access_token, refresh_token)
    payload: dict[str, Any] = {
        "hive_url": get_cached_hive_url(),
        "token_cached": token_type is not None,
        "token_type": token_type,
        "env_token_set": bool(os.environ.get("HIVE_ACCESS_TOKEN")),
    }

    def text_output() -> None:
        typer.echo(f"Hive URL:     {payload['hive_url'] or '(none cached)'}")
        cached = {"personal_access_token": "yes (personal access token)", "sso": "yes (SSO)"}
        typer.echo(f"Cached token: {cached.get(token_type or '', 'no')}")
        if payload["env_token_set"]:
            typer.echo("HIVE_ACCESS_TOKEN is set and takes priority over the cache.")

    print_result(payload, text_output)


@auth_app.command(name="logout")
def logout() -> None:
    """Remove the cached Hive URL and tokens from the OS keyring."""
    try:
        clear_credentials()
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Could not clear the OS keyring: {e}",
            error_data={"error": "Keyring delete failed", "details": str(e)},
        )
    print_result(
        {"logged_out": True},
        lambda: typer.echo("Removed the cached Hive URL and token."),
    )
