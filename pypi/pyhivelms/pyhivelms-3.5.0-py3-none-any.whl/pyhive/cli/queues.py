"""Queues CLI subcommand group: queues, the items in them, and editing both."""

from typing import Any

import typer

from pyhive.cli.base import PyHiveTyper
from pyhive.cli.client_factory import (
    HIVE_URL_OPTION,
    VERIFY_OPTION,
    get_hive_client,
)
from pyhive.cli.formatter import (
    print_error_and_exit,
    print_formatted_list,
    print_info,
    print_result,
)
from pyhive.types import QueueItem, QueueRuleEnum

queue_app = PyHiveTyper(help="Manage queues and the items in them.")

RULES = [rule.value for rule in QueueRuleEnum]
RULE_HELP = f"Queue rule: {', '.join(repr(r) for r in RULES)}"


def id_or_none(value: str, option: str) -> int | None:
    """``none`` (any case) -> None, else the integer id."""
    if value.strip().lower() == "none":
        return None
    try:
        return int(value)
    except ValueError:
        raise typer.BadParameter(
            f"{value!r} is neither an id nor 'none'", param_hint=option
        ) from None


def _fail(what: str, error: Exception) -> None:
    print_error_and_exit(
        message=f"Failed to {what}: {error}",
        error_data={"error": f"Failed to {what}", "details": str(error)},
    )


def _rule(value: str | None) -> QueueRuleEnum | None:
    if value is None:
        return None
    for rule in QueueRuleEnum:
        if value.lower() in (rule.value.lower(), rule.name.lower()):
            return rule
    raise typer.BadParameter(f"{value!r} is not one of {RULES}", param_hint="--rule")


def _item_row(item: QueueItem) -> dict[str, Any]:
    target = (
        f"exercise {item.exercise.id} ({item.exercise.name})"
        if item.exercise is not None
        else f"queue {item.nested_queue.id} ({item.nested_queue.name})"
        if item.nested_queue is not None
        else "-"
    )
    return {
        "id": item.id,
        "order": item.order,
        "target": target,
        "queue_rule": item.queue_rule.value,
        "enabled": item.enabled,
        "continue_on_redo": item.continue_on_redo,
    }


def _print_item(action: str, queue_id: int, item: QueueItem) -> None:
    row = _item_row(item)

    def text_output() -> None:
        typer.secho(
            f"{action} item {row['id']} at position {row['order']} of queue {queue_id}:"
            f" {row['target']}, rule {row['queue_rule']}, enabled {row['enabled']}.",
            fg=typer.colors.GREEN,
        )

    print_result({"queue_id": queue_id, "item": item.to_dict()}, text_output)


def _print_queue(action: str, data: dict[str, Any]) -> None:
    def text_output() -> None:
        owner = (
            f"user {data.get('user_id')}"
            if data.get("user_id") is not None
            else f"module {data.get('module_id')}"
        )
        typer.secho(
            f"{action} queue [{data['id']}] {data['name']} ({owner}).",
            fg=typer.colors.GREEN,
        )

    print_result({"queue": data}, text_output)


@queue_app.callback(invoke_without_command=True)
def queue_callback(
    ctx: typer.Context,
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    if ctx.invoked_subcommand is None:
        list_queues(hive_url=hive_url, verify=verify)


@queue_app.command(name="list")
def list_queues(  # pylint: disable=too-many-arguments
    user: int | None = typer.Option(None, help="Only this user's own queues"),
    module: int | None = typer.Option(None, help="Only this module's queues"),
    class_id: int | None = typer.Option(
        None, "--class", help="Only queues of this class's students"
    ),
    user_queues: bool | None = typer.Option(
        None,
        "--user-queues/--module-queues",
        help="Only users' own queues, or only module queues",
    ),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """List queues."""
    try:
        print_info(f"Fetching queues from {hive_url}...")
        client = get_hive_client(hive_url=hive_url, verify=verify)
        queues = sorted(
            (
                q.to_dict()
                for q in client.get_queues(
                    user=user, module=module, class_=class_id, user_queues=user_queues
                )
            ),
            key=lambda q: q["id"],
        )
        for q in queues:
            q["owner"] = (
                f"user {q.get('user_id')}"
                if q.get("user_id") is not None
                else f"module {q.get('module_id')}"
            )

        def text_output() -> None:
            typer.secho(f"\nFound {len(queues)} queues:", fg=typer.colors.GREEN)
            print_formatted_list(
                data=queues,
                template="- [{id}]  {name}  ({owner})",
                keys=["id", "name", "owner"],
            )

        print_result({"queues": queues}, text_output)
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail("list queues", e)


@queue_app.command(name="get")
def get_queue(
    queue_id: int = typer.Argument(..., help="ID of the queue"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Get a queue by ID."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        data = client.get_queue(queue_id).to_dict()

        def text_output() -> None:
            for key, value in data.items():
                typer.echo(f"{key}: {value}")

        print_result({"queue": data}, text_output)
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"get queue {queue_id}", e)


@queue_app.command(name="create")
def create_queue(
    name: str = typer.Argument(..., help="Name of the new queue"),
    module: int | None = typer.Option(None, help="Module that owns the queue"),
    user: int | None = typer.Option(None, help="User whose own queue this is"),
    description: str = typer.Option("", help="Description"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Create a queue owned by exactly one of --module or --user."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        queue = client.create_queue(name, description, module=module, user=user)
        _print_queue("Created", queue.to_dict())
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail("create queue", e)


@queue_app.command(name="update")
def update_queue(
    queue_id: int = typer.Argument(..., help="ID of the queue"),
    name: str | None = typer.Option(None, help="New name"),
    description: str | None = typer.Option(None, help="New description"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Rename or re-describe a queue."""
    if name is None and description is None:
        print_error_and_exit("Nothing to update: pass --name and/or --description.")
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        queue = client.update_queue(queue_id, name=name, description=description)
        _print_queue("Updated", queue.to_dict())
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"update queue {queue_id}", e)


@queue_app.command(name="duplicate")
def duplicate_queue(
    queue_id: int = typer.Argument(..., help="ID of the queue to copy"),
    name: str = typer.Argument(..., help="Name of the copy"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Copy a queue and its items; the copy has the same owner."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        queue = client.duplicate_queue(queue_id, name)
        _print_queue(f"Copied queue {queue_id} to", queue.to_dict())
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"duplicate queue {queue_id}", e)


@queue_app.command(name="delete")
def delete_queue(
    queue_id: int = typer.Argument(..., help="ID of the queue to delete"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Delete a queue by ID."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        client.delete_queue(queue_id)

        def text_output() -> None:
            typer.secho(f"\nQueue '{queue_id}' deleted.", fg=typer.colors.GREEN)

        print_result({"deleted_queue_id": queue_id, "status": "success"}, text_output)
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"delete queue {queue_id}", e)


@queue_app.command(name="items")
def list_items(
    queue_id: int = typer.Argument(..., help="ID of the queue"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """List a queue's items in order."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        items = list(client.get_queue_items(queue_id))
        rows = [_item_row(i) for i in items]

        def text_output() -> None:
            typer.secho(
                f"\nQueue {queue_id} has {len(rows)} items:", fg=typer.colors.GREEN
            )
            print_formatted_list(
                data=rows,
                template="{order}. [{id}]  {target}  rule={queue_rule}  enabled={enabled}",
                keys=["order", "id", "target", "queue_rule", "enabled"],
            )

        print_result(
            {"queue_id": queue_id, "items": [i.to_dict() for i in items]}, text_output
        )
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"list the items of queue {queue_id}", e)


@queue_app.command(name="add-item")
def add_item(  # pylint: disable=too-many-arguments
    queue_id: int = typer.Argument(..., help="ID of the queue"),
    exercise: int | None = typer.Option(None, help="Exercise to add"),
    nested_queue: int | None = typer.Option(None, help="Queue to nest"),
    module: int | None = typer.Option(None, help="Module whose exercises to add"),
    order: int | None = typer.Option(
        None, help="0-based position (later items shift down); default: last"
    ),
    rule: str = typer.Option(QueueRuleEnum.CHOOSE.value, help=RULE_HELP),
    enabled: bool = typer.Option(True, "--enabled/--disabled", help="Item enabled"),
    continue_on_redo: bool = typer.Option(False, help="Continue on redo"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Add an exercise, a nested queue or a module's exercises to a queue."""
    if sum(x is not None for x in (exercise, nested_queue, module)) != 1:
        print_error_and_exit(
            "Pass exactly one of --exercise, --nested-queue or --module."
        )
    queue_rule = _rule(rule)
    assert queue_rule is not None
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        item = client.add_queue_item(
            queue_id,
            exercise=exercise,
            nested_queue=nested_queue,
            module=module,
            order=order,
            queue_rule=queue_rule,
            enabled=enabled,
            continue_on_redo=continue_on_redo,
        )
        _print_item("Added", queue_id, item)
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"add an item to queue {queue_id}", e)


@queue_app.command(name="update-item")
def update_item(  # pylint: disable=too-many-arguments
    queue_id: int = typer.Argument(..., help="ID of the queue"),
    item_id: int = typer.Argument(..., help="ID of the item"),
    rule: str | None = typer.Option(None, help=RULE_HELP),
    enabled: bool | None = typer.Option(
        None, "--enabled/--disabled", help="Enable or disable the item"
    ),
    continue_on_redo: bool | None = typer.Option(
        None, "--continue-on-redo/--no-continue-on-redo", help="Continue on redo"
    ),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Change an item's rule or flags (reorder with move-item)."""
    if rule is None and enabled is None and continue_on_redo is None:
        print_error_and_exit(
            "Nothing to update: pass --rule, --enabled/--disabled or --[no-]continue-on-redo."
        )
    queue_rule = _rule(rule)
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        item = client.update_queue_item(
            queue_id,
            item_id,
            queue_rule=queue_rule,
            enabled=enabled,
            continue_on_redo=continue_on_redo,
        )
        _print_item("Updated", queue_id, item)
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"update item {item_id} of queue {queue_id}", e)


@queue_app.command(name="move-item")
def move_item(
    queue_id: int = typer.Argument(..., help="ID of the queue"),
    item_id: int = typer.Argument(..., help="ID of the item"),
    new_order: int = typer.Argument(..., help="New 0-based position"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Move an item to another position; the rest are renumbered."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        item = client.move_queue_item(queue_id, item_id, new_order)
        _print_item("Moved", queue_id, item)
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"move item {item_id} of queue {queue_id}", e)


@queue_app.command(name="expand-item")
def expand_item(
    queue_id: int = typer.Argument(..., help="ID of the queue"),
    item_id: int = typer.Argument(..., help="ID of a nested-queue item"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Replace a nested-queue item with that queue's own items."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        client.expand_queue_item(queue_id, item_id)

        def text_output() -> None:
            typer.secho(
                f"\nExpanded item {item_id} of queue {queue_id}.", fg=typer.colors.GREEN
            )

        print_result(
            {"queue_id": queue_id, "expanded_item_id": item_id, "status": "success"},
            text_output,
        )
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"expand item {item_id} of queue {queue_id}", e)


@queue_app.command(name="remove-item")
def remove_item(
    queue_id: int = typer.Argument(..., help="ID of the queue"),
    item_id: int = typer.Argument(..., help="ID of the item to remove"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Remove an item from a queue."""
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        client.delete_queue_item(queue_id, item_id)

        def text_output() -> None:
            typer.secho(
                f"\nRemoved item {item_id} from queue {queue_id}.",
                fg=typer.colors.GREEN,
            )

        print_result(
            {"queue_id": queue_id, "removed_item_id": item_id, "status": "success"},
            text_output,
        )
    except Exception as e:  # pylint: disable=broad-exception-caught
        _fail(f"remove item {item_id} from queue {queue_id}", e)
