"""
Name: client_factory.py
Purpose: Centralized instantiation of the HiveClient based on CLI state, environment, and OS Keyring.
Created: 2026-04-07
Author: Michael K. Steinberg
"""

import os

import keyring
import typer
from keyring.errors import PasswordDeleteError

from pyhive.cli.state import state
from pyhive.client import HiveClient
from pyhive.src.access_tokens import looks_like_personal_access_token

DEFAULT_HIVE_URL = "https://hive.org"
KEYRING_SERVICE = "pyhive_cli"
KEYRING_ACCOUNT = "pyhive_access_token"
KEYRING_REFRESH_ACCOUNT = "pyhive_refresh_token"
KEYRING_URL_ACCOUNT = "pyhive_hive_url"


def _normalize_url(hive_url: str) -> str:
    return hive_url.rstrip("/")


def get_cached_tokens() -> tuple[str | None, str | None]:
    """Safely fetch the cached access and refresh tokens from the OS keyring."""
    try:
        access_token = keyring.get_password(KEYRING_SERVICE, KEYRING_ACCOUNT)
        refresh_token = keyring.get_password(KEYRING_SERVICE, KEYRING_REFRESH_ACCOUNT)
    except Exception:  # pylint: disable=broad-exception-caught
        return None, None
    return access_token, refresh_token


def get_cached_hive_url() -> str | None:
    """Return the Hive URL saved by the last cached sign-in, if any."""
    try:
        return keyring.get_password(KEYRING_SERVICE, KEYRING_URL_ACCOUNT)
    except Exception:  # pylint: disable=broad-exception-caught
        return None


def default_hive_url() -> str:
    """Return --hive-url from the root command, else the cached URL, else the public default."""
    return state.hive_url or get_cached_hive_url() or DEFAULT_HIVE_URL


def default_verify() -> bool:
    """Return --verify/--no-verify from the root command, else False."""
    return bool(state.verify)


# The root command hoists --hive-url and --verify from anywhere on the line
# (see GlobalOptionsGroup), so these per-command options only take effect
# when a sub-app runs on its own; otherwise their defaults read the root's.
HIVE_URL_OPTION = typer.Option(
    default_factory=default_hive_url,
    show_default=f"the cached URL, else {DEFAULT_HIVE_URL}",
    help="Target Hive server URL",
)
VERIFY_OPTION = typer.Option(
    default_factory=default_verify,
    show_default="--no-verify",
    help="Verify SSL certificates",
)


def save_credentials(
    hive_url: str, access_token: str, refresh_token: str | None
) -> None:
    """Write the Hive URL and tokens to the OS keyring; raises if the keyring fails."""
    keyring.set_password(KEYRING_SERVICE, KEYRING_URL_ACCOUNT, _normalize_url(hive_url))
    keyring.set_password(KEYRING_SERVICE, KEYRING_ACCOUNT, access_token)
    if refresh_token:
        keyring.set_password(KEYRING_SERVICE, KEYRING_REFRESH_ACCOUNT, refresh_token)
    else:
        _delete_entry(KEYRING_REFRESH_ACCOUNT)


def cache_credentials(
    hive_url: str, access_token: str, refresh_token: str | None
) -> None:
    """Like save_credentials, but a keyring failure only prints a warning."""
    try:
        save_credentials(hive_url, access_token, refresh_token)
    except Exception as exc:  # pylint: disable=broad-exception-caught
        # A locked keychain must not crash the command: the client is already
        # authenticated either way. stderr, so --json stdout stays parseable.
        typer.secho(
            f"Warning: could not cache token in the OS keyring ({exc}).",
            fg=typer.colors.YELLOW,
            err=True,
        )


def _delete_entry(account: str) -> None:
    try:
        keyring.delete_password(KEYRING_SERVICE, account)
    except PasswordDeleteError:
        pass


def clear_credentials() -> None:
    """Remove the cached Hive URL and tokens; raises if the keyring fails."""
    for account in (KEYRING_URL_ACCOUNT, KEYRING_ACCOUNT, KEYRING_REFRESH_ACCOUNT):
        _delete_entry(account)


def _client_from_token(token: str, hive_url: str, verify: bool) -> HiveClient:
    """A personal access token (hive_pat_...) or a bare API token (JWT), from --token or HIVE_ACCESS_TOKEN."""
    if looks_like_personal_access_token(token):
        return HiveClient.from_access_token(
            hive_url=hive_url,
            verify=verify,
            access_token=token,
        )
    return HiveClient.from_api_token(
        hive_url=hive_url,
        verify=verify,
        api_token=token,
    )


def get_hive_client(hive_url: str, verify: bool) -> HiveClient:
    """
    Instantiate HiveClient using credentials from the global state, environment, or OS keyring.
    Prioritizes Username/Password, then explicit CLI Token, then Environment Variable,
    then OS Keyring, and finally falls back to SSO. Tokens starting with hive_pat_ are
    personal access tokens, which are never refreshed and need no refresh token.

    Args:
        hive_url (str): The base URL of the Hive instance.
        verify (bool): Whether to verify SSL certificates.

    Returns:
        HiveClient: An authenticated instance of the Hive client.
    """
    env_token: str | None = os.environ.get("HIVE_ACCESS_TOKEN")
    keyring_access_token, keyring_refresh_token = get_cached_tokens()
    cached_url = get_cached_hive_url()
    # Cached tokens belong to the server they were issued by. Caches written
    # before the URL was stored have no URL, so they keep working as before.
    cache_matches_url = cached_url is None or _normalize_url(
        cached_url
    ) == _normalize_url(hive_url)

    if state.username and state.password:
        client = HiveClient(
            hive_url=hive_url,
            verify=verify,
            username=state.username,
            password=state.password,
        )
    elif state.access_token:
        client = _client_from_token(state.access_token, hive_url, verify)
    elif env_token:
        client = _client_from_token(env_token, hive_url, verify)
    elif (
        keyring_access_token
        and looks_like_personal_access_token(keyring_access_token)
        and cache_matches_url
    ):
        client = HiveClient.from_access_token(
            hive_url=hive_url,
            verify=verify,
            access_token=keyring_access_token,
        )
    elif keyring_access_token and keyring_refresh_token and cache_matches_url:
        client = HiveClient.from_api_token(
            hive_url=hive_url,
            verify=verify,
            api_token=keyring_access_token,
            refresh_token=keyring_refresh_token,
            auth_strategy="cache",
        )
    else:
        client = HiveClient.from_sso(
            hive_url=hive_url,
            verify=verify,
        )

    if state.cache_token:
        access_token: str | None = client._access_token  # pylint: disable=protected-access
        refresh_token: str | None = client._refresh_token  # pylint: disable=protected-access
        if access_token:
            cache_credentials(hive_url, access_token, refresh_token)

    return client
