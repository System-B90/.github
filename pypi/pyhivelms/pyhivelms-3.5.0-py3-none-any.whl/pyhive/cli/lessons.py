"""Lessons CLI subcommand group: find the lesson ids `classes set-lesson` takes."""

import typer

from pyhive.cli.base import PyHiveTyper
from pyhive.cli.client_factory import (
    HIVE_URL_OPTION,
    VERIFY_OPTION,
    get_hive_client,
)
from pyhive.cli.formatter import (
    print_error_and_exit,
    print_formatted_list,
    print_info,
    print_result,
)

lesson_app = PyHiveTyper(help="List Hive lessons (scheduled lesson plans).")


@lesson_app.callback(invoke_without_command=True)
def lesson_callback(
    ctx: typer.Context,
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    if ctx.invoked_subcommand is None:
        list_lessons(module=None, hive_url=hive_url, verify=verify)


@lesson_app.command(name="list")
def list_lessons(
    module: int | None = typer.Option(None, help="Only this module's lessons"),
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """List lessons."""
    try:
        print_info(f"Fetching lessons from {hive_url}...")
        client = get_hive_client(hive_url=hive_url, verify=verify)
        lessons = [lesson.to_dict() for lesson in client.get_lessons(module__id=module)]

        def text_output() -> None:
            typer.secho(f"\nFound {len(lessons)} lessons:", fg=typer.colors.GREEN)
            print_formatted_list(
                data=lessons,
                template="- [{id}]  {name}  (module: {module_name})",
                keys=["id", "name", "module_name"],
            )

        print_result({"lessons": lessons}, text_output)
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Failed to fetch lessons: {e}",
            error_data={"error": "Lesson fetch failed", "details": str(e)},
        )
