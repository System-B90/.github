"""List open help requests: who asked, about which exercise, and when it was last answered.

Run:  pyhive examples run open_help_requests
"""

from pyhive import HiveClient
from pyhive.types import HelpStatusEnum


def main(client: HiveClient, *_args: str) -> None:
    requests = list(
        client.get_help_requests(
            help_status__in=[HelpStatusEnum.OPEN.value], ordering="-id"
        )
    )
    print(f"{len(requests)} open help requests")
    for request in requests:
        exercise = request.for_exercise
        about = f" — {exercise.name}" if exercise else ""
        print(f"#{request.id} [{request.help_type.value}] {request.title}{about}")
        print(f"    asked by {request.user.display_name}")
        responses = list(client.get_help_responses(request))
        if responses:
            print(
                f"    {len(responses)} replies, last on {responses[-1].date:%Y-%m-%d}"
            )


if __name__ == "__main__":
    with HiveClient.from_sso("https://hive.org", verify=False) as hive:
        main(hive)
