"""Print the schedule for the next seven days, grouped by day.

Run:  pyhive examples run weekly_schedule
"""

from collections import defaultdict
from datetime import date, datetime, timedelta, timezone

from pyhive import HiveClient
from pyhive.types import ScheduleEvent


def main(client: HiveClient, *_args: str) -> None:
    start = datetime.now(timezone.utc).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    end = start + timedelta(days=7)

    days: dict[date, list[ScheduleEvent]] = defaultdict(list)
    for event in client.get_schedule_events(start__gte=start, end__lte=end):
        days[event.start.date()].append(event)

    if not days:
        print(f"No events between {start:%Y-%m-%d} and {end:%Y-%m-%d}.")
    for day in sorted(days):
        print(f"{day:%A %Y-%m-%d}")
        for event in sorted(days[day], key=lambda e: e.start):
            category = f" [{event.category_name}]" if event.category_name else ""
            print(f"  {event.start:%H:%M}-{event.end:%H:%M}  {event.title}{category}")


if __name__ == "__main__":
    with HiveClient.from_sso("https://hive.org", verify=False) as hive:
        main(hive)
