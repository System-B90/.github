"""Find a student by name or number and show their mentor, classes and progress.

Run:  pyhive examples run find_student "First Last"
      pyhive examples run find_student 1234
"""

from collections import Counter

from pyhive import HiveClient


def main(client: HiveClient, *args: str) -> None:
    if not args:
        print("Pass a student name or number. Students:")
        for each in client.get_students():
            print(f"  {each.number}  {each.display_name}")
        return

    query = args[0]
    student = (
        client.get_student(number=int(query))
        if query.isdigit()
        else client.get_student(name=query)
    )
    if student is None:
        print(f"No single student matches {query!r}.")
        return

    print(f"{student.display_name} (#{student.id}, number {student.number})")
    print(f"  status:  {student.status.value if student.status else '-'}")
    print(f"  program: {student.program.name if student.program else '-'}")
    print(f"  mentor:  {student.mentor.display_name if student.mentor else '-'}")
    print(f"  classes: {', '.join(c.name for c in student.classes) or '-'}")

    by_status = Counter(a.assignment_status.value for a in student.get_assignments())
    print("  assignments:")
    for status, count in by_status.most_common():
        print(f"    {status:<18} {count}")


if __name__ == "__main__":
    import sys

    with HiveClient.from_sso("https://hive.org", verify=False) as hive:
        main(hive, *sys.argv[1:])
