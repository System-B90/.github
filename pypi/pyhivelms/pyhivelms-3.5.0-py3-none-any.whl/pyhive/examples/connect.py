"""Every way to sign in to Hive, then print the server version and what you can see.

Run:  pyhive examples run connect
"""

import os

from pyhive import HiveClient

HIVE_URL = "https://hive.org"


def connect_with_sso() -> HiveClient:
    # Opens a browser for Hive's SSO page; the token refreshes itself afterwards.
    return HiveClient.from_sso(HIVE_URL, verify=False)


def connect_with_password(username: str, password: str) -> HiveClient:
    return HiveClient(username, password, HIVE_URL, verify=False)


def connect_with_token() -> HiveClient:
    # A bare token cannot be refreshed: once it expires, build a new client.
    # Get one with `pyhive token`.
    return HiveClient.from_api_token(os.environ["HIVE_ACCESS_TOKEN"], HIVE_URL)


def main(client: HiveClient, *_args: str) -> None:
    print(f"Hive version: {client.get_hive_version()}")
    print(f"Server time:  {client.get_server_time()}")
    print(f"Programs:     {[program.name for program in client.get_programs()]}")


if __name__ == "__main__":
    with connect_with_sso() as hive:
        main(hive)
