"""Hive personal access tokens (``hive_pat_...``): recognising and validating them offline."""

import binascii
import string

import httpx

PAT_PREFIX = "hive_pat_"
_ALPHABET = string.digits + string.ascii_letters
_SECRET_LENGTH = 40
_CHECKSUM_LENGTH = 6
PAT_LENGTH = len(PAT_PREFIX) + _SECRET_LENGTH + _CHECKSUM_LENGTH


def _base62(number: int, length: int) -> str:
    digits = []
    for _ in range(length):
        number, digit = divmod(number, len(_ALPHABET))
        digits.append(_ALPHABET[digit])
    return "".join(reversed(digits))


def looks_like_personal_access_token(token: str) -> bool:
    """Whether ``token`` is meant to be a Hive PAT (has the prefix), well formed or not."""
    return token.startswith(PAT_PREFIX)


def is_valid_personal_access_token(token: str) -> bool:
    """Whether ``token`` is a well formed Hive PAT, checksum included. Catches typos and truncation offline."""
    if len(token) != PAT_LENGTH or not looks_like_personal_access_token(token):
        return False
    body = token[len(PAT_PREFIX) :]
    if any(char not in _ALPHABET for char in body):
        return False
    secret, checksum = body[:_SECRET_LENGTH], body[_SECRET_LENGTH:]
    # Must match Hive's core.access_tokens.models._checksum
    return _base62(binascii.crc32(secret.encode()), _CHECKSUM_LENGTH) == checksum


class AccessTokenRejectedError(RuntimeError):
    """Hive answered 401 to a personal access token: it is invalid, expired or revoked."""


class AccessTokenExpiredError(AccessTokenRejectedError):
    """The personal access token is past its expiry date; regenerate it in Hive."""


class AccessTokenReadOnlyError(httpx.HTTPStatusError):
    """A read-only personal access token was used for a write (POST, PUT, PATCH or DELETE)."""
