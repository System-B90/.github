"""
Name: queue_item.py
Purpose: A single item in a learning queue, either referencing an exercise or another queue.
Created: 2026-04-05
Author: Michael K. Steinberg
"""

from typing import TYPE_CHECKING, Annotated, Any, TypeVar

from pydantic import Field
from typing_extensions import Self

from .core_item import HiveCoreItem
from .enums.queue_rule_enum import QueueRuleEnum
from .exercise import Exercise
from .queue import Queue

if TYPE_CHECKING:
    from ...client import HiveClient


class QueueItem(HiveCoreItem):
    """A single item in a learning queue, either referencing an exercise or another queue."""

    hive_client: Annotated["HiveClient", Field(exclude=True, repr=False)]
    queue_id: Annotated[int | None, Field(exclude=True, repr=False)] = None
    id: int
    order: int
    exercise: Exercise | None
    nested_queue: Queue | None
    queue_rule: QueueRuleEnum
    enabled: bool
    continue_on_redo: bool | None = Field(default=None)

    @classmethod
    def from_dict(
        cls,
        src_dict: dict[str, Any],
        hive_client: "HiveClient",
        queue_id: int | None = None,
    ) -> Self:
        data = dict(src_dict)
        data["hive_client"] = hive_client
        data["queue_id"] = queue_id
        # The nested objects are full models that need the client too.
        for key in ("exercise", "nested_queue"):
            if isinstance(data.get(key), dict):
                data[key] = dict(data[key], hive_client=hive_client)
        return cls.model_validate(data)

    def _queue(self) -> int:
        if self.queue_id is None:
            raise ValueError(
                "This queue item does not know its queue; pass it explicitly."
            )
        return self.queue_id

    def update(
        self,
        *,
        queue_rule: QueueRuleEnum | str | None = None,
        enabled: bool | None = None,
        continue_on_redo: bool | None = None,
    ) -> "QueueItem":
        """Change this item's rule or flags; ``None`` leaves a setting as it is."""
        return self.hive_client.update_queue_item(
            self._queue(),
            self,
            queue_rule=queue_rule,
            enabled=enabled,
            continue_on_redo=continue_on_redo,
        )

    def move(self, new_order: int) -> "QueueItem":
        """Move this item to 0-based position ``new_order`` in its queue."""
        return self.hive_client.move_queue_item(self._queue(), self, new_order)

    def expand(self) -> None:
        """Replace this nested-queue item with the nested queue's own items."""
        self.hive_client.expand_queue_item(self._queue(), self)

    def delete(self) -> None:
        self.hive_client.delete_queue_item(self._queue(), self)


T = TypeVar("T", bound="QueueItem")
QueueItemLike = TypeVar("QueueItemLike", QueueItem, int)
