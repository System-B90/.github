"""Outgoing webhook mixin for HiveClient (``/api/core/webhooks/endpoints/``, admins only)."""

from collections.abc import Iterable, Sequence

from ..src.types._generated.enums import EventsEnum
from ..src.types.webhook_endpoint import WebhookEndpoint, WebhookEndpointCreated
from .client_shared import ClientCoreMixin


class WebhookClientMixin(ClientCoreMixin):
    """Mixin that exposes outgoing webhook endpoints."""

    def get_webhook_endpoints(self) -> Iterable[WebhookEndpoint]:
        """Yield every outgoing webhook."""
        return self._get_core_items("/api/core/webhooks/endpoints/", WebhookEndpoint)

    def create_webhook_endpoint(  # pylint: disable=too-many-arguments
        self,
        name: str,
        url: str,
        events: Sequence[EventsEnum | str],
        *,
        description: str = "",
        active: bool = True,
        secret: str | None = None,
    ) -> WebhookEndpointCreated:
        """Create an outgoing webhook; Hive makes the signing secret unless ``secret`` (16+ chars) is given."""
        from ..client import HiveClient

        assert isinstance(self, HiveClient), "self must be an instance of HiveClient"
        payload: dict[str, object] = {
            "name": name,
            "url": url,
            "events": [str(event) for event in events],
            "description": description,
            "active": active,
        }
        if secret is not None:
            payload["secret"] = secret
        data = self.post("/api/core/webhooks/endpoints/", payload)
        assert isinstance(data, dict)
        return WebhookEndpointCreated.from_dict(data, hive_client=self)

    def delete_webhook_endpoint(self, endpoint: "WebhookEndpoint | str") -> None:
        """Delete an outgoing webhook (by model or id)."""
        endpoint_id = endpoint.id if isinstance(endpoint, WebhookEndpoint) else endpoint
        self.delete(f"/api/core/webhooks/endpoints/{endpoint_id}/")
