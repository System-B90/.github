"""
Name: webhook_endpoint.py
Purpose: Outgoing webhook models (the signing secret only on WebhookEndpointCreated).
"""

from typing import TYPE_CHECKING, Annotated, Any, TypeVar

from pydantic import Field
from typing_extensions import Self

from ._generated.models import WebhookEndpoint as _WebhookEndpointBase
from ._generated.models import WebhookEndpointCreated as _WebhookEndpointCreatedBase

if TYPE_CHECKING:
    from ...client import HiveClient


class WebhookEndpoint(_WebhookEndpointBase):
    """An outgoing webhook: Hive POSTs the events it subscribes to to its URL."""

    hive_client: Annotated["HiveClient", Field(exclude=True, repr=False)]

    @classmethod
    def from_dict(cls, src_dict: dict[str, Any], hive_client: "HiveClient") -> Self:
        data = dict(src_dict)
        data["hive_client"] = hive_client
        return cls.model_validate(data)


class WebhookEndpointCreated(_WebhookEndpointCreatedBase):
    """An outgoing webhook just created: ``secret`` (its signing key) is shown only this once."""

    hive_client: Annotated["HiveClient", Field(exclude=True, repr=False)]
    secret: Annotated[str, Field(repr=False)]

    @classmethod
    def from_dict(cls, src_dict: dict[str, Any], hive_client: "HiveClient") -> Self:
        data = dict(src_dict)
        data["hive_client"] = hive_client
        return cls.model_validate(data)


T = TypeVar("T", bound="WebhookEndpoint")
