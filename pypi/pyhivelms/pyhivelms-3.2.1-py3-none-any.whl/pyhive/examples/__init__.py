"""
Name: __init__.py
Purpose: Registry of the runnable example scripts shipped with PyHive. Each
    example is a module here exposing ``main(client, *args)``; ``pyhive examples``
    lists, prints and runs them.
Created: 2026-10-27
Author: Michael K. Steinberg
"""

from __future__ import annotations

import importlib
import pkgutil
from pathlib import Path
from types import ModuleType

__all__ = ["describe", "load", "names", "source"]


def names() -> list[str]:
    """Return the name of every shipped example, in alphabetical order."""
    return sorted(
        info.name
        for info in pkgutil.iter_modules(__path__)
        if not info.name.startswith("_")
    )


def load(name: str) -> ModuleType:
    """Import and return the example module called ``name``."""
    if name not in names():
        raise KeyError(f"No example named '{name}'. Available: {', '.join(names())}")
    return importlib.import_module(f"{__name__}.{name}")


def describe(name: str) -> str:
    """Return the one-line summary of an example (its docstring's first line)."""
    doc = load(name).__doc__ or ""
    return doc.strip().splitlines()[0] if doc.strip() else ""


def source(name: str) -> str:
    """Return the source code of an example."""
    load(name)
    return (Path(__file__).parent / f"{name}.py").read_text(encoding="utf-8")
