"""Print the course tree — program, subjects, modules, exercises — with counts.

Run:  pyhive examples run program_tree [PROGRAM_ID]
"""

from collections import defaultdict

from pyhive import HiveClient
from pyhive.types import Exercise, Module


def main(client: HiveClient, *args: str) -> None:
    programs = (
        [client.get_program(int(args[0]))] if args else list(client.get_programs())
    )
    for program in programs:
        # One request per level, grouped locally, instead of one request per
        # subject and per module through subject.get_modules().
        program_filter = [program.id]
        subjects = sorted(client.get_subjects(parent_program__id__in=program_filter))
        modules: dict[int, list[Module]] = defaultdict(list)
        for module in client.get_modules(
            parent_subject__parent_program__id__in=program_filter
        ):
            modules[module.parent_subject_id].append(module)
        exercises: dict[int, list[Exercise]] = defaultdict(list)
        for exercise in client.get_exercises(
            parent_module__parent_subject__parent_program__id__in=program_filter
        ):
            exercises[exercise.parent_module_id].append(exercise)

        print(f"{program.name} (#{program.id})")
        for subject in subjects:
            print(f"  [{subject.symbol}] {subject.name} (#{subject.id})")
            for module in sorted(modules[subject.id], key=lambda m: m.order):
                count = len(exercises[module.id])
                print(f"    {module.order:>3}. {module.name} — {count} exercises")
                for exercise in sorted(exercises[module.id], key=lambda e: e.order):
                    print(f"         - {exercise.name} (#{exercise.id})")


if __name__ == "__main__":
    with HiveClient.from_sso("https://chive.bis.net", verify=False) as hive:
        main(hive)
