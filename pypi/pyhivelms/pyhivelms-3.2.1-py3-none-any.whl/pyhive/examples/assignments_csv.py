"""Export assignments as CSV — student, subject, module, exercise, status, submissions.

Run:  pyhive examples run assignments_csv > assignments.csv
      pyhive examples run assignments_csv MENTOR_USER_ID   (only that mentor's mentees)
"""

import csv
import sys

from pyhive import HiveClient
from pyhive.types import Exercise, User


def main(client: HiveClient, *args: str) -> None:
    assignments = (
        client.get_assignments(for_mentees_of=int(args[0]))
        if args
        else client.get_assignments()
    )

    # Fetch each lookup table once. assignment.user / assignment.exercise
    # would issue one request per assignment.
    users: dict[int, User] = {user.id: user for user in client.get_users()}
    exercises: dict[int, Exercise] = {ex.id: ex for ex in client.get_exercises()}

    writer = csv.writer(sys.stdout)
    writer.writerow(
        ["student", "subject", "module", "exercise", "status", "submissions"]
    )
    for assignment in assignments:
        student = users.get(assignment.user_id)
        exercise = exercises.get(assignment.exercise_id)
        writer.writerow(
            [
                student.display_name if student else assignment.user_id,
                exercise.parent_subject_name if exercise else "",
                exercise.parent_module_name if exercise else "",
                exercise.name if exercise else assignment.exercise_id,
                assignment.assignment_status.value,
                assignment.submission_count,
            ]
        )


if __name__ == "__main__":
    with HiveClient.from_sso("https://chive.bis.net", verify=False) as hive:
        main(hive, *sys.argv[1:])
