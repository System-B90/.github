"""Print every class (rooms and student groups) with its members.

Run:  pyhive examples run class_roster
"""

from pyhive import HiveClient
from pyhive.types import ClassTypeEnum


def main(client: HiveClient, *_args: str) -> None:
    # One users request instead of class.users, which fetches members one by one.
    users = {user.id: user for user in client.get_users()}

    for class_type in ClassTypeEnum:
        print(f"{class_type.value}s")
        for hive_class in client.get_classes(type_=class_type):
            members = [users[uid].display_name for uid in hive_class.user_ids]
            print(f"  {hive_class.name} (#{hive_class.id}) — {len(members)} members")
            for name in sorted(members):
                print(f"      {name}")


if __name__ == "__main__":
    with HiveClient.from_sso("https://chive.bis.net", verify=False) as hive:
        main(hive)
