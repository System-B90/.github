"""`python -m pyhive.examples` — the same commands as `pyhive examples`."""

from pyhive.cli.examples import examples_app

examples_app(prog_name="python -m pyhive.examples")
