"""Create a subject, a module and its exercises from a plain Python outline.

Writes to the server. Everything it creates is deleted again at the end unless
you pass --keep.

Run:  pyhive examples run build_module PROGRAM_ID [--keep]
"""

import random
import string

from pyhive import HiveClient

OUTLINE = {
    "Python Basics": [
        "Variables and types",
        "Conditionals",
        "Loops",
        "Functions",
    ],
}


def main(client: HiveClient, *args: str) -> None:
    if not args:
        print("Pass a program id, e.g.: pyhive examples run build_module 2")
        return
    program = client.get_program(int(args[0]))
    keep = "--keep" in args

    symbol = "".join(random.choices(string.ascii_uppercase, k=2))
    subject = program.create_subject(
        symbol=symbol, name="PyHive example", color="#3F51B5"
    )
    print(f"Created subject [{subject.symbol}] {subject.name} (#{subject.id})")
    try:
        for order, (module_name, exercise_names) in enumerate(OUTLINE.items(), 1):
            module = subject.create_module(name=module_name, order=order)
            print(f"  module {module.name} (#{module.id})")
            for ex_order, exercise_name in enumerate(exercise_names, 1):
                exercise = module.create_exercise(
                    name=exercise_name, order=ex_order, expected_duration="45:00"
                )
                print(f"    exercise {exercise.name} (#{exercise.id})")
    finally:
        if not keep:
            # Deleting a subject deletes its modules and exercises with it.
            subject.delete()
            print("Deleted everything again (pass --keep to keep it).")


if __name__ == "__main__":
    import sys

    with HiveClient.from_sso("https://chive.bis.net", verify=False) as hive:
        main(hive, *sys.argv[1:])
