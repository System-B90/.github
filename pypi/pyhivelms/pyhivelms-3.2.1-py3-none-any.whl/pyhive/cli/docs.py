"""
Name: docs.py
Purpose: `pyhive docs` — read the documentation shipped inside the package and
    install it as a Claude Code skill. The same files are the published docs
    site, so what the terminal prints is what the site shows.
Created: 2026-10-27
Author: Michael K. Steinberg
"""

import shutil
from pathlib import Path
from typing import Annotated

import typer

from pyhive.cli.base import PyHiveTyper
from pyhive.cli.formatter import print_error_and_exit, print_result

docs_app = PyHiveTyper(help="Read the PyHive docs and install the Claude Code skill.")

DOCS_DIR = Path(__file__).resolve().parent.parent / "docs"
SKILL_NAME = "pyhive"


def _pages() -> dict[str, Path]:
    return {path.stem.lower(): path for path in sorted(DOCS_DIR.glob("*.md"))}


def _title(path: Path) -> str:
    lines = path.read_text(encoding="utf-8").splitlines()
    if lines and lines[0] == "---":
        lines = lines[lines.index("---", 1) + 1 :]
    return next((line[2:] for line in lines if line.startswith("# ")), path.stem)


@docs_app.callback(invoke_without_command=True)
def docs_callback(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        list_pages()


@docs_app.command(name="list")
def list_pages() -> None:
    """List the documentation pages."""
    pages = [
        {"page": name, "title": _title(path), "path": str(path)}
        for name, path in _pages().items()
    ]

    def text_output() -> None:
        typer.echo(f"PyHive docs ({DOCS_DIR}):")
        for page in pages:
            typer.echo(f"  pyhive docs show {page['page']:<9} {page['title']}")

    print_result({"docs_dir": str(DOCS_DIR), "pages": pages}, text_output)


@docs_app.command(name="show")
def show_page(
    page: str = typer.Argument("index", help="Page name, e.g. cli, sdk, examples"),
) -> None:
    """Print a documentation page as Markdown."""
    path = _pages().get(page.lower().removesuffix(".md"))
    if path is None:
        print_error_and_exit(
            f"No docs page '{page}'. Pages: {', '.join(_pages())}",
            {"error": "Unknown page", "page": page, "pages": list(_pages())},
        )
        return
    content = path.read_text(encoding="utf-8")
    print_result(
        {"page": path.stem.lower(), "path": str(path), "content": content},
        lambda: typer.echo(content),
    )


@docs_app.command(name="path")
def show_path() -> None:
    """Print the directory holding the documentation files."""
    print_result({"docs_dir": str(DOCS_DIR)}, lambda: typer.echo(DOCS_DIR))


@docs_app.command(name="install-skill")
def install_skill(
    project: Annotated[
        Path | None,
        typer.Option(
            help="Install into PROJECT/.claude/skills instead of ~/.claude/skills.",
            file_okay=False,
        ),
    ] = None,
) -> None:
    """Install the docs as the `pyhive` Claude Code skill (replaces an older copy)."""
    root = project if project is not None else Path.home()
    target = root / ".claude" / "skills" / SKILL_NAME
    try:
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(DOCS_DIR, target)
    except OSError as exc:
        print_error_and_exit(
            f"Could not install the skill into {target}: {exc}",
            {"error": "Skill install failed", "details": str(exc)},
        )
        return

    def text_output() -> None:
        typer.secho(f"Installed the '{SKILL_NAME}' skill into {target}", fg="green")
        typer.echo("Restart Claude Code (or run /skills) to pick it up.")

    print_result({"skill": SKILL_NAME, "path": str(target)}, text_output)
