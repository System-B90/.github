"""
Name: examples.py
Purpose: `pyhive examples` — list, print and run the example scripts shipped in
    `pyhive.examples`, signing in the same way every other command does.
Created: 2026-10-27
Author: Michael K. Steinberg
"""

from typing import Annotated

import typer

from pyhive import examples
from pyhive.cli.base import PyHiveTyper
from pyhive.cli.client_factory import (
    HIVE_URL_OPTION,
    VERIFY_OPTION,
    get_hive_client,
)
from pyhive.cli.formatter import print_error_and_exit, print_result

examples_app = PyHiveTyper(help="List, read and run the PyHive example scripts.")


@examples_app.callback(invoke_without_command=True)
def examples_callback(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        list_examples()


@examples_app.command(name="list")
def list_examples() -> None:
    """List the example scripts."""
    items = [
        {"name": name, "summary": examples.describe(name)} for name in examples.names()
    ]

    def text_output() -> None:
        width = max(len(item["name"]) for item in items)
        for item in items:
            typer.echo(f"{item['name']:<{width}}  {item['summary']}")

    print_result({"examples": items}, text_output)


@examples_app.command(name="show")
def show_example(name: str = typer.Argument(..., help="Example name")) -> None:
    """Print an example's source code."""
    try:
        code = examples.source(name)
    except KeyError as exc:
        print_error_and_exit(
            str(exc.args[0]), {"error": "Unknown example", "name": name}
        )
        return
    print_result({"name": name, "source": code}, lambda: typer.echo(code))


# Example arguments such as `--keep` belong to the example, not to this command.
@examples_app.command(
    name="run",
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
)
def run_example(
    name: str = typer.Argument(..., help="Example name"),
    args: Annotated[
        list[str] | None, typer.Argument(help="Arguments for the example")
    ] = None,
    hive_url: str = HIVE_URL_OPTION,
    verify: bool = VERIFY_OPTION,
) -> None:
    """Run an example against a Hive server. Output is the example's own text."""
    try:
        module = examples.load(name)
    except KeyError as exc:
        print_error_and_exit(
            str(exc.args[0]), {"error": "Unknown example", "name": name}
        )
        return
    try:
        client = get_hive_client(hive_url=hive_url, verify=verify)
        module.main(client, *(args or []))
    except Exception as e:  # pylint: disable=broad-exception-caught
        print_error_and_exit(
            message=f"Example '{name}' failed: {e}",
            error_data={"error": "Example failed", "name": name, "details": str(e)},
        )
