"""
Name: schedule_event.py
Purpose: Model for calendar events served by the Hive schedule API.
Created: 2026-08-23
Author: Michael K. Steinberg
"""

from typing import TYPE_CHECKING, Annotated, Any, TypeVar
from uuid import UUID

from pydantic import Field
from typing_extensions import Self

from ._generated.models import Event as _ScheduleEventBase
from ._generated.models import EventAttendeeClass as _EventAttendeeClassBase

if TYPE_CHECKING:
    from ...client import HiveClient


class ScheduleEventAttendee(_EventAttendeeClassBase):
    """A class attending a schedule event (id, name, description, program_id)."""

    # Hive <= 7.3.0 serves no program_id and a nullable description.
    description: str | None = None  # type: ignore[assignment]
    program_id: int | None = None


class ScheduleEvent(_ScheduleEventBase):
    """A calendar event (category/room/lesson links, attendees). Data fields are inherited."""

    # Hive < 7.3.0 serves integer ids here; 7.3.0+ serves UUIDs.
    id: UUID | int | None = None  # type: ignore[assignment]
    category_id: UUID | int | None = None  # type: ignore[assignment]
    lesson_id: UUID | int | None = None  # type: ignore[assignment]
    category_name: str | None = None

    # Hive <= 7.3.0 omits the flattened display fields 8.0.0 added, may send a
    # null title, and serves the description/locked fields 8.0.0 dropped.
    title: str | None = None  # type: ignore[assignment]
    hidden_from_students: bool | None = None  # type: ignore[assignment]
    attendees: list[ScheduleEventAttendee] = Field(default_factory=list)  # type: ignore[assignment]
    category_color: str | None = None
    category_has_lesson: bool | None = None
    room_id: int | None = None
    room_name: str | None = None
    room_program_id: int | None = None
    lesson_name: str | None = None
    module_id: int | None = None
    subject_id: int | None = None
    subject_symbol: str | None = None
    subject_color: str | None = None
    subject_program_id: int | None = None
    description: str | None = None
    locked: bool | None = None

    hive_client: Annotated["HiveClient", Field(exclude=True, repr=False)]

    @classmethod
    def from_dict(cls, src_dict: dict[str, Any], hive_client: "HiveClient") -> Self:
        data = dict(src_dict)
        data["hive_client"] = hive_client
        return cls.model_validate(data)


T = TypeVar("T", bound="ScheduleEvent")
